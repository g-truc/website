Start the demo using exec.bat
You can change CLOD level with the key "PAGE UP" and "PAGE DOWN".
The programme will close when demo will finished or if you press escape key.
The demo need a graphic board with 4 textures units as GF3, GF4 ti, GF FX, Radeon 8xxx and Radeon 9xxx

Demo by : 
Groove -> Programming
groove@g-truc.net, www.g-truc.net

Invalide -> Mapping and texture
invalide@gnougnou.com, invalide.gnougnou.com