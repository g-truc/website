//////////////////////////////////////////////////////////////////////////////////
// OpenGL Mathematics Copyright (c) 2005 G-Truc Creation (www.g-truc.net)
//////////////////////////////////////////////////////////////////////////////////
// Author  : Christophe [Groove] Riccio (contact [at] g-truc [point] net)
// Created : 2005-01-10
// Updated : 2006-01-04
// Licence : This source is under GNU LGPL licence
// File    : _vec3.h
//////////////////////////////////////////////////////////////////////////////////
// Optimisation note: Don't use vec3 class instead of vec4 because you think it 
// whould be faster. It whouldn't be the case especially if you use SSE 
// intructions set in your compiler option and/or mat4 transformations.
// An advide: test your code speed with vec3 and vec4 to select the faster.
//////////////////////////////////////////////////////////////////////////////////

#ifndef __vec3_h__
#define __vec3_h__

namespace glm
{
    template <typename T> class _xvec2;
    template <typename T> class _xvec4;
    class _bvec2;
    class _bvec3;
    class _bvec4;
    template <typename T> class _xmat3;

    //!< \brief Template for Vector of 3 floating-point numbers or 3 integers . (From GLSL 1.10.59 specification)
    template <typename T> 
    class _xvec3
    {
    public:
        // Data
        /* ISO C++ version unavailable with VC7.1 ...
            union{T x, r, s;};
            union{T y, g, t;};
            union{T z, b, p;};
        */
        // Solution away from ISO C++ but available with VC7.1 and GCC without -pedantic
        union 
        {
            struct{T x, y, z;};
            struct{T r, g, b;};
            struct{T s, t, p;};
        };

        // Constructors
	    _xvec3();
	    explicit _xvec3(const T x, const T y, const T z);
        explicit _xvec3(T f);

        // Convertions
        template <typename U> explicit _xvec3(U x, U y, U z);
        explicit _xvec3(const _xvec2<T> & v1, T v2);
        explicit _xvec3(T v1, const _xvec2<T> & v2);
        explicit _xvec3(const _xvec4<T> & v);
        explicit _xvec3(const _bvec3& v);
        explicit _xvec3(const _bvec2& v1, bool v2);
        explicit _xvec3(bool v1, const _bvec2& v2);
        explicit _xvec3(const _bvec4& v);
        template <typename U> explicit _xvec3(const _xvec3<U>& v);
        template <typename U> explicit _xvec3(const _xvec2<U>& v1, U v2);
        template <typename U> explicit _xvec3(U v1, const _xvec2<U>& v2);
        template <typename U> explicit _xvec3(const _xvec4<U>& v);

        // Accesses
        T& operator [] (int i);
        T operator [] (int i) const;
        operator T* ();
	    operator const T* () const;

        // Operators
        _xvec3<T>& operator=(const _xvec3<T>& x);
	    _xvec3<T> operator+ (const T s) const;
	    _xvec3<T> & operator+= (const T s);
	    _xvec3<T> operator+ (const _xvec3<T> & v) const;
	    _xvec3<T> & operator+= (const _xvec3<T> & v);
	    _xvec3<T> operator- (const T s) const;
	    _xvec3<T> & operator-= (const T s);
	    _xvec3<T> operator- (const _xvec3<T> & v) const;
	    _xvec3<T> & operator-= (const _xvec3<T> & v);
        _xvec3<T> operator* (const T s) const;
	    _xvec3<T> & operator*= (const T s);
	    _xvec3<T> operator* (const _xvec3<T> & v) const;
	    _xvec3<T> & operator*= (const _xvec3<T> & v);
        _xvec3<T> operator* (const _xmat3<T> & m) const;
        _xvec3<T> & operator*= (const _xmat3<T>& m);
        _xvec3<T> operator/ (const T s) const;
	    _xvec3<T> & operator/= (const T s);
	    _xvec3<T> operator/ (const _xvec3<T> & v) const;
	    _xvec3<T> & operator/= (const _xvec3<T> & v);
        _xvec3<T> operator- () const;
        _xvec3<T> operator++ ();
	    const _xvec3<T> operator++ (int n) const;
	    _xvec3<T> operator-- ();
	    const _xvec3<T> operator-- (int n) const;
    };

    template <typename T> 
    _xvec3<T> operator+ (const T s, const _xvec3<T> & v)
    {
        return v + s;
    }
//  _xvec3<T> operator-() const is defined so this isn't need
    template <typename T> 
    _xvec3<T> operator- (const T s, const _xvec3<T> & v)
    {
        return _xvec3<T>(s - v.x, s - v.y, s - v.z);
    }

    template <typename T> 
    _xvec3<T> operator* (const T s, const _xvec3<T> & v)
    {
        return v * s;
    }

    //////////////////////////////////////////////////////////

    class _bvec2;
    class _bvec4;

    //!< \brief Class for Vector of 3 booleans. (From GLSL 1.10.59 specification)
    class _bvec3
    {
    public:
        //int _size () const;

    public:
        // Data
        union{bool x, r, s;};
        union{bool y, g, t;};
        union{bool z, b, p;};

        // Constructors
	    _bvec3();
	    explicit _bvec3(bool x, bool y, bool z);
        explicit _bvec3(bool b);
        explicit _bvec3(const _bvec2 & v1, bool v2);
        explicit _bvec3(bool v1, const _bvec2 & v2);
        explicit _bvec3(const _bvec4& v);

        // Convertions
        template <typename U> explicit _bvec3(const _xvec3<U>& v);
        template <typename U> explicit _bvec3(const _xvec2<U>& v1, U v2);
        template <typename U> explicit _bvec3(U v1, const _xvec2<U>& v2);
        template <typename U> explicit _bvec3(const _xvec4<U>& v);

        // Accesses
        bool& operator [] (int i);
        bool operator [] (int i) const;
        operator bool* ();
	    operator const bool* () const;

        // Operators
        _bvec3& operator=(const _bvec3& x);
	    _bvec3 operator-- ();
		const _bvec3 operator-- (int n) const;
		_bvec3 operator++ ();
	    const _bvec3 operator++ (int n) const;
	    _bvec3 operator! () const;
    };
} //namespace glm

#endif //__vec3_h__
