#include "precompiled.h"
#include "component_test2.h"
#include "message.h"

// CTestComponent2
CTestComponent2::CTestComponent2(handle ObjectId, const o::core::IParameter* Parameter) :
	ITestComponent(ObjectId, CTestComponent2::Type)
{
	Position[0] = 0.0f;
	Position[1] = 0.0f;
	Position[2] = 0.0f;
}

void CTestComponent2::Print()
{
	printf("CTestComponent2::Print, ObjectID: %d, ComponentId: %d\n", ObjectId, ComponentId);
	printf("Position(%f, %f, %f)\n", Position[0], Position[1], Position[2]);
}

bool CTestComponent2::HandleMessage(const o::core::IMessage* Message)
{
	bool Result = false;
	if(Message->TypeId == CMessagePosition::Type)
	{
		const CMessagePosition* MessagePosition = static_cast<const CMessagePosition*>(Message);
		Position[0] = MessagePosition->Position[0];
		Position[1] = MessagePosition->Position[1];
		Position[2] = MessagePosition->Position[2];
	}
	return Result;
}

// CTestParameter2
CTestParameter2::CTestParameter2() :
	TypeId(CTestComponent2::Type)
{}
