#ifndef __MESSAGE_H__
#define __MESSAGE_H__

class CMessagePosition : public o::core::IMessage, public o::core::IType<CMessagePosition>
{
public:
	CMessagePosition(handle Sender, float x, float y, float z);
	float Position[3];
};

#endif//__MESSAGE_H__
