#ifndef __COMPONENT_TEST_H__
#define __COMPONENT_TEST_H__

interface ITestComponent : public o::core::IComponent
{
	ITestComponent(handle ObjectId, handle TypeId) : o::core::IComponent(ObjectId, TypeId){}
	virtual ~ITestComponent(){}
	virtual void Print() = 0;
};

#endif//__COMPONENT_TEST_H__
