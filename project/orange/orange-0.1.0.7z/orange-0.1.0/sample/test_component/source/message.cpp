#include "precompiled.h"
#include "message.h"

CMessagePosition::CMessagePosition(handle Sender, float x, float y, float z) :
	IMessage(Sender, CMessagePosition::Type)
{
	Position[0] = x;
	Position[1] = y;
	Position[2] = z;
}