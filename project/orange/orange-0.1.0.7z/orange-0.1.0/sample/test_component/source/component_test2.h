#ifndef __COMPONENT_TEST2_H__
#define __COMPONENT_TEST2_H__

#include "component_test.h"

class CTestParameter2 : public o::core::IParameter
{
public:
	CTestParameter2();

	const handle TypeId;
};

class CTestComponent2 : public ITestComponent, public o::core::IType<CTestComponent2>
{
	friend class o::core::CObjectManager;

public:
	CTestComponent2(handle ObjectId, const o::core::IParameter* Parameter);
	virtual ~CTestComponent2(){}

	virtual void Print();

	virtual bool HandleMessage(const o::core::IMessage* Message);

private:
	float Position[3];
};

#endif//__COMPONENT_TEST2_H__
