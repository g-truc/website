#include "precompiled.h"
#include "component_test1.h"
#include "component_test2.h"
#include "message.h"

// CTestParameter
CTestParameter1::CTestParameter1() :
	TypeId(CTestComponent1::Type)
{}

// CTestComponent
CTestComponent1::CTestComponent1(handle ObjectId, const o::core::IParameter* Parameter) :
	ITestComponent(ObjectId, CTestComponent1::Type)
{}

void CTestComponent1::Print()
{
	printf("CTestComponent1::Print, ObjectID: %d, ComponentId: %d\n", ObjectId, ComponentId);
}

void CTestComponent1::Update()
{
	CMessagePosition Message(ComponentId, 76.f, 76.f, 76.f);
	o::core::CObjectManager::GetInstance()->Broadcast(o::core::TARGET_TYPE, CTestComponent2::Type, &Message);
}
