#include <orange.h>

class Class1
{
public:
	Class1() : integer(0) {o_message("Class1 Constructor");}
	~Class1(){o_message("Class1 Destructor");}

private:
	int integer;
};

class Class2
{
public:
	Class2() : integer(0) {o_message("Class2 Constructor");}
	~Class2(){o_message("Class2 Destructor");}

private:
	int integer;
};

void test_memory()
{
	o_message("===== test_memory =====");

	o::core::Error* err = o::core::Error::GetInstance();
	// Memory macros allow a global overview of memory leak and could answer to the question "Is there a memory leak in my program ?"
	o_message(o::core::format("Allocated object: %d", err->GetUsageCount()).c_str());

	// Memory allocation for one object, like "new Class" in this sample
	Class1* Object = new_object(Class1);
	// Memory allocation for array, like "new Class[2]" in this sample
	Class1* Array = new_array(Class1, 2);

	// If you used this library, it's high recommended to never used new or delete operators in the full program. 
	// In release mode memory macro are replaced by usual memory operator, they haven't got any cost indend.

	o_message(o::core::format("Allocated object: %d", err->GetUsageCount()).c_str());

	// Free memory for one object, like "delete Object" in this sample
	delete_object(Object);
	// Free memory for an array, like "delete[] Array" in this sample
	delete_array(Array);

	// Some information are available from the Log Class.
	// GetUsageCount : Return the number of variables in memory. This value should be null at the and of the program, otherwise the means that you have a memory leak
	// GetMemoryAllocated : Return the size of memory allocated since the beginning of the program
	// GetNewCount : Return the number of call of new_object and new_array
	// GetDeleteCount : Return the number of call of delete_object and delete_array
	// GetNewObjectCount : Return the number of call of new_object
	// GetNewArrayCount : Return the number of call of new_array
	// GetDeleteObjectCount : Return the number of call of delete_object
	// GetDeleteArrayCount : Return the number of call of delete_array
	o_message(o::core::format("Allocated object: %d", err->GetUsageCount()).c_str());
}

void test_log()
{
	// message is use for custom user information.
	o_message("===== test_log =====");

	// test could be used everywhere in the program to test variables values.
	// At release mode test macro is skip.
	o_test((1 < 2), "1 < 2 ?");
	o_test((2 < 1), "2 < 1 ?");

	// warning macro should be used when a none critical issue occur 
	o_warning(false, "No warning, the program continue");
	o_warning(true, "A warning, the program continue");

	// error macro should be used to stop the program after a critical error.
	o_error(false, "No error, the program continue");
	o_error(true, "An error, the program stop");

	o_message("None logged");
}

int main()
{
	test_memory();
	test_log();

	system("pause");

	return 0;
}
