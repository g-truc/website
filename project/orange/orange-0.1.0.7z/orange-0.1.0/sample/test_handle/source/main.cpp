#include <orange.h>

int main()
{
	handle Handle1;
	handle Handle2 = Handle1;
	handle Handle3(Handle1);
	handle Handle4;
	handle Handle5[2];
	//Handle2 = Handle3; //Error, an handler could not change its value

	if(Handle1 == Handle2)
		printf("Handle1 == Handle2: %d, %d\n", Handle1, Handle2);

	if(Handle1 == Handle3)
		printf("Handle1 == Handle3: %d, %d\n", Handle1, Handle3);

	if(Handle1 != Handle4)
		printf("Handle1 != Handle4: %d, %d\n", Handle1, Handle4);

	printf("handles: %d, %d, %d, %d\n", Handle1, Handle2, Handle3, Handle4);

	for(int i = 0; i < 2; ++i)
		printf("Handle[%d]: %d\n", i, Handle5[i]);

	system("pause");

	return 0;
}
