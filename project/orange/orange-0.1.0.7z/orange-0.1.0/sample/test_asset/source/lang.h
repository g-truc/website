#ifndef __ORANGE_CORE_ERROR_LANG_H__
#define __ORANGE_CORE_ERROR_LANG_H__

#include <orange.h>

class CLang : public ocore::IAsset, public obase::CType<CLang>
{
	friend class obase::CCreator<ocore::IAsset, CLang>;

public:
	static CLang* Create(const char* Filename);
	static void Release(CLang* Asset);

	virtual bool Load(const ocore::CResource* Resource);
	virtual std::string Find(int Message) const;

	const ocore::TLangMap& GetLangMap() const {return _LangMap;}

private:
	CLang();
	virtual ~CLang();
	
	void _ReadLangElement(TiXmlElement* Element);

	ocore::TLangMap _LangMap;
};

#endif//__ORANGE_CORE_ERROR_LANG_H__
