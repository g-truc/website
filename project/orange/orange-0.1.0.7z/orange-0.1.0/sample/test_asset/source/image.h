#ifndef __IMAGE_H__
#define __IMAGE_H__

#include <orange.h>

//! \brief Enumeration to indicate the image format
//! Values are those of OpenGL specification, eg: 
//! RGB = GL_RGB
//! DXT1 = GL_COMPRESSED_RGBA_S3TC_DXT1_EXT
enum EImageFormat
{
    IMAGE_NONE = 0,
    IMAGE_RGB = 0x1907,
    IMAGE_BGR = 0x80E0,
    IMAGE_RGBA = 0x1908,
    IMAGE_BGRA = 0x80E1,
    IMAGE_LUMINANCE = 0x1909,
    IMAGE_LUMINANCE_ALPHA = 0x190A,
    IMAGE_DXT1 = 0x83F1,
    IMAGE_DXT3 = 0x83F2,
    IMAGE_DXT5 = 0x83F3
};

class CImage : public ocore::IAsset, public obase::CType<CImage>
{
	friend class obase::CCreator<ocore::IAsset, CImage>;

public:
	static CImage* Create(const char* Filename);
	static void Release(CImage* Asset);

    bool IsLoaded(){return Loaded;}

	const byte* GetData() const{return Data;}
	uint32 GetWidth() const{return Width;}
	uint32 GetHeight() const{return Height;}
    uint8 GetMipmaps() const{return Mipmaps;}
	uint8 GetComponents() const{return Components;}
    EImageFormat GetFormat() const{return Format;}

protected:
	CImage();
	~CImage();

    byte* Data;
    uint32 Width;
    uint32 Height;
    uint8 Mipmaps;
    uint8 Components;
    bool Loaded;
    EImageFormat Format;
};

#endif//__IMAGE_H__
