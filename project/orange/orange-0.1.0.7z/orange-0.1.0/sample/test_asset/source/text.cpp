#include "text.h"

CText::CText()
{}

CText::~CText()
{}

CText* CText::Create(const char* Filename)
{
	// During the frist CText object creation, the CText class is registred in the resource manager with the RegisterAsset function
	o::core::RegisterAsset<CText>("txt");

	IAsset* Asset = o::core::CResourceManager::GetInstance()->FindAsset(Filename);
	o_error(/*Asset->Type() != CText::Type || */Asset == null, o::core::format("Loading of %s failed", Filename).c_str());
	return reinterpret_cast<CText*>(Asset);
}

void CText::Release(CText* Text)
{
	o::core::CResourceManager::GetInstance()->ReleaseAsset(Text);
}

bool CText::Load(const o::core::PResource& Resource)
{
	if(Resource == null)
		return false;
	_Content = std::string((char*)(Resource->GetBuffer()));
	return true;
}

void CText::Print() const
{
	printf((_Content + std::string("\n")).c_str());
}
