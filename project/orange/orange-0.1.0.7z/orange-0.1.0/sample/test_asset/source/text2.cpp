#include "text2.h"

CText2::CText2()
{}

CText2::~CText2()
{}

CText2* CText2::Create(const char* Filename)
{
	o::core::RegisterAsset<CText2>("tx2");

	o::core::IAsset* Asset = o::core::CResourceManager::GetInstance()->FindAsset(Filename);
	//orange_error(/*Asset->Type() != CText::Type || */Asset == null, util::format("Loading of %s failed", Filename).c_str());
	return reinterpret_cast<CText2*>(Asset);
}

void CText2::Release(CText2* Text)
{
	o::core::CResourceManager::GetInstance()->ReleaseAsset(Text);
}

bool CText2::Load(const o::core::PResource& Resource)
{
	if(Resource == null)
		return false;
	_Content = std::string((char*)(Resource->GetBuffer()));
	return true;
}

void CText2::Print() const
{
	printf((_Content + std::string("\n")).c_str());
}

