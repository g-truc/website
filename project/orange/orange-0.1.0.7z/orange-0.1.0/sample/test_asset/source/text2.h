#ifndef __RES_TEXT2_H__
#define __RES_TEXT2_H__

#include <orange.h>

class CText2 : public o::core::IAsset, public o::core::IType<CText2>
{
	friend class o::core::CCreator<o::core::IAsset, CText2>;

public:
	static CText2* Create(const char* Filename);
	static void Release(CText2* Text);

	virtual bool Load(const o::core::PResource& Resource);
	virtual handle GetType() const{return CText2::Type;}

	void Print() const;

private:
	CText2();
	~CText2();

	std::string _Content;
};

#endif//__RES_TEXT2_H__
