#include "text.h"
#include "text2.h"

enum EMessageId
{
	MESSAGE_COUCOU1 = 1,
	MESSAGE_COUCOUX = 2
};

int main()
{
	// Creation of an instance of "test.txt"
	CText* TextA = CText::Create("test.txt");
	TextA->Print();

	// Create a new reference of the instance of "test.txt"
	CText* TextB = CText::Create("test.txt");
	TextB->Print();

	// Creation of an instance of "test.tx2"
	CText2* TextC = CText2::Create("test.tx2");
	TextC->Print();

	// Release of a reference of "test.txt"
	CText::Release(TextA);

	// Creation of an instance of "test76.txt"
	CText* TextD = CText::Create("test76.txt");
	TextD->Print();

	// Destroy the instance of test.txt
	CText::Release(TextB);
	// Destroy the instance of test.tx2
	CText2::Release(TextC);
	// Destroy the instance of test76.txt
	CText::Release(TextD);

	o::core::CImage* ImageDDS = o::core::CImage::Create("image.dds");
	printf("ImageDDS width: %d\n", ImageDDS->GetWidth());
	printf("ImageDDS height: %d\n", ImageDDS->GetHeight());
	o::core::CImage::Release(ImageDDS);

	o::core::CImage* ImageTGA = o::core::CImage::Create("image.tga");
	printf("ImageTGA width: %d\n", ImageTGA->GetWidth());
	printf("ImageTGA height: %d\n", ImageTGA->GetHeight());
	o::core::CImage::Release(ImageTGA);

	o::core::CLang* Lang = o::core::CLang::Create("coucou.xlang");

	printf(Lang->Find(MESSAGE_COUCOU1).c_str());
	printf("\n");
	printf(Lang->Find(MESSAGE_COUCOUX).c_str(), 76);
	printf("\n");

	o::core::CErrorMessage* ErrorMessage = o::core::CErrorMessage::GetInstance();
	ErrorMessage->Read(Lang->GetLangMap());
	printf(ErrorMessage->Find(MESSAGE_COUCOU1).c_str());
	printf("\n");

	o::core::CLang::Release(Lang);

	system("pause");
}
