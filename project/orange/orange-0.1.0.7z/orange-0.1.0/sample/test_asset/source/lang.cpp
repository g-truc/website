#include "precompiled.h"
#include "lang.h"

CLang::CLang()
{}

CLang::~CLang()
{}

CLang* CLang::Create(const char* Filename)
{
	ocore::RegisterAsset<CLang>("xlang");

	IAsset* Asset = ocore::CResourceManager::GetInstance()->FindAsset(Filename);
	//orange_error(/*Asset->Type() != CText::Type || */Asset == null, obase::format("Loading of %s failed", Filename).c_str());
	return reinterpret_cast<CLang*>(Asset);
}

void CLang::Release(CLang* Lang)
{
	ocore::CResourceManager::GetInstance()->ReleaseAsset(Lang);
}

bool CLang::Load(const ocore::CResource* Resource)
{
	if(Resource == null)
		return false;

	TiXmlDocument Document;
	Document.Parse((char*)Resource->GetBuffer());
	if(Document.Error())
		printf("Error in %s: %s\n", Document.Value(), Document.ErrorDesc());

	TiXmlElement* Lang = Document.FirstChild("lang")->ToElement();
	if(Lang == null)
		return false;

    TiXmlElement* LangElement = Lang->FirstChildElement("lang-element");
    if(LangElement == null)
        return false;
    do
    {
        _ReadLangElement(LangElement);
    }
    while(LangElement = LangElement->NextSiblingElement());

	return true;
}

std::string CLang::Find(int Message) const
{
	ocore::TLangMap::const_iterator it = _LangMap.find(Message);
	if(it != _LangMap.end())
		return it->second;
	return std::string();
}

void CLang::_ReadLangElement(TiXmlElement* Element)
{
	int MessageId = 0;
	std::string MessageContent;

    TiXmlAttribute* Attribute = Element->FirstAttribute();
    do
    {
        if(!strcmp("id", Attribute->Name()))
            MessageId = atoi(Attribute->Value());
        else if(!strcmp("content", Attribute->Name()))
            MessageContent = std::string(Attribute->Value());
    }    
    while(Attribute = Attribute->Next());
	_LangMap.insert(std::make_pair(MessageId, MessageContent));
}

