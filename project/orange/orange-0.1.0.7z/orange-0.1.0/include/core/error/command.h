#ifndef __ORANGE_CORE_ERROR_COMMAND_H__
#define __ORANGE_CORE_ERROR_COMMAND_H__

#include <core/util/util.h>
#include "log_manager.h"

#define message(msg)														\
{																			\
	o::core::Log::Instance()->Message(o::core::MESSAGE, msg, __FILE__, __LINE__);	\
}

#ifdef NDEBUG
#define test(expression, message)	
#else
#define test(expression, message)																	\
{																									\
	o::core::Log::Instance()->Test(o::core::TEST, #expression, expression, message, __FILE__, __LINE__);	\
}

#endif

#define error(expression, message)															\
{																							\
	if(expression == true)																	\
	{																						\
		o::core::Log::Instance()->Error(o::core::ERROR_TARGET, #expression, message, __FILE__, __LINE__);	\
		exit(1);																			\
	}																						\
}

#define caution(expression, message)															\
{																								\
	if(expression == true)																		\
	{																							\
		o::core::Log::Instance()->Warning(o::core::WARNING, #expression, message, __FILE__, __LINE__);	\
	}																							\
}

#endif//__ORANGE_CORE_ERROR_COMMAND_H__
