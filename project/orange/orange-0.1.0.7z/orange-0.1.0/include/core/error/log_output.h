#ifndef __ORANGE_CORE_ERROR_LOG_OUTPUT_H__
#define __ORANGE_CORE_ERROR_LOG_OUTPUT_H__

#include "log_manager.h"

namespace o {
namespace core {
/*
class LoggerDebug : public Logger
{
	friend class Log;

public:
	static LoggerDebug* Create(){return new_object(LoggerDebug);}
	virtual void NewObject(const char* type, size_t size, const char* file, int line);
	virtual void NewArray(const char* type, size_t size, const char* File, int line);
	virtual void DeleteObject(const char* object, const char* file, int line);
	virtual void DeleteArray(const char* array, const char* file, int line);
	virtual void Test(const char* expression, bool result, const char* message, const char* file, int line);
	virtual void Warning(const char* expression, const char* message, const char* file, int line);
	virtual void Error(const char* expression, const char* message, const char* file, int line);
	virtual void Message(const char* message, const char* filename, int line);

private:
	LoggerDebug(){}
	virtual ~LoggerDebug(){}
};

class LoggerMessageBox : public Logger
{
	friend class Log;

public:
	static LoggerMessageBox* Create(){return new_object(LoggerMessageBox);}
	virtual void NewObject(const char* type, size_t size, const char* file, int line);
	virtual void NewArray(const char* type, size_t size, const char* File, int line);
	virtual void DeleteObject(const char* object, const char* file, int line);
	virtual void DeleteArray(const char* array, const char* file, int line);
	virtual void Test(const char* expression, bool result, const char* message, const char* file, int line);
	virtual void Warning(const char* expression, const char* message, const char* file, int line);
	virtual void Error(const char* expression, const char* message, const char* file, int line);
	virtual void Message(const char* message, const char* filename, int line);

private:
	LoggerMessageBox(){}
	virtual ~LoggerMessageBox(){}
};
*/
class LoggerText : public Logger
{
	friend class Log;

public:
	static LoggerText* Create(const char* Filename){return new_object(LoggerText)(Filename);}
	virtual void NewObject(const char* type, size_t size, const char* filename, int line);
	virtual void NewArray(const char* type, size_t size, const char* filename, int line);
	virtual void DeleteObject(const char* object, const char* filename, int line);
	virtual void DeleteArray(const char* array, const char* filename, int line);
	virtual void Test(const char* expression, bool result, const char* message, const char* filename, int line);
	virtual void Warning(const char* expression, const char* message, const char* filename, int line);
	virtual void Error(const char* expression, const char* message, const char* filename, int line);
	virtual void Message(const char* message, const char* filename, int line);
	virtual void Flush();

private:
	LoggerText(const char* Filename);
	virtual ~LoggerText();

	FILE* file;
};

class LoggerStream : public Logger
{
	friend class Log;

public:
	static LoggerStream* Create(FILE* flux){return new_object(LoggerStream)(flux);}
	virtual void NewObject(const char* type, size_t size, const char* filename, int line);
	virtual void NewArray(const char* type, size_t size, const char* filename, int line);
	virtual void DeleteObject(const char* object, const char* filename, int line);
	virtual void DeleteArray(const char* array, const char* filename, int line);
	virtual void Test(const char* expression, bool result, const char* message, const char* filename, int line);
	virtual void Warning(const char* expression, const char* message, const char* filename, int line);
	virtual void Error(const char* expression, const char* message, const char* filename, int line);
	virtual void Message(const char* message, const char* filename, int line);

private:
	LoggerStream(FILE* flux);
	virtual ~LoggerStream();

	FILE* Stream;
};

}// namespace core
}// namespace o

#endif//__ORANGE_CORE_ERROR_LOG_OUTPUT_H__
