#ifndef __ORANGE_CORE_ERROR_MANAGER_H__
#define __ORANGE_CORE_ERROR_MANAGER_H__

#include <core/util/util.h>

namespace o {
namespace core {

enum Target
{
	MESSAGE = (1 << 0),
	TEST = (1 << 1),
	ERROR_TARGET = (1 << 2),
	WARNING = (1 << 3),
	MEMORY = (1 << 4),
	ALL = MESSAGE | TEST | ERROR_TARGET | WARNING | MEMORY
};

interface Logger
{
	virtual ~Logger(){}
	virtual void NewObject(const char* type, size_t size, const char* filename, int line) = 0;
	virtual void NewArray(const char* type, size_t size, const char* filename, int line) = 0;
	virtual void DeleteObject(const char* object, const char* filename, int line) = 0;
	virtual void DeleteArray(const char* array, const char* filename, int line) = 0;
	virtual void Test(const char* expression, bool result, const char* message, const char* filename, int line) = 0;
	virtual void Warning(const char* expression, const char* message, const char* filename, int line) = 0;
	virtual void Error(const char* expression, const char* message, const char* filename, int line) = 0;
	virtual void Message(const char* message, const char* filename, int line) = 0;
	virtual void Flush(){}
};

class Log
{
	typedef std::multimap<flag, Logger*> TLoggerMap;

public:
    static Log* Instance();
    static void Destroy();

	void Register(flag target, Logger* logger);
	void Flush();

	void SetAutoFlush(bool autoFlush){this->autoFlush = autoFlush;}
	bool GetAutoFlush() const {return autoFlush;}

	uint64 GetMemoryAllocated() const {return memoryAllocated;}
	uint64 GetNewCount() const {return newObjectCount + newArrayCount;}
	uint64 GetDeleteCount() const {return deleteObjectCount + deleteArrayCount;}
	uint64 GetNewObjectCount() const {return newObjectCount;}
	uint64 GetNewArrayCount() const {return newArrayCount;}
	uint64 GetDeleteObjectCount() const {return deleteObjectCount;}
	uint64 GetDeleteArrayCount() const {return deleteArrayCount;}
	uint64 GetUsageCount() const {return newObjectCount + newArrayCount - deleteObjectCount - deleteArrayCount;}

	void NewObject(flag target, const char* type, size_t size, const char* file, int line);
	void NewArray(flag target, const char* type, size_t size, const char* file, int line);
	void DeleteObject(flag target, const char* object, const char* file, int line);
	void DeleteArray(flag target, const char* array, const char* file, int line);
	void Test(flag target, const char* expression, bool result, const char* message, const char* file, int line);
	void Warning(flag target, const char* expression, const char* message, const char* file, int line);
	void Error(flag target, const char* expression, const char* message, const char* file, int line);
	void Message(flag target, const char* message, const char* file, int line);

protected:
	Log();
	~Log();

	TLoggerMap loggerMap;
	uint64 memoryAllocated;
	uint64 newObjectCount;
	uint64 deleteObjectCount;
	uint64 newArrayCount;
	uint64 deleteArrayCount;
	bool autoFlush;

	static Log* object;
};

}//namespace core
}//namespace o

#endif//__ORANGE_CORE_ERROR_MANAGER_H__
