#ifndef __ORANGE_CORE_ERROR_ERROR_H__
#define __ORANGE_CORE_ERROR_ERROR_H__

#include <core/pattern/pattern.h>
#include "log_manager.h"

namespace o {
namespace core {

class Error : public CSingleton<Error>
{
	friend class CSingleton<Error>;

public:
	inline uint64 GetMemoryAllocated() const{return Log::Instance()->GetMemoryAllocated();}
	inline uint64 GetNewCount() const{return Log::Instance()->GetNewCount();}
	inline uint64 GetDeleteCount() const{return Log::Instance()->GetDeleteCount();}
	inline uint64 GetNewObjectCount() const{return Log::Instance()->GetNewObjectCount();}
	inline uint64 GetNewArrayCount() const{return Log::Instance()->GetNewArrayCount();}
	inline uint64 GetDeleteObjectCount() const{return Log::Instance()->GetDeleteObjectCount();}
	inline uint64 GetDeleteArrayCount() const{return Log::Instance()->GetDeleteArrayCount();}
	inline uint64 GetUsageCount() const{return Log::Instance()->GetUsageCount();}

private:
	Error();
	virtual ~Error();
};

}//namespace core
}//namespace o

#define o_message(msg)															\
{																					\
	o::core::Error::GetInstance();													\
	o::core::Log::Instance()->Message(o::core::MESSAGE, msg, __FILE__, __LINE__);	\
}

#ifdef NDEBUG
#define o_test(expression, message)	
#else
#define o_test(expression, message)																	\
{																											\
	o::core::Error::GetInstance();																			\
	o::core::Log::Instance()->Test(o::core::TEST, #expression, expression, message, __FILE__, __LINE__);	\
}

#endif

#define o_error(expression, message)																	\
{																											\
	if(expression == true)																					\
	{																										\
		o::core::Error::GetInstance();																		\
		o::core::Log::Instance()->Error(o::core::ERROR_TARGET, #expression, message, __FILE__, __LINE__);	\
		exit(1);																							\
	}																										\
}

#define o_warning(expression, message)																\
{																										\
	if(expression == true)																				\
	{																									\
		o::core::Error::GetInstance();																	\
		o::core::Log::Instance()->Warning(o::core::WARNING, #expression, message, __FILE__, __LINE__);	\
	}																									\
}

#endif//__ORANGE_CORE_ERROR_ERROR_H__
