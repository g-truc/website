#ifndef __ORANGE_OCORE_COMPONENT_MANAGER_H__
#define __ORANGE_OCORE_COMPONENT_MANAGER_H__

#include "factory.h"

namespace o {
namespace core {

interface IMessage
{
	IMessage(handle SenderId, handle TypeId);
	virtual ~IMessage(){}

	const handle TypeId;
	const handle SenderId;
	const handle MessageId;
};

interface IComponent : public CNonCopyable
{
	IComponent(handle ObjectId, handle TypeId);
	virtual ~IComponent(){}

	virtual bool HandleMessage(const IMessage* Message) = 0;

	const handle TypeId;
	const handle ObjectId;
	const handle ComponentId;
};

enum EBroadcastTarget
{
	TARGET_OBJECT,
	TARGET_COMPONENT,
	TARGET_TYPE
};

class CObjectManager : 
	public CAutoSingleton<CObjectManager>, 
	public CComponentFactory<std::string>
{
	friend class CAutoSingleton<CObjectManager>;

private:
	typedef std::multimap<handle, IComponent*> TObjectMap;
	typedef std::multimap<handle, IComponent*> TTypeMap;
	typedef std::map<handle, IComponent*> TComponentMap;
	typedef std::list<IComponent*> TReleaseList;

public:
	typedef TTypeMap::iterator iterator;
	typedef TTypeMap::const_iterator const_iterator;

public:
	void Broadcast(EBroadcastTarget Target, handle Index, const IMessage* Message);
	handle FindComponentId(handle ObjectId, handle TypeId);
	IComponent* CreateComponent(const std::string& Key, handle ObjectId, IParameter* Parameter);
	void ReleaseComponent(EBroadcastTarget Target, handle Index);
	const IComponent* GetComponent(handle ComponentId) const;
	IComponent* GetComponent(handle ComponentId);

	iterator Begin(handle TypeId);
	const_iterator Begin(handle TypeId) const;
	iterator End(handle TypeId);
	const_iterator End(handle TypeId) const;
	iterator Begin();
	const_iterator Begin() const;
	iterator End();
	const_iterator End() const;
	size_t Size() const;

private:
	CObjectManager();
	virtual ~CObjectManager();

	//! Send the message to each component whose type is TypeId
	void _BroadcastByType(handle TypeId, const IMessage* Message);
	//! Send the message to each components of a object  
	void _BroadcastByObject(handle ObjectId, const IMessage* Message);
	//! Send the message to the component whose identifier is ComponentId
	void _BroadcastByComponent(handle ComponentId, const IMessage* Message);
	//! Push all components of a type in the release list
	void _ReleaseByType(handle TypeId);
	//! Push all components of an object in the release list
	void _ReleaseByObject(handle ObjectId);
	//! Push the component identified by ComponentId in the release list
	void _ReleaseByComponent(handle ComponentId);
	//! Effectively delete all components in the release list
	void _ClearReleaseList();
	//! Effectively delete a component
	void _Clear();

	TTypeMap _TypeMap;
	TObjectMap _ObjectMap;
	TComponentMap _ComponentMap;
	TReleaseList _ReleaseList;
};

template <typename D>
CComponentCreator<D>* ComponentCreator();

template <typename D>
void ComponentRegister(const std::string& Name);

}//namespace core
}//namespace o

#include "manager.inl"

#endif//__ORANGE_OCORE_COMPONENT_MANAGER_H__