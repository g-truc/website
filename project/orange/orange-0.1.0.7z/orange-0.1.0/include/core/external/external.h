#ifndef __ORANGE_CORE_EXTERNAL_H__
#define __ORANGE_CORE_EXTERNAL_H__

#include "tinyxml/tinyxml.h"
#include "tinyxml/tinystr.h"

#endif//__ORANGE_CORE_EXTERNAL_H__
