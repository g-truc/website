#ifndef __ORANGE_CORE_RESOURCE_MESSAGE_H__
#define __ORANGE_CORE_RESOURCE_MESSAGE_H__

#include <core/pattern/pattern.h>

namespace o {
namespace core {

typedef std::map<int, std::string> TLangMap;

class CErrorMessage : public CAutoSingleton<CErrorMessage>
{
	friend class CAutoSingleton<CErrorMessage>;

public:
	void Read(const TLangMap& LangMap);
	virtual std::string Find(int Message) const;

private:
	CErrorMessage();
	~CErrorMessage();

	TLangMap _LangMap;
};

}//namespace core
}//namespace o

#endif//__ORANGE_CORE_RESOURCE_MESSAGE_H__
