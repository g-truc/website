#ifndef __ORANGE_CORE_RESOURCE_RESOURCE_H__
#define __ORANGE_CORE_RESOURCE_RESOURCE_H__

#include "manager.h"
#include "message.h"

#endif//__ORANGE_CORE_RESOURCE_RESOURCE_H__
