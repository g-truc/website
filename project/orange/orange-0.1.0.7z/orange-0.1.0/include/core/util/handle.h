#ifndef __ORANGE_BASE_UTIL_HANDLE_H__
#define __ORANGE_BASE_UTIL_HANDLE_H__

#include "../util/lang.h"

namespace o {
namespace core {

template<typename T>
class CHandle
{
public:
	CHandle();
	CHandle(const CHandle& Handle);

	bool operator==(const CHandle& Handle);
	bool operator!=(const CHandle& Handle);
	CHandle<T>& operator=(const CHandle<T>& Handle);

	operator const T() const;
	operator T();

	static CHandle<T> Null();

private:
	explicit CHandle(bool NotNull);

	T _Value;
	static T _Current;
};

}//namespace core
}//namespace o

typedef o::core::CHandle<uint32> handle;

#include "handle.inl"

#endif//__ORANGE_BASE_UTIL_HANDLE_H__
