#ifndef __ORANGE_BASE_UTIL_STATIC_TYPE_H__
#define __ORANGE_BASE_UTIL_STATIC_TYPE_H__

#include "lang.h"
#include "handle.h"

namespace o {
namespace core {

template <typename T>
interface IType
{
	static const handle Type;
};

}//namespace core
}//namespace o

#include "static_type.inl"

#endif//__ORANGE_BASE_UTIL_STATIC_TYPE_H__
