#ifndef __ORANGE_BASE_UTIL_UTIL_H__
#define __ORANGE_BASE_UTIL_UTIL_H__

#include "handle.h"
#include "lang.h"
#include "type.h"
#include "static_type.h"
#include "std.h"
#include "ref_info.h"

#endif//__ORANGE_BASE_UTIL_UTIL_H__
