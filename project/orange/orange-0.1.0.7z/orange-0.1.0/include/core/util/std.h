#ifndef __ORANGE_BASE_UTIL_STD_H__
#define __ORANGE_BASE_UTIL_STD_H__

#include <cstdio>
#include <cstring>
#include <cstdarg>
#include <cstddef>
#include <string>
#include <map>
#include <set>
#include <vector>
#include <list>
#include <fstream>

#endif//__ORANGE_BASE_UTIL_STD_H__
