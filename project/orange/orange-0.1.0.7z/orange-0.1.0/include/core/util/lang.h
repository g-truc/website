#ifndef __ORANGE_BASE_UTIL_LANG_H__
#define __ORANGE_BASE_UTIL_LANG_H__

#include <string>

#pragma warning (disable:4291)

#ifdef min
#undef min
#endif

#ifdef max
#undef max
#endif

// 13/06/2005 - interface : Nearly as in Java and C# but more adaptable, eg : interface ITruc;
#define interface struct
// 14/06/2005 - final : We mustn't derivate the class, eg : final class CTruc;
#define final
// 14/06/2005 - abstract : We mustn't instanciate the class, eg : abstract class CTruc;
#define abstract

#define self (*this)

// 14/06/2005 - A tag witch mean that the following declaration are public only to specific classes 
// eg : limited(Class)
#define limited(x) public

#define null 0
extern const float infinite;
extern const float epsilon;
extern const float pi;

namespace o {
namespace core {

std::string format(const char* msg, ...);
std::string subpath(const char* Source, int Depth);
bool isPowerOfTwo(int value);
// Useless thanks to memory macro
//void safeDeleteObject(void* pointer);
//void safeDeleteArray(void* pointer);
template <typename T> inline T* addressof(T& v);
std::string uppercase(const std::string& s);
std::string lowercase(const std::string& s);

}//namespace core
}//namespace o

#include "lang.inl"

#endif//__ORANGE_BASE_UTIL_LANG_H__
