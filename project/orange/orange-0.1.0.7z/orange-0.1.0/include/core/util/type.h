#ifndef __ORANGE_BASE_UTIL_TYPE_H__
#define __ORANGE_BASE_UTIL_TYPE_H__

#include <glm/glmext.h>

typedef glm::__halfGTX                  half;

typedef glm::__halfGTX                  float16;
typedef float                           float32;
typedef double                          float64;

typedef signed char                     int8;
typedef signed short                    int16;
typedef signed int                      int32;
typedef signed long long                int64;

typedef signed char                     sint8;
typedef signed short                    sint16;
typedef signed int                      sint32;
typedef signed long long                sint64;

typedef unsigned char                   uint8;
typedef unsigned short                  uint16;
typedef unsigned int                    uint32;
typedef unsigned long long              uint64;

typedef unsigned int                    flag;
typedef unsigned char                   flag8;
typedef unsigned short                  flag16;
typedef unsigned int                    flag32;
typedef unsigned long long              flag64;

typedef unsigned char                   byte;
typedef unsigned short                  word;
typedef unsigned int                    dword;
typedef unsigned long long              qword;

typedef unsigned char                   uchar;
typedef signed char                     schar;

typedef unsigned int                    uint;
typedef signed int                      sint;

typedef uint attribute;
typedef uint uniform;

#endif //__ORANGE_BASE_UTIL_TYPE_H__
