#ifndef __ORANGE_CORE_ASSET_ASSET_H__
#define __ORANGE_CORE_ASSET_ASSET_H__

#include "image.h"
#include "lang.h"

#endif//__ORANGE_CORE_ASSET_ASSET_H__
