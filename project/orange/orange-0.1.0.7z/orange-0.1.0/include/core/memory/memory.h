/*
========================================
 BUGS:
----------------------------------------
== Template makes the compiler crazy == 
If you are using a template classes with overloaded new operator, you will have lot of errors during the compilation.
For example:
template <typename T> class CClass {...};
CClass<int> Class = new_object(CClass<int>);

Unfortunately, this is wrong and you must do this:
template <typename T> class CClass {...};
typename CClass<int> TClassInt;
TClassInt Class = new_object(TClassInt);

=> ToDo: Check it out <=

========================================
*/

#ifndef __ORANGE_BASE_MEMORY_MEMORY_H__
#define __ORANGE_BASE_MEMORY_MEMORY_H__

#include "manager.h"

//#if(!defined(NDEBUG) || defined(DEBUG_MEMORY))
#if(defined(DEBUG_MEMORY))
#pragma warning(disable:4291)
#endif

#define SUBPATH_DEPTH 3

inline void* operator new(size_t Size, const char* File, int Line, const char* Type) 
{
	void* Pointer = malloc(Size);

	if(Pointer == null)
	{
		puts("ERROR: out of memory");
		return null;
	}

	std::string SubFile = o::core::subpath(File, SUBPATH_DEPTH);
	o::core::SMemoryInfo MemoryInfo(SubFile.c_str(), Line, Type, Size, Size);
	o::core::CMemoryManager::GetInstance()->New(Pointer, MemoryInfo);

	return Pointer;
}

inline void* operator new[](size_t Size, const char* File, int Line, const char* Type, size_t Element) 
{
	void* Pointer = malloc(Size);

	if(Pointer == null)
	{
		puts("ERROR: Out of memory");
		return null;
	}

	std::string SubFile = o::core::subpath(File, SUBPATH_DEPTH);
	o::core::SMemoryInfo MemoryInfo(SubFile.c_str(), Line, Type, Size / Element, Size);
	o::core::CMemoryManager::GetInstance()->New(Pointer, MemoryInfo);

	return Pointer;
}

//#if(!defined(NDEBUG) || defined(DEBUG_MEMORY))
#if(defined(DEBUG_MEMORY))
	#define new_object(Type)					new(__FILE__, __LINE__, #Type) Type
	#define new_array(Type, Size)				new(__FILE__, __LINE__, #Type, Size) Type[Size]
	#define delete_object(Object)				o::core::CMemoryManager::GetInstance()->Delete(Object); delete Object; Object = null
	#define delete_array(Array)					o::core::CMemoryManager::GetInstance()->Delete(Array); delete[] Array; Array = null
#else
	#define new_object(Type)					new Type
	#define new_array(Type, Size)				new Type[Size]
	#define delete_object(Object)				delete Object; Object = null
	#define delete_array(Array)					delete[] Array; Array = null
#endif
/*
#if(!defined(NDEBUG) || defined(DEBUG_MEMORY))
	#define new_object(Type)					new(__FILE__, __LINE__, #Type) Type
	//#define new_object(Type)					memory::_new_object<Type>(__FILE__, __LINE__, #Type)
	#define new_array(Type, Size)				new(__FILE__, __LINE__, #Type, Size) Type[Size]
	//#define new_array(Type, Size)				memory::_new_array<Type>(__FILE__, __LINE__, #Type, Size)
	#define new_custom(Type)					new Type
	#define delete_object(Object)				obase::CMemoryManager::GetInstance()->Delete(Object); delete Object; Object = null
	//#define delete_object(Object)				memory::_delete_object(Object); delete Object; Object = null
	#define delete_array(Array)					obase::CMemoryManager::GetInstance()->Delete(Array); delete[] Array; Array = null
	//#define delete_array(Array)					memory::_delete_array(Array); delete[] Array; Array = null
	#define delete_custom(Object)				memory::_delete_object(Object); delete Object; Object = null
	#define register_custom(Type, Pointer)		memory::_new_register(__FILE__, __LINE__, #Type, Pointer)
#else
	#define new_object(Type)					new Type
	#define new_array(Type, Size)				new Type[Size]
	#define new_register(Type)					new Type
	#define delete_object(Object)				delete Object; Object = null
	#define delete_array(Array)					delete[] Array; Array = null
	#define delete_custom(Object)				delete Object; Object = null
	#define register_custom(Type, Pointer)
#endif
*/
#endif//__ORANGE_BASE_MEMORY_MEMORY_H__
