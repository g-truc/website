#ifndef __ORANGE_BASE_MEMORY_MANAGER_H__
#define __ORANGE_BASE_MEMORY_MANAGER_H__

#include "../pattern/auto_singleton.h"

namespace o {
namespace core {

struct SMemoryInfo
{
	SMemoryInfo(const std::string& Filename, int Line, const std::string& Typename, size_t TypeSize, size_t FullSize);

	std::string Filename;
	int Line;
	std::string Typename;
	size_t TypeSize;
	size_t FullSize;
};

class CMemoryManager : public CAutoSingleton<CMemoryManager>
{
	friend class CAutoSingleton<CMemoryManager>;

private:
	typedef std::map<const void* const, SMemoryInfo> TMemoryMap;

public:
	typedef TMemoryMap::const_iterator const_iterator;

public:
	void New(void* const Pointer, const SMemoryInfo& MemoryInfo);
	void New(const void* const Pointer, const SMemoryInfo& MemoryInfo);
	void Delete(void* const Pointer);
	void Delete(const void* const Pointer);
	size_t GetSize() const;

	const_iterator Begin() const;
	const_iterator End() const;

private:
	TMemoryMap MemoryMap;
};

}//namespace core
}//namespace o

#endif//__ORANGE_BASE_MEMORY_MANAGER_H__
