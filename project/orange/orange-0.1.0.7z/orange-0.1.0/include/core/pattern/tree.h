#ifndef __ORANGE_BASE_PATTERN_TREE_H__
#define __ORANGE_BASE_PATTERN_TREE_H__

#include <core/util/util.h>

namespace o {
namespace core {

class CTree
{
public:
    CTree();
	CTree(CTree* Parent);
	virtual ~CTree();

    handle Name() const;
	CTree* Parent() const;
	CTree* FristChild() const;
	CTree* PrevSibling() const;
	CTree* NextSibling() const;
	bool IsRoot() const;
	bool IsLeaf() const;
	bool IsFirstChild() const;
	bool IsLastChild() const;
	void Attach(CTree* Parent);
	void Insert(CTree* Child);
	void Detach();
	int Count() const; //!< Number of nodes in the subtree.
    CTree* Find(handle Name);
    void Release();

private:
    handle _Name;
	CTree* _Parent;
    CTree* _FristChild;
    CTree* _Prev;
    CTree* _Next;
};

}//namespace core
}//namespace o

#endif//__ORANGE_BASE_PATTERN_TREE_H__
