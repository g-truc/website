#ifndef __ORANGE_BASE_PATTERN_NONCOPYABLE_H__
#define __ORANGE_BASE_PATTERN_NONCOPYABLE_H__

namespace o {
namespace core {

    class CNonCopyable
    {
    protected:
        CNonCopyable(){}
        ~CNonCopyable(){}

    private:
        CNonCopyable(const CNonCopyable&);
        CNonCopyable& operator=(const CNonCopyable&);
    };

}//namespace core
}//namespace o

#endif//__ORANGE_BASE_PATTERN_NONCOPYABLE_H__
