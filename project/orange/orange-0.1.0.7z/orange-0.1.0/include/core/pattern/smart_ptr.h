#ifndef __ORANGE_PATTERN_SMART_PTR_H__
#define __ORANGE_PATTERN_SMART_PTR_H__

namespace o {
namespace core {

template <typename T, bool Array = false>
class CSmartPtr
{
public:
    CSmartPtr();
    CSmartPtr(const CSmartPtr& SmartPtr);
    CSmartPtr(T* Pointer);
    ~CSmartPtr();

    T& operator*();
    T* operator->();
    const T& operator*() const;
    const T* operator->() const;
    CSmartPtr& operator=(const CSmartPtr& SmartPtr);
    CSmartPtr& operator=(T* Pointer);
	bool operator==(const CSmartPtr& SmartPtr) const;
	bool operator!=(const CSmartPtr& SmartPtr) const;

private:
	void _Release();

    int* _RefCounter;
    T* _Pointer;
};

}//namespace core
}//namespace o

#include "smart_ptr.inl"

#endif //__ORANGE_PATTERN_SMART_PTR_H__
