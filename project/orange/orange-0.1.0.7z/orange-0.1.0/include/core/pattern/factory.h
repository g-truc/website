///////////////////////////////////////////////////////////////////////////
// USE SAMPLE
// struct A{};
// struct B : public A{};
// struct C : public A{};
// util::CAbstractFactory<int, A> Factory;
// Factory.Register(1, util::creator<A, B>());
// Factory.Register(2, util::creator<A, C>());
// A* pB = Factory.Create(1);
// A* pC = Factory.Create(2);
// Factory.Destroy(pB);
// Factory.Destroy(pC);
// Factory.UnRegister(1);
///////////////////////////////////////////////////////////////////////////

#ifndef __ORANGE_BASE_PATTERN_FACTORY_H__
#define __ORANGE_BASE_PATTERN_FACTORY_H__

#include <core/util/lang.h>
#include <core/memory/memory.h>
#include "noncopyable.h"

namespace o {
namespace core {

    template <typename base>
    interface ICreator
    {
        virtual base* Create() = 0;
        virtual bool Destroy(base*) = 0;
    };

    template<typename K, typename B>
    class CAbstractFactory;

    template <typename B, typename D>
    class CCreator : public ICreator<B>
    {
    public:
        CCreator();
        virtual ~CCreator();

        virtual B* Create();
        virtual bool Destroy(B* pObject);
    };

    template<typename K, typename B>
	class CAbstractFactory : public CNonCopyable
    {
        typedef typename std::map<K, ICreator<B>*> TCreatorsMap;
        typedef typename std::map<K, ICreator<B>*>::iterator TCreatorsIt;
        typedef typename std::map<K, ICreator<B>*>::const_iterator TCreatorsCit;

    public:
        CAbstractFactory();
        virtual ~CAbstractFactory();
        bool Register(K Key, ICreator<B>* pCreator);
        bool UnRegister(K Key);
        B* CreateObject(K Key) const;
        bool DestroyObject(B* pObject);

    protected:
        TCreatorsMap CreatorsMap;
    };

    template <typename base, typename derived>
    CCreator<base, derived>* creator();

}//namespace core
}//namespace o

#include "factory.inl"

#endif //__ORANGE_BASE_PATTERN_FACTORY_H__
