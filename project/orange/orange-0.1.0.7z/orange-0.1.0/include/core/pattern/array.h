#ifndef __ORANGE_BASE_PATTERN_ARRAY_H__
#define __ORANGE_BASE_PATTERN_ARRAY_H__

namespace o {
namespace core {

	template <typename T, size_t N> 
	class CArray
	{
	public:
		CArray();
		CArray(const T& Value);
		CArray(T* Data, size_t Size);
		//~CArray();

		T& operator[](size_t i);
		const T& operator[](size_t i) const;

        operator T*();
	    operator const T*() const;

		size_t GetSize() const {return N;}

	private:
		T _Data[N];
	};

}//namespace core
}//namespace o

#include "array.inl"

#endif//__ORANGE_BASE_PATTERN_ARRAY_H__
