#ifndef __ORANGE_BASE_MATH_MATH_H__
#define __ORANGE_BASE_MATH_MATH_H__

#include "type.h"
#include "rand.h"

#endif//__ORANGE_BASE_MATH_MATH_H__
