#ifndef __ORANGE_BASE_MATH_TYPE_H__
#define __ORANGE_BASE_MATH_TYPE_H__

#include <glm/glmext.h>

using glm::vec2;
using glm::vec3;
using glm::vec4;

typedef glm::__hvec2GTX hvec2;
typedef glm::__hvec3GTX hvec3;
typedef glm::__hvec4GTX hvec4;

typedef glm::vec2 fvec2;
typedef glm::vec3 fvec3;
typedef glm::vec4 fvec4;

typedef glm::__dvec2GTX dvec2;
typedef glm::__dvec3GTX dvec3;
typedef glm::__dvec4GTX dvec4;

using glm::ivec2;
using glm::ivec3;
using glm::ivec4;

using glm::bvec2;
using glm::bvec3;
using glm::bvec4;

using glm::mat2;
using glm::mat3;
using glm::mat4;

typedef glm::__hmat2GTX hmat2;
typedef glm::__hmat3GTX hmat3;
typedef glm::__hmat4GTX hmat4;

typedef glm::mat2 fmat2;
typedef glm::mat3 fmat3;
typedef glm::mat4 fmat4;

typedef glm::__dmat2GTX dmat2;
typedef glm::__dmat3GTX dmat3;
typedef glm::__dmat4GTX dmat4;

typedef glm::__quatGTX quat;
typedef glm::__hquatGTX hquat;
typedef glm::__quatGTX fquat;
typedef glm::__dquatGTX dquat;

#endif//__ORANGE_BASE_MATH_TYPE_H__
