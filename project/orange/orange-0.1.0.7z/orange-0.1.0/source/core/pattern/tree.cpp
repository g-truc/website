#include <core/precompiled.h>
#include <core/pattern/tree.h>

namespace o {
namespace core {

CTree::CTree() :
    _Parent(null), 
    _FristChild(null), 
    _Prev(null), 
    _Next(null)
{}

CTree::CTree(CTree* Parent) : 
    _Parent(null), 
    _FristChild(null), 
    _Prev(null), 
    _Next(null)
{
	Attach(Parent);
}

CTree::~CTree()
{
	if(_FristChild)
		delete_object(_FristChild);

	if(_Next)
		delete_object(_Next);
}

handle CTree::Name() const
{
    return _Name;
}

CTree* CTree::Parent() const
{
	return _Parent;
}

CTree* CTree::FristChild() const
{
	return _FristChild;
}

CTree* CTree::PrevSibling() const
{
	return _Prev;
}

CTree* CTree::NextSibling() const
{
	return _Next;
}

bool CTree::IsRoot() const
{
	return _Parent == null;
}

bool CTree::IsLeaf() const
{
	return _FristChild == null;
}

bool CTree::IsFirstChild() const
{
    if(_Parent)
	    return _Parent->_FristChild == this;
    return false;
}

bool CTree::IsLastChild() const
{
	return _Next == null;
}

void CTree::Attach(CTree* Parent)
{
	if(!IsRoot())
        Detach();

	_Parent = Parent;
	if(!_Parent->IsLeaf())
    {
        _Next = _Parent->_FristChild;
        _Parent->_FristChild->_Prev = this;
    }
	_Parent->_FristChild = this;
}

void CTree::Insert(CTree* Child)
{
	if(!Child->IsRoot())
        Child->Detach();

	Child->_Parent = this;
	if(!IsLeaf())
    {
        Child->_Next = _FristChild;
        _FristChild->_Prev = Child;
    }
	_FristChild = Child;
}

void CTree::Detach()
{
	if(IsFirstChild())
        _Parent->_FristChild = _Next;

	if(_Prev)
        _Prev->_Next = _Next;

    if(_Next)
        _Next->_Prev = _Prev;

    _Prev = _Next = null;
}

int CTree::Count() const
{
	if(IsLeaf() && IsLastChild())
        return 1;

    int Count = _FristChild->Count() + 1;

	if(!IsLastChild())
        Count += _Next->Count();
	return Count;
}

CTree* CTree::Find(handle Name)
{
	if(_Name == Name)
        return this;

	CTree* Adress = null;
	if(!IsLeaf())
        Adress = _FristChild->Find(Name);

	if(Adress != null)
		return Adress;
	else if(!IsLastChild())
        return _Next->Find(Name);
	else 
        return null;
}

void CTree::Release()
{
    CTree* Node = _FristChild;
    while(Node != null)
    {
        Node->Release();
        CTree* Temp = Node->NextSibling();
        delete_object(Node);
        Node = Temp;
    }
    _FristChild = null;
}

}//namespace core
}//namespace o
