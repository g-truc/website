#include <core/precompiled.h>
#include <core/math/rand.h>
#include <core/util/util.h>

namespace o {
namespace core {

float32 rand()
{
	return 2.0f * (std::rand() - RAND_MAX / 2) / float32(RAND_MAX);
}

float32 rand(float32 fMin, float32 fMax)
{
	return (std::rand() / float32(RAND_MAX) * (fMax - fMin)) + fMin;
}

int32 rand(int32 iMin, int32 iMax)
{
	return int32(std::rand() / (float32(RAND_MAX)) * (iMax + 1 - iMin)) + iMin;
}

vec2 rand2()
{
	float a = core::rand(0.0f, pi);
	return vec2(glm::cos(a), glm::sin(a));
}

vec3 rand3()
{
	float z = core::rand(-1.0f, 1.0f);
	float a = core::rand(0.0f, pi);

	float r = glm::sqrt(1.0f - z * z);

	float x = r * glm::cos(a);
	float y = r * glm::sin(a);

	return vec3(x, y, z);
}

}//namespace core
}//namespace o
