// Comment: It mustn't have some numbered packs left between the first and the last

#include <core/precompiled.h>
#include <core/resource/manager.h>
#include <core/resource/reader_local.h>
#include <core/resource/reader_7z.h>

namespace o {
namespace core {

// CResource
CResource::CResource(const std::string& Filename, const void* Buffer, const size_t Size) :
	CFileDesc(Filename, Size),
	_Buffer(Buffer)
{}

CResource::~CResource()
{
	delete_array(_Buffer);
}

// CResourceManager
CResourceManager::CResourceManager() :
	_ReaderLocal(new_object(CReaderLocal)),
	_Reader7z(new_object(CReader7z))
{}

CResourceManager::~CResourceManager()
{
	if(!_AssetMap.empty())
	{
		Clear();
		//orange_warning(!_AssetMap.empty(), "All assets haven't been released before program end");
	}

	if(_ReaderLocal != null)
		delete_object(_ReaderLocal);
	if(_Reader7z != null)
		delete_object(_Reader7z);
}

IAsset* CResourceManager::FindAsset(const std::string& Filename)
{
	IAsset* Asset = null;

	if((Asset = _SearchAssetInstance(Filename)) != null)
		return Asset;

	if((Asset = _LoadAssetInstance(Filename)) != null)
		return Asset;

	//o_error(Asset == null, format("File not found %s", Filename.c_str()).c_str());
	return null;
}

void CResourceManager::ReleaseAsset(IAsset* Asset)
{
	TAssetMapAccess::iterator it = _AssetMapAccess.find(Asset);
	SAssetInfo& Info = _AssetMap.find(it->second->first)->second;
	++Info.DeleteCount;

	if(Info.NewCount - Info.DeleteCount == 0)
	{
		delete_object(Info.Pointer);
		_AssetMap.erase(it->second);
		_AssetMapAccess.erase(it);
	}
}

void CResourceManager::Clear()
{
	for(TAssetMap::iterator it = _AssetMap.begin(); it != _AssetMap.end(); ++it)
		delete_object(it->second.Pointer);
}

IAsset* CResourceManager::_SearchAssetInstance(const std::string& Filename)
{
	TAssetMap::iterator it = _AssetMap.find(Filename);
	if(it != _AssetMap.end())
	{
		++(it->second.NewCount);
		return it->second.Pointer; // Asset found
	}

	return null; // Asset not found
}

IAsset* CResourceManager::_LoadAssetInstance(const std::string& Filename)
{
	PResource Resource = null;

	if(Resource == null)
		Resource = _ReaderLocal->Load(Filename);

	if(Resource == null)
		Resource = _Reader7z->Load(Filename);

	if(Resource == null)
		return null;

	std::string Extension = Resource->GetExtension().c_str();
	IAsset* Asset = CreateObject(Extension.c_str());
	if(Asset == null)
		return null;

	std::pair<TAssetMap::iterator, bool> it = _AssetMap.insert(std::make_pair(Filename, SAssetInfo(Asset)));
	_AssetMapAccess.insert(std::make_pair(Asset, it.first));
	Asset->Load(Resource);

	//Not need smart pointer take care of this memory
	//delete_object(Resource);

	return Asset;
}

}//namespace core
}//namespace o
