#include <core/precompiled.h>
#include <core/util/lang.h>

#define STRING_BUFFER 2048

const float infinite = 1e37f;
const float epsilon = 0.00001f;
const float pi = 3.1415926535897932384626433832795f;

namespace o {
namespace core {

std::string format(const char* msg, ...)
{
	char text[STRING_BUFFER];
	va_list list;

	if(msg == 0)
		return std::string();

	va_start(list, msg);
		vsprintf(text, msg, list);
	va_end(list);

	return std::string(text);
}

std::string subpath(const char* Source, int Depth)
{
	int CurrentDepth = 0;
	for(size_t i = strlen(Source) - 1; i >= 0; --i)
	{
		if(Source[i] != '\\' && Source[i] != '/')
			continue;
		++CurrentDepth;
		if(CurrentDepth == Depth)
			return std::string(Source + i + 1);
	}
	return std::string();
}

// Make an uppercase copy of s
std::string uppercase(const std::string& s)
{
	std::string upper(s);
	for(size_t i = 0; i < s.length(); ++i)
		upper[i] = toupper(upper[i]);
	return upper;
}

// Make a lowercase copy of s
std::string lowercase(const std::string& s)
{
	std::string lower(s);
	for(size_t i = 0; i < s.length(); ++i)
		lower[i] = tolower(lower[i]);
	return lower;
}

}//namespace core
}//namespace o
