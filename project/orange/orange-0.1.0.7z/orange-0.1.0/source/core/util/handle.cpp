#include <core/precompiled.h>
#include <core/util/handle.h>

namespace o {
namespace core {

}//namespace core
}//namespace o
