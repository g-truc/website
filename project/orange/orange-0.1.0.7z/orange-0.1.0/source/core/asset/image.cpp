#include <core/precompiled.h>
#include <core/asset/image.h>
#include <core/error/error.h>

namespace o {
namespace core {

class CImageTGA;
class CImageDDS;

// CImage
CImage::CImage() :
    Data(null),
    Width(0),
    Height(0),
    Mipmaps(0),
    Components(0),
	Loaded(false),
    Format(IMAGE_NONE)
{}

CImage::~CImage()
{
	if(Data != null)
		delete_array(Data);
}

CImage* CImage::Create(const std::string& Filename)
{
	RegisterAsset<CImageTGA>("tga");
	RegisterAsset<CImageDDS>("dds");

	IAsset* Asset = CResourceManager::GetInstance()->FindAsset(Filename);

	o_error(Asset == null, format("Loading of %s failed", Filename).c_str());
	// Todo: o_error(Asset->Type() != CImage::Type, format("Loading of %s failed", Filename).c_str());

	//return reinterpret_cast<CImage*>(Asset);
	return static_cast<CImage*>(Asset);
}

void CImage::Release(CImage* Asset)
{
	CResourceManager::GetInstance()->ReleaseAsset(Asset);
}

// SHeaderTGA struct declaration
#pragma pack(push, 1)
struct SHeaderTGA
{
	uint8 IdentificationFieldSize;
	uint8 ColorMapType;
	uint8 ImageType;
	uint16 ColorMapOrigin;
	uint16 ColorMapLength;
	uint8 ColorMapEntrySize;
	uint16 OriginX;
	uint16 OriginY;
	uint16 Width;
	uint16 Height;
	uint8 TexelSize;
	uint8 Descriptor;
};
#pragma pack(pop)

// CImageTGA
class CImageTGA : public CImage
{
public:
	virtual bool Load(const PResource& Resource);

private:
	EImageFormat _Format(uint ImageType);
};

bool CImageTGA::Load(const PResource& Resource)
{
	if(Resource == null)
		return false;

	const char* const ResourceData = static_cast<const char* const>(Resource->GetBuffer());
	int Offset = 0;

	// Read TGA image header 
	SHeaderTGA Header;
	memcpy(&Header, ResourceData + Offset, sizeof(SHeaderTGA));
	Offset += sizeof(SHeaderTGA);

	// Save needed header information
	Width = Header.Width;
	Height = Header.Height;
	Mipmaps = 1;
	Components = Header.TexelSize >> 3;
	Format = _Format(Header.ImageType);

	// Allocate memory to texels information
	uint32 Size = Width * Height * Components;
	Data = new_array(byte, Size);
	//Offset += 18 + Header.ColorMapLength + Header.IdentificationFieldSize;
	Offset += Header.ColorMapLength + Header.IdentificationFieldSize;

	o_error(Data == null, "Not enough memory")

	memcpy(Data, ResourceData + Offset, Size * sizeof(byte));

	return Loaded = true;
}

EImageFormat CImageTGA::_Format(uint ImageType)
{
	switch(ImageType)
	{
	default:
		//fprintf(stderr, "Unkowned file format");
		return IMAGE_NONE;
	case 2: //Uncompressed 24, 32 bits
		switch(Components)
		{
		case 3: return IMAGE_BGR;
		case 4: return IMAGE_BGRA;
		default: return IMAGE_NONE;
		};
		break;
	case 3: //Uncompressed 8, 16 bits
		switch(Components)
		{
		case 1: return IMAGE_LUMINANCE;
		case 2: return IMAGE_LUMINANCE_ALPHA;
		default: return IMAGE_NONE;
		};
		break;
/*
	case 10: //Compressed 24, 32 bits
		switch(components)
		{
		case 3: return IMAGE_BGR;
		case 4: return IMAGE_BGRA;
		default: return IMAGE_NONE;
		};
		break;
	case 11: //Compressed 8, 16 bits
		switch(components)
		{
		case 1: return IMAGE_LUMINANCE;
		case 2: return IMAGE_LUMINANCE_ALPHA;
		default: return IMAGE_NONE;
		};
		break;
*/
	}
}

// SHeaderDDS struct declaration
#pragma pack(push, 1)
struct SHeaderDDS
{
	uint32 Size;
	uint32 Flags;
	uint32 Height;
	uint32 Width;
	uint32 Pitch;
	uint32 Depth;
	uint32 MipMapLevels;
	uint32 Reserved1[11];

	uint32 PixelSize;
	uint32 PixelFlags;
	uint32 FourCC;
	uint32 BitCount;
	uint32 ColorMask[4];

	uint32 Caps[2];
	uint32 Reserved2[2];

	uint32 Reserved3;
};
#pragma pack(pop)

enum
{
	DDSD_CAPS			= 0x00000001,
	DDSD_HEIGHT			= 0x00000002, 
	DDSD_WIDTH			= 0x00000004,
	DDSD_PITCH			= 0x00000008,
	DDSD_PIXELFORMAT	= 0x00001000,
	DDSD_MIPMAPCOUNT	= 0x00020000,
	DDSD_LINEARSIZE		= 0x00080000,
	DDSD_DEPTH			= 0x00800000
};

enum
{
	DDPF_ALPHAPIXELS	= 0x00000001,
	DDPF_FOURCC			= 0x00000004,
	DDPF_RGB			= 0x00000040
};

enum
{
	DDSCAPS_COMPLEX		= 0x00000008,
	DDSCAPS_TEXTURE		= 0x00001000,
	DDSCAPS_MIPMAP		= 0x00400000
};

enum
{
	DDSCAPS2_CUBEMAP			= 0x00000200,
	DDSCAPS2_CUBEMAP_POSITIVEX	= 0x00000400,
	DDSCAPS2_CUBEMAP_NEGATIVEX	= 0x00000800,
	DDSCAPS2_CUBEMAP_POSITIVEY	= 0x00001000,
	DDSCAPS2_CUBEMAP_NEGATIVEY	= 0x00002000,
	DDSCAPS2_CUBEMAP_POSITIVEZ	= 0x00004000,
	DDSCAPS2_CUBEMAP_NEGATIVEZ	= 0x00008000,
	DDSCAPS2_VOLUME				= 0x00200000
};

#ifndef MAKEFOURCC
#define MAKEFOURCC(ch0, ch1, ch2, ch3)		\
(											\
	((uint32(ch3) << 24) & 0xFF000000) |	\
	((uint32(ch2) << 16) & 0x00FF0000) |	\
	((uint32(ch1) <<  8) & 0x0000FF00) |	\
	((uint32(ch0) <<  0) & 0x000000FF)		\
)
#endif

#define FOURCC_DXT1	MAKEFOURCC('D', 'X', 'T', '1')
#define FOURCC_DXT3	MAKEFOURCC('D', 'X', 'T', '3')
#define FOURCC_DXT5	MAKEFOURCC('D', 'X', 'T', '5')

// CImageDDS
class CImageDDS : public CImage
{
public:
	virtual bool Load(const PResource& Resource);

private:
	EImageFormat _Format(uint ImageType);
};

bool CImageDDS::Load(const PResource& Resource)
{
	if(Resource == null)
		return false;

	const char* const ResourceData = static_cast<const char* const>(Resource->GetBuffer());
	int Offset = 0;
	o_error(strncmp(ResourceData + Offset, "DDS ", 4) != 0, format("%s isn't a DDS image", Resource->GetFilename().c_str()).c_str());
	
	Offset += 4;
	SHeaderDDS Header;
	memcpy(&Header, ResourceData + Offset, sizeof(SHeaderDDS));

	Width = Header.Width;
	Height = Header.Height;
	Mipmaps = uint8(Header.MipMapLevels);
	Components = Header.FourCC == FOURCC_DXT1 ? 3 : 4;
	Format = _Format(Header.FourCC);

	o_error(Format == IMAGE_NONE, format("DDS loader can't load %s, format unknown, use DXT1, DXT3, or DXT5\n", Resource->GetFilename().c_str()).c_str())

	Offset += sizeof(SHeaderDDS);
	int Factor = Format == IMAGE_DXT1 ? 2 : 4;
	uint32 Size = Header.MipMapLevels > 1 ? Header.Pitch * Factor : Header.Pitch;
	Data = new_array(byte, Size);

	o_error(Data == null, "Not enough memory")

	memcpy(Data, ResourceData + Offset, Size * sizeof(byte));

	return Loaded = true;
}

EImageFormat CImageDDS::_Format(uint ImageType)
{
	switch(ImageType)
	{
	case FOURCC_DXT1: return IMAGE_DXT1;
	case FOURCC_DXT3: return IMAGE_DXT3;
	case FOURCC_DXT5: return IMAGE_DXT5;
	default: return IMAGE_NONE;
	}
}

}//namespace core
}//namespace o
