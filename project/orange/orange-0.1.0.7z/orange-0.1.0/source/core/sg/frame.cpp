#include <core/precompiled.h>
#include <core/sg/frame.h>

namespace o {
namespace core {

CFrame::CFrame() :
    _WorldFlag(null),
    _ModelFlag(null),
    _Updated(true)
{}

CFrame::CFrame(CFrame* Parent) :
    CTree(Parent),
    _WorldFlag(null),
    _ModelFlag(null),
    _Updated(true)
{}

void CFrame::WorldTranslate(const vec3& Displacement)
{
    _WorldFlag |= TRANSLATION;
    _WorldTranslation += Displacement;
    _NotifyUpdated();
}

void CFrame::WorldPosition(const vec3& Position)
{
    _WorldFlag |= TRANSLATION;
    _WorldTranslation = Position;
    _NotifyUpdated();
}

void CFrame::WorldRotate(const quat& Rotation)
{
    _WorldFlag |= ROTATION;
    _WorldOrientation = glm::cross(_WorldOrientation, Rotation);
    _NotifyUpdated();
}

void CFrame::WorldOrientation(const quat& Orientation)
{
    _WorldFlag |= ROTATION;
    _WorldOrientation = Orientation;
    _NotifyUpdated();
}

void CFrame::WorldScaleAjust(const vec3& ScaleVariation)
{
    _WorldFlag |= SCALING;
    _WorldScaling += ScaleVariation;
    _NotifyUpdated();
}

void CFrame::WorldScale(const vec3& Scale)
{
    _WorldFlag |= SCALING;
    _WorldScaling = Scale;
    _NotifyUpdated();
}

void CFrame::WorldReflection(const vec3& ReflectNormal)
{
    if(glm::length(ReflectNormal) > epsilon)
        _WorldFlag |= REFLECTION;
    else
        _WorldFlag &= ~REFLECTION;
    _WorldReflectNormal = ReflectNormal;
}

void CFrame::ModelTranslate(const vec3& Displacement)
{
    _ModelFlag |= TRANSLATION;
    _ModelTranslation += Displacement;
    _NotifyUpdated();
}

void CFrame::ModelPosition(const vec3& Position)
{
    _ModelFlag |= TRANSLATION;
    _ModelTranslation = Position;
    _NotifyUpdated();
}

void CFrame::ModelRotate(const quat& Rotation)
{
    _ModelFlag |= ROTATION;
    _ModelOrientation = glm::cross(_ModelOrientation, Rotation);
    _NotifyUpdated();
}

void CFrame::ModelOrientation(const quat& Orientation)
{
    _ModelFlag |= ROTATION;
    _ModelOrientation = Orientation;
    _NotifyUpdated();
}

void CFrame::ModelScaleAjust(const vec3& ScaleVariation)
{
    _ModelFlag |= SCALING;
    _ModelScaling += ScaleVariation;
    _NotifyUpdated();
}

void CFrame::ModelScale(const vec3& Scale)
{
    _ModelFlag |= SCALING;
    _ModelScaling = Scale;
    _NotifyUpdated();
}

void CFrame::ModelReflection(const vec3& ReflectNormal)
{
    if(glm::length(ReflectNormal) > epsilon)
        _ModelFlag |= REFLECTION;
    else
        _ModelFlag &= ~REFLECTION;
    _ModelReflectNormal = ReflectNormal;
}

void CFrame::_Update()
{
    // World transformation
    _WorldTransformation = mat4(1.0f);
    if(_WorldFlag != null)
    {
        if(_WorldFlag & TRANSLATION)
            _WorldTransformation = glm::translate3DGTX(_WorldTransformation, _WorldTranslation);

        if(_WorldFlag & ROTATION)
            _WorldTransformation *= mat4GTX(_WorldOrientation);

        if(_WorldFlag & SCALING)
            _WorldTransformation = glm::scale3DGTX(_WorldTransformation, _WorldScaling);

        if(_WorldFlag & REFLECTION)
            _WorldTransformation = glm::reflect3DGTX(_WorldTransformation, _WorldReflectNormal);
/*
        if(_WorldFlag & SHEARING)
        {
            _WorldTransformation = glm::shear3DXGTX(_WorldTransformation, );
            _WorldTransformation = glm::shear3DYGTX(_WorldTransformation, );
            _WorldTransformation = glm::shear3DZGTX(_WorldTransformation, );
        }
*/
    }

    // Model transformation
    _ModelTransformation = mat4(1.0f);
    if(_ModelFlag != null)
    {
        if(_ModelFlag & TRANSLATION)
            _ModelTransformation = glm::translate3DGTX(mat4(1.0f), _ModelTranslation);

        if(_ModelFlag & ROTATION)
            _ModelTransformation *= mat4GTX(_ModelOrientation);

        if(_ModelFlag & SCALING)
            _ModelTransformation = glm::scale3DGTX(_ModelTransformation, _ModelScaling);

        if(_ModelFlag & REFLECTION)
            _ModelTransformation = glm::reflect3DGTX(_ModelTransformation, _ModelReflectNormal);
/*
        if(_ModelFlag & SHEARING)
        {
            _ModelTransformation = glm::shear3DXGTX(_ModelTransformation, );
            _ModelTransformation = glm::shear3DYGTX(_ModelTransformation, );
            _ModelTransformation = glm::shear3DZGTX(_ModelTransformation, );
        }
*/
    }

    if(!IsRoot())
    {
        if(static_cast<CFrame*>(Parent())->_Updated)
            static_cast<CFrame*>(Parent())->_Update();
        _WorldTransformation = static_cast<CFrame*>(Parent())->_WorldTransformation * _WorldTransformation;
    }

    _Transform = _WorldTransformation * _ModelTransformation,
    _Position = _Transform * vec4(0, 0, 0, 1);
    _Updated = false;
}

mat4 CFrame::Transform()
{
    if(_Updated)
        _Update();

    return _Transform;
}

void CFrame::_NotifyUpdated()
{
    _Updated = true;
    if(IsLeaf())
        return;

    CFrame* pFrame = static_cast<CFrame*>(FristChild());
    do
    {
        pFrame->_NotifyUpdated();
    }
    while(pFrame = static_cast<CFrame*>(pFrame->NextSibling()));
}

}//namespace core
}//namespace o
