#ifndef __ORANGE_H__
#define __ORANGE_H__

#include "core/precompiled.h"
#include "core/asset/asset.h"
#include "core/component/component.h"
#include "core/error/error.h"
#include "core/math/math.h"
#include "core/memory/memory.h"
#include "core/pattern/pattern.h"
#include "core/resource/resource.h"
#include "core/sg/sg.h"
#include "core/util/util.h"

#endif//__ORANGE_H__
