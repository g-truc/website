#ifndef __ORANGE_CORE_ASSET_LANG_H__
#define __ORANGE_CORE_ASSET_LANG_H__

#include <core/util/util.h>
#include <core/resource/resource.h>
#include <core/external/tinyxml/tinyxml.h>

namespace o {
namespace core {

class CLang : public IAsset, public IType<CLang>
{
	friend class CCreator<IAsset, CLang>;

public:
	static CLang* Create(const std::string& Filename);
	static void Release(CLang* Asset);

	virtual bool Load(const PResource& Resource);
	virtual handle GetType() const{return CLang::Type;}

	std::string Find(int Message) const;
	const TLangMap& GetLangMap() const {return _LangMap;}

private:
	CLang();
	virtual ~CLang();
	
	void _ReadLangElement(TiXmlElement* Element);

	TLangMap _LangMap;
};

}//namespace core
}//namespace o

#endif//__ORANGE_CORE_ASSET_LANG_H__
