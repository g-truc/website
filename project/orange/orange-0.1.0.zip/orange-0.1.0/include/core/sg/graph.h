#ifndef __ORANGE_CORE_SG_GRAPH_H__
#define __ORANGE_CORE_SG_GRAPH_H__

#include "frame.h"

namespace o {
namespace core {

class CSceneGraph
{
public:
    CSceneGraph();
    ~CSceneGraph();

    //! if Parent is null then the parent node is the root node
    CFrame* Create(CFrame* Parent = null);
    //! if ParentName is null then the parent node is the root node
    handle CreateByHandle(handle ParentName);
    //! Destroy Node and all its children
    void Destroy(CFrame* Frame);
    //! Destroy NodeName and all its children
    void DestroyByHandle(handle NodeName);
    //! free all nodes
    void Clear();

private:
    CFrame* _Root;
};

}//namespace core
}//namespace o

#endif//__ORANGE_CORE_SG_GRAPH_H__
