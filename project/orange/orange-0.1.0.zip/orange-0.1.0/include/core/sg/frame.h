#ifndef __ORANGE_CORE_SG_FRAME_H__
#define __ORANGE_CORE_SG_FRAME_H__

#include <core/util/util.h>
#include <core/pattern/pattern.h>

namespace o {
namespace core {

class CFrame : public CTree
{
private:
    enum
    {
        TRANSLATION = (1 << 0),
        ROTATION = (1 << 1),
        SCALING = (1 << 2),
        SHEARING = (1 << 3),
        REFLECTION = (1 << 4)
    };

public:
    CFrame();
    CFrame(CFrame* Parent);
    virtual ~CFrame(){}

    void WorldTranslate(const vec3& Displacement);
    void WorldPosition(const vec3& Position);
    void WorldRotate(const quat& Rotation);
    void WorldOrientation(const quat& Orientation);
    void WorldScaleAjust(const vec3& ScaleVariation);
    void WorldScale(const vec3& Scale);
    void WorldReflection(const vec3& ReflectNormal);

    void ModelTranslate(const vec3& Displacement);
    void ModelPosition(const vec3& Position);
    void ModelRotate(const quat& Rotation);
    void ModelOrientation(const quat& Orientation);
    void ModelScaleAjust(const vec3& ScaleVariation);
    void ModelScale(const vec3& Scale);
    void ModelReflection(const vec3& ReflectNormal);

    mat4 Transform();
    vec3 GetForward() const{return _WorldOrientation * vec3(0.f, 1.f, 0.f);}
    vec3 GetStrafe() const{return _WorldOrientation * vec3(1.f, 0.f, 0.f);}
    vec3 GetUp() const{return _WorldOrientation * vec3(0.f, 0.f, 1.f);}
    vec4 Position() const{return _Position;}

private:
    void _NotifyUpdated();
    void _Update();

    bool _Updated;

    flag8 _WorldFlag;
    vec3 _WorldTranslation;
    quat _WorldOrientation;
    vec3 _WorldScaling;
    vec3 _WorldReflectNormal;
    mat4 _WorldTransformation;

    flag8 _ModelFlag;
    vec3 _ModelTranslation;
    quat _ModelOrientation;
    vec3 _ModelScaling;
    vec3 _ModelReflectNormal;
    mat4 _ModelTransformation;

    mat4 _Transform;
    vec4 _Position;
};

}//namespace core
}//namespace o

#endif//__ORANGE_CORE_SG_FRAME_H__
