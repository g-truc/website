#ifndef __ORANGE_CORE_SG_SG_H__
#define __ORANGE_CORE_SG_SG_H__

#include "graph.h"

#endif//__ORANGE_CORE_SG_SG_H__
