#ifndef __ORANGE_CORE_H__
#define __ORANGE_CORE_H__

#include "error/error.h"
#include "resource/resource.h"
#include "sg/sg.h"
#include "time/time.h"
#include "window/window.h"
#include "component/component.h"

#endif//__ORANGE_CORE_H__
