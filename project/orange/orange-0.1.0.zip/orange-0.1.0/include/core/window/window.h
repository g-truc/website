#ifndef __ORANGE_CORE_WINDOW_WINDOW_H__
#define __ORANGE_CORE_WINDOW_WINDOW_H__

#ifdef USE_OPENGL
#include <gtw/window_wgl.h>

namespace o::core
{

}

#endif

#ifdef USE_DIRECT3D9
#include <gtw/window_d3d9.h>

namespace o::core
{

}

#endif

#endif//__ORANGE_CORE_WINDOW_WINDOW_H__
