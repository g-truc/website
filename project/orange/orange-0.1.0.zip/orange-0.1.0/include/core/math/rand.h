#ifndef __ORANGE_BASE_MATH_RAND_H__
#define __ORANGE_BASE_MATH_RAND_H__

#include "../util/type.h"
#include "../math/type.h"

namespace o {
namespace core {

// Return a random float32 number between -1.0f and 1.0f
float32 rand();
// Return a random float32 number between fMin and fMax
float32 rand(float32 fMin, float32 fMax);
// Return a random sint32 number between sMin and sMax
// with sMin and sMax included
int32 rand(int32 sMin, int32 sMax);
// Return a random unit vec3
vec2 rand2();
// Return a random unit vec3
vec3 rand3();

}//namespace core
}//namespace o

#endif //__ORANGE_BASE_MATH_RAND_H__
