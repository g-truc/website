#ifndef __ORANGE_CORE_COMPONENT_FACTORY_H__
#define __ORANGE_CORE_COMPONENT_FACTORY_H__

#include <core/pattern/pattern.h>

namespace o {
namespace core {

interface IParameter
{};

interface IComponent;

interface IComponentCreator
{
    virtual IComponent* Create(handle ObjectId, IParameter* Parameter) = 0;
    virtual bool Destroy(IComponent*) = 0;
};

template<typename D>
class CComponentCreator : public IComponentCreator
{
public:
    CComponentCreator();
    virtual ~CComponentCreator();

    virtual IComponent* Create(handle ObjectId, IParameter* Parameter);
    virtual bool Destroy(IComponent* pObject);
};

template<typename K>
class CComponentFactory : public CNonCopyable
{
    typedef typename std::map<K, IComponentCreator*> TCreatorsMap;
    typedef typename std::map<K, IComponentCreator*>::iterator TCreatorsIt;
    typedef typename std::map<K, IComponentCreator*>::const_iterator TCreatorsCit;

public:
    CComponentFactory();
    virtual ~CComponentFactory();
    bool Register(K Key, IComponentCreator* pCreator);
    bool UnRegister(K Key);
    bool DestroyObject(IComponent* pObject);

protected:
    IComponent* CreateObject(K Key, handle ObjectId, IParameter* Parameter) const;

    TCreatorsMap m_Creators;
};

}//namespace core
}//namespace o

#include "factory.inl"

#endif//__ORANGE_CORE_COMPONENT_FACTORY_H__
