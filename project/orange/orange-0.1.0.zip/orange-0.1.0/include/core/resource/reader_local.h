#ifndef __ORANGE_CORE_RESOURCE_READER_LOCAL_H__
#define __ORANGE_CORE_RESOURCE_READER_LOCAL_H__

#include "reader.h"

namespace o {
namespace core {

class CReaderLocal : public IReader
{
public:
	virtual CResource* Load(const std::string& Filename);
};

}//namespace core
}//namespace o

#endif//__ORANGE_CORE_RESOURCE_READER_LOCAL_H__
