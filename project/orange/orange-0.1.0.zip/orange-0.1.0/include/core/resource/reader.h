#ifndef __ORANGE_CORE_RESOURCE_READER_H__
#define __ORANGE_CORE_RESOURCE_READER_H__

#define LOCAL_DIRECTORY "./data/"

#include <core/util/util.h>

namespace o {
namespace core {

class CResource;	

class CFileDesc
{
public:
	CFileDesc();
	CFileDesc(const std::string& Filename, size_t Size);
	virtual ~CFileDesc(){}

	std::string GetFilename() const {return _Filename;}
	std::string GetExtension() const {return _Extension;}
	size_t GetSize() const {return _Size;}

private:
	void _ExtractExtension();

	std::string _Filename;
	std::string _Extension;
	size_t _Size;
};

interface IReader
{
	virtual ~IReader(){}
	virtual CResource* Load(const std::string& Filename) = 0;
};

}//namespace core
}//namespace o

#endif//__ORANGE_CORE_RESOURCE_READER_H__
