#ifndef __ORANGE_CORE_RESOURCE_READER_7Z_H__
#define __ORANGE_CORE_RESOURCE_READER_7Z_H__

#include "reader.h"
#include "7z/7z.h"
#include <core/util/util.h>

namespace o {
namespace core {

class CReader7z : public IReader
{
public:
	struct SDataAccess
	{
		SDataAccess() :
			File(null)
		{}

		~SDataAccess()
		{}

		ISzInStream Stream;
		FILE* File;
	};

private:
	struct SArchiveInfo
	{
		SArchiveInfo();
		~SArchiveInfo();

		SDataAccess DataAccess;
		ISzAlloc MainAlloc;
		ISzAlloc TempAlloc;
		CArchiveDatabaseEx Database;
		std::string Filename;
	};

	typedef std::set<std::string> TFileIndex;

public:
	CReader7z();
	~CReader7z();
	virtual CResource* Load(const std::string& Filename);

private:
	void _RegisterArchives();
	void _FillIndex(SArchiveInfo& ArchiveInfo, TFileIndex& FileIndex, const std::string& ArchiveName);

	int _ArchiveNumber;
	TFileIndex* _FileIndex;
	SArchiveInfo* _ArchiveInfo;
};

}//namespace core
}//namespace o

#endif//__ORANGE_CORE_RESOURCE_READER_7Z_H__
