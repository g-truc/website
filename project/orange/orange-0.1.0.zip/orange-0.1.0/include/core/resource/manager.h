#ifndef __ORANGE_CORE_RESOURCE_MANAGER_H__
#define __ORANGE_CORE_RESOURCE_MANAGER_H__

#include "reader.h"
#include <core/pattern/pattern.h>

namespace o {
namespace core {

//! Raw data from local files of archived files
class CResource : public CFileDesc, public CNonCopyable
{
public:
	CResource(const std::string& Filename, const void* Buffer, const size_t Size);
	virtual ~CResource();

	const void* const GetBuffer() const {return _Buffer;}

private:
	const void* _Buffer;
};

typedef CSmartPtr<CResource> PResource;

//! Interface of asset in the asset manager
class IAsset : public CFileDesc
{
public:
	virtual ~IAsset(){}
	virtual bool Load(const PResource& Resource) = 0;
	virtual handle GetType() const = 0;
};

//! Before being used, asset classes must be registred in the asset manager witch is in charge of asset instancing
template <typename T>
inline void RegisterAsset(const std::string& Extension)
{
	static bool Registred = false;
	if(!Registred)
	{
		CResourceManager::GetInstance()->Register(Extension, creator<IAsset, T>());
		Registred = true;
	}
}

//! The asset manager class save asset instances and prevent more than one instance per asset
class CResourceManager : public CAutoSingleton<CResourceManager>, public CAbstractFactory<std::string, IAsset>
{
	struct SAssetInfo
	{
		SAssetInfo(IAsset* Pointer) :
			Pointer(Pointer),
			NewCount(1),
			DeleteCount(0)
		{}
		IAsset* Pointer;
		int NewCount;
		int DeleteCount;
	};

	friend class CAutoSingleton<CResourceManager>;

	typedef std::map<std::string, SAssetInfo> TAssetMap;
	typedef std::map<IAsset*, TAssetMap::iterator> TAssetMapAccess;

public:
	//! Find asset instance if there is one already or create the instance
	IAsset* FindAsset(const std::string& Filename);
	//! Destroy asset instance if all references have been release already.
	void ReleaseAsset(IAsset* Asset);
	//! Destroy all asset instances, use wish caution !
	void Clear();

private:
	CResourceManager();
	virtual ~CResourceManager();

	//! List all the content of archives
	void _RegisterArchives();
	//! Look in the AssetMap weather of not the asset is allready loaded
	IAsset* _SearchAssetInstance(const std::string& Filename);
	//! Load a resource from a file on the hard disk
	IAsset* _LoadAssetInstance(const std::string& Filename);

	//! Read files from the local directory
	IReader* _ReaderLocal;
	//! Read files from archives
	IReader* _Reader7z;

	//! In charge of asset instances
	TAssetMap _AssetMap;
	//! Allow a fast access to _AssetMap entry using instances pointers
	TAssetMapAccess _AssetMapAccess;
};

}//namespace core
}//namespace o

#endif//__ORANGE_CORE_RESOURCE_MANAGER_H__
