// Todo: Integrate and test

#ifndef __ORANGE_BASE_UTIL_REF_INFO_H__
#define __ORANGE_BASE_UTIL_REF_INFO_H__

#include <core/memory/memory.h>

namespace o {
namespace core {

template <typename T>
interface CRefCounter
{
public:
	CRefCounter(T* Pointer) :
		_Pointer(Pointer),
		_NewCount(1),
		_DeleteCount(0)
	{}

	~CRefCounter()
	{}

	int Count() const{return _NewCount - _DeleteCount;}
	void Push(){++_NewCount;}
	void Pop(){++_DeleteCount;}
	T* GetPointer()const {return _Pointer;}

private:
	T* _Pointer;
	int _NewCount;
	int _DeleteCount;
};

}//namespace core
}//namespace o

#include "ref_info.inl"

#endif//__ORANGE_BASE_UTIL_REF_INFO_H__
