#ifndef __ORANGE_BASE_PATTERN_AUTO_SINGLETON_H__
#define __ORANGE_BASE_PATTERN_AUTO_SINGLETON_H__

#include "../util/lang.h"

namespace o {
namespace core {

template <typename T> 
class CAutoSingleton
{
public:
    // 13/06/2005 - Get and/or create the singleton instance
    static T* GetInstance();
    // 13/06/2005 - Delete singleton instance if it was created 
    static void Destroy();
    // 13/06/2005 - Test if singleton instance was created
    static bool IsCreated();

private:
    static T* singleton;
};

}//namespace core
}//namespace o

#include "auto_singleton.inl"

#endif//__ORANGE_BASE_PATTERN_AUTO_SINGLETON_H__
