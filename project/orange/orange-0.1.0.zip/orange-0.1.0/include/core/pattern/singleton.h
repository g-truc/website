#ifndef __ORANGE_BASE_PATTERN_SINGLETON_H__
#define __ORANGE_BASE_PATTERN_SINGLETON_H__

#include <core/util/lang.h>

namespace o {
namespace core {

template <typename T> 
class CSingleton
{
public:
    // 13/06/2005 - Get and/or create the singleton instance
    static T* GetInstance();
    // 13/06/2005 - Delete singleton instance if it was created 
    static void Destroy();
    // 13/06/2005 - Test if singleton instance was created
    static bool IsCreated();

private:
    static T* object;
};

}//namespace core
}//namespace o

#include "singleton.inl"

#endif//__ORANGE_BASE_PATTERN_SINGLETON_H__
