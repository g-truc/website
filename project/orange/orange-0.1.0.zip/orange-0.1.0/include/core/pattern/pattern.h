#ifndef __ORANGE_SERVICE_PATTERN_PATTERN_H__
#define __ORANGE_SERVICE_PATTERN_PATTERN_H__

#include "array.h"
#include "auto_singleton.h"
#include "factory.h"
#include "noncopyable.h"
#include "singleton.h"
#include "smart_ptr.h"
#include "tree.h"

#endif//__ORANGE_SERVICE_PATTERN_PATTERN_H__
