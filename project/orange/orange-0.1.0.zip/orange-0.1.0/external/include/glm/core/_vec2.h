//////////////////////////////////////////////////////////////////////////////////
// OpenGL Mathematics Copyright (c) 2005 G-Truc Creation (www.g-truc.net)
//////////////////////////////////////////////////////////////////////////////////
// Author  : Christophe [Groove] Riccio (contact [at] g-truc [point] net)
// Created : 2005-01-10
// Updated : 2006-01-04
// Licence : This source is under GNU LGPL licence
// File    : _vec2.h
//////////////////////////////////////////////////////////////////////////////////

#ifndef __vec2_h__
#define __vec2_h__

namespace glm
{
    template <typename T> class _xvec3;
    template <typename T> class _xvec4;
    class _bvec2;
    class _bvec3;
    class _bvec4;
    template <typename T> class _xmat2;

	//!< \brief Template for Vector of 2 floating-point numbers or 2 integers . (From GLSL 1.10.59 specification)
    template <typename T> 
    class _xvec2
    {
    public:
        // Data
        /* ISO C++ version unavailable with VC7.1 ...
            union{T x, r, s;};
            union{T y, g, t;};
        */
        // Solution away from ISO C++ but available with VC7.1 and GCC without -pedantic
        union 
        {
            struct{T x, y;};
            struct{T r, g;};
            struct{T s, t;};
        };

	    // Constructors
        _xvec2();
	    explicit _xvec2(T x, T y);
        explicit _xvec2(T f);
        //explicit _xvec2(const T* a);

        // Convertions
        template <typename U> explicit _xvec2(U x, U y);
        explicit _xvec2(const _xvec3<T>& v);
        explicit _xvec2(const _xvec4<T>& v);
        explicit _xvec2(const _bvec2& v);
        explicit _xvec2(const _bvec3& v);
        explicit _xvec2(const _bvec4& v);
        template <typename U> explicit _xvec2(const _xvec2<U>& v);
        template <typename U> explicit _xvec2(const _xvec3<U>& v);
        template <typename U> explicit _xvec2(const _xvec4<U>& v);

        // Accesses
        T& operator[](int i);
        T operator[](int i) const;
        operator T*();
	    operator const T*() const;

        // Operators
        _xvec2<T>& operator=(const _xvec2<T>& x);
	    _xvec2<T> operator+ (const T s) const;
	    _xvec2<T> & operator+= (const T s);
        _xvec2<T> operator+ (const _xvec2<T> & v) const;
	    _xvec2<T> & operator+= (const _xvec2<T> & v);
	    _xvec2<T> operator- (const T s) const;
	    _xvec2<T> & operator-= (const T s);
	    _xvec2<T> operator- (const _xvec2<T> & v) const;
	    _xvec2<T> & operator-= (const _xvec2<T> & v);
	    _xvec2<T> operator* (const T s) const;
	    _xvec2<T> & operator*= (const T s);
	    _xvec2<T> operator* (const _xvec2<T> & v) const;
	    _xvec2<T> & operator*= (const _xvec2<T> & v);
        _xvec2<T> operator* (const _xmat2<T>& m) const;
        _xvec2<T> & operator*= (const _xmat2<T>& m);
	    _xvec2<T> operator/ (const T s) const;
	    _xvec2<T> & operator/= (const T s);
	    _xvec2<T> operator/ (const _xvec2<T> & v) const;
	    _xvec2<T> & operator/= (const _xvec2<T> & v);
        _xvec2<T> operator- () const;
        _xvec2<T> operator++ ();
	    const _xvec2<T> operator++ (int n) const;
	    _xvec2<T> operator-- ();
	    const _xvec2<T> operator-- (int n) const;
    };

    template <typename T> _xvec2<T> operator+ (const T s, const _xvec2<T>& v)
    {
        return v + s;
    }
//  _xvec2<T> operator-() const is defined so this isn't need
    template <typename T> _xvec2<T> operator- (const T s, const _xvec2<T>& v)
    {
        return _xvec2<T>(s - v.x, s - v.y);
    }

    template <typename T> _xvec2<T> operator* (const T s, const _xvec2<T>& v)
    {
        return v * s;
    }

    //////////////////////////////////////////////////////////

    class _bvec3;
    class _bvec4;

    //!< \brief Class for Vector of 2 booleans. (From GLSL 1.10.59 specification)
    class _bvec2
    {
    public:
        int _size () const;

    public:
        // Data
        union{bool x, r, s;};
        union{bool y, g, t;};

        // Constructors
	    _bvec2();
	    explicit _bvec2(bool x, bool y);
        explicit _bvec2(bool b);
        explicit _bvec2(const bool* a);

        // Convertions
        template <typename U> explicit _bvec2(U x, U y);
	    _bvec2(const _bvec3 & v);
        _bvec2(const _bvec4 & v);
        template <typename U> _bvec2(const _xvec2<U>& v);
        template <typename U> _bvec2(const _xvec3<U>& v);
        template <typename U> _bvec2(const _xvec4<U>& v);

        // Accesses
        bool& operator[](int i);
        bool operator[](int i) const;
        operator bool*();
	    operator const bool*() const;

        // Operators
        _bvec2& operator=(const _bvec2& x);
	    _bvec2 operator-- ();
	    const _bvec2 operator-- (int n) const;
        _bvec2 operator++ ();
	    const _bvec2 operator++ (int n) const;
	    _bvec2 operator! () const;
    };
} //namespace glm

#endif //__vec2_h__
