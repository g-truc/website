//////////////////////////////////////////////////////////////////////////////////
// OpenGL Mathematics Copyright (c) 2005 G-Truc Creation (www.g-truc.net)
//////////////////////////////////////////////////////////////////////////////////
// Author  : Christophe [Groove] Riccio (contact [at] g-truc [point] net)
// Created : 2005-01-10
// Updated : 2006-01-04
// Licence : This source is under GNU LGPL licence
// File    : _vec4.h
//////////////////////////////////////////////////////////////////////////////////

#ifndef __vec4_h__
#define __vec4_h__

namespace glm
{
    template <typename T> class _xvec2;
    template <typename T> class _xvec3;
    class _bvec2;
    class _bvec3;
    class _bvec4;
    template <typename T> class _xmat4;

    //!< \brief Template for Vector of 3 floating-point numbers or 3 integers . (From GLSL 1.10.59 specification)
    template <typename T> 
    class _xvec4
    {
    public:
        // Data
        /* ISO C++ version unavailable with VC7.1 ...
            union{T x, r, s;};
            union{T y, g, t;};
            union{T z, b, p;};
            union{T w, a, q;};
        */
        // Solution away from ISO C++ but available with VC7.1 and GCC without -pedantic
        union 
        {
            struct{T x, y, z, w;};
            struct{T r, g, b, a;};
            struct{T s, t, p, q;};
            //__m128 data;
        };

        // Constructors
	    _xvec4();
	    explicit _xvec4(const T x, const T y, const T z, const T w);
        explicit _xvec4(T f);
        //explicit _xvec4(const T* a);

        // Convertions
        explicit _xvec4(const _xvec2<T> & v1, const _xvec2<T> & v2);
        explicit _xvec4(const _xvec3<T> & v1, T v2);
        explicit _xvec4(T v1, const _xvec3<T> & v2);
        explicit _xvec4(T v1, T v2, const _xvec2<T> & v3);
        explicit _xvec4(T v1, const _xvec2<T> & v2, T v3);
        explicit _xvec4(const _xvec2<T> & v1, T v2, T v3);
        template <typename U> explicit _xvec4(U x, U y, U z, U w);
        template <typename U> explicit _xvec4(const _xvec4<U>& v);
        template <typename U> explicit _xvec4(const _xvec2<U> & v1, const _xvec2<U> & v2);
        template <typename U> explicit _xvec4(const _xvec3<U> & v1, U v2);
        template <typename U> explicit _xvec4(U v1, const _xvec3<U>& v2);
        template <typename U> explicit _xvec4(U v1, U v2, const _xvec2<U>& v3);
        template <typename U> explicit _xvec4(U v1, const _xvec2<U>& v2, U v3);
        template <typename U> explicit _xvec4(const _xvec2<U>& v1, U v2, U v3);
        explicit _xvec4(const _bvec4& v);
        explicit _xvec4(const _bvec2& v1, const _bvec2& v2);
        explicit _xvec4(const _bvec3& v1, bool v2);
        explicit _xvec4(bool v1, const _bvec3& v2);
        explicit _xvec4(bool v1, bool v2, const _bvec2& v3);
        explicit _xvec4(bool v1, const _bvec2& v2, bool v3);
        explicit _xvec4(const _bvec2& v1, bool v2, bool v3);

        // Accesses
        T& operator[](int i);
        T operator[](int i) const;
        operator T*();
	    operator const T*() const;

        // Operators
        _xvec4<T>& operator=(const _xvec4<T>& x);
	    _xvec4<T> operator+ (const T s) const;
	    _xvec4<T> & operator+= (const T s);
	    _xvec4<T> operator+(const _xvec4<T> & v) const;
	    _xvec4<T> & operator+=(const _xvec4<T> & v);
	    _xvec4<T> operator- (const T s) const;
	    _xvec4<T> & operator-= (const T s);
	    _xvec4<T> operator-(const _xvec4<T> & v) const;
	    _xvec4<T> & operator-=(const _xvec4<T> & v);
	    _xvec4<T> operator*(const T s) const;
	    _xvec4<T> & operator*=(const T s);
	    _xvec4<T> operator* (const _xvec4<T> & v) const;
	    _xvec4<T> & operator*= (const _xvec4<T> & v);
        _xvec4<T> operator* (const _xmat4<T> & m) const;
        _xvec4<T> & operator*= (const _xmat4<T> & m);
	    _xvec4<T> operator/(const T s) const;
	    _xvec4<T> & operator/=(const T s);
	    _xvec4<T> operator/ (const _xvec4<T> & v) const;
	    _xvec4<T> & operator/= (const _xvec4<T> & v);
        _xvec4<T> operator-() const;
	    _xvec4<T> operator++();
	    const _xvec4<T> operator++(int n) const;
	    _xvec4<T> operator--();
        const _xvec4<T> operator--(int n) const;
    };

    template <typename T> _xvec4<T> operator+ (const T s, const _xvec4<T> & v)
    {
        return v + s;
    }

    //_xvec4<T> operator-() const is defined so this isn't need
    template <typename T> _xvec4<T> operator- (const T s, const _xvec4<T> & v)
    {
        return _xvec4<T>(s - v.x, s - v.y, s - v.z, s - v.w);
    }

    template <typename T> _xvec4<T> operator* (const T s, const _xvec4<T> & v)
    {
        return v * s;
    }

    //////////////////////////////////////////////////////////

    class _bvec2;
    class _bvec3;

    //!< \brief Class for Vector of 4 booleans. (From GLSL 1.10.59 specification)
    class _bvec4
    {
    public:
        // Data
        union{bool x, r, s;};
        union{bool y, g, t;};
        union{bool z, b, p;};
        union{bool w, a, q;};

        // Constructors
	    _bvec4();
	    explicit _bvec4(bool x, bool y, bool z, bool w);
        explicit _bvec4(bool b);
        explicit _bvec4(const _bvec2& v1, const _bvec2& v2);
        explicit _bvec4(const _bvec3& v1, bool v2);
        explicit _bvec4(bool v1, const _bvec3& v2);
        explicit _bvec4(bool v1, bool v2, const _bvec2& v3);
        explicit _bvec4(bool v1, const _bvec2& v2, bool v3);
        explicit _bvec4(const _bvec2& v1, bool v2, bool v3);

        // Convertions
        template <typename U> explicit _bvec4(const _xvec4<U>& v);
        template <typename U> explicit _bvec4(U x, U y, U z, U w);
        template <typename U> explicit _bvec4(const _xvec2<U> & v1, const _xvec2<U> & v2);
        template <typename U> explicit _bvec4(const _xvec3<U> & v1, U v2);
        template <typename U> explicit _bvec4(U v1, const _xvec3<U>& v2);
        template <typename U> explicit _bvec4(U v1, U v2, const _xvec2<U>& v3);
        template <typename U> explicit _bvec4(U v1, const _xvec2<U>& v2, U v3);
        template <typename U> explicit _bvec4(const _xvec2<U>& v1, U v2, U v3);

        // Accesses
        bool& operator[](int i);
        bool operator[](int i) const;
        operator bool*();
	    operator const bool*() const;

        // Operators
        _bvec4& operator=(const _bvec4& x);
	    _bvec4 operator++();
	    const _bvec4 operator++(int n) const;
        _bvec4 operator--();
	    const _bvec4 operator--(int n) const;
        _bvec4 operator!() const ;
    };
} //namespace glm

#endif //__vec4_h__

