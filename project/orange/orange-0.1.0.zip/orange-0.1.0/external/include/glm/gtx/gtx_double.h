//////////////////////////////////////////////////////////////////////////////////
// OpenGL Mathematics Copyright (c) 2005 G-Truc Creation (www.g-truc.net)
//////////////////////////////////////////////////////////////////////////////////
// Author  : Christophe [Groove] Riccio (contact [at] g-truc [point] net)
// Created : 2005-12-21
// Updated : 2005-12-21
// Licence : This source is under GNU LGPL licence
// File    : gtx_double.h
//////////////////////////////////////////////////////////////////////////////////
// Dependency:
// - GLM version 1.0
//////////////////////////////////////////////////////////////////////////////////
// ToDo:
// - Finish to declare extension functions
// - Nothing define
// - Study extension dependencies
//////////////////////////////////////////////////////////////////////////////////
// Note:
// - This implementation doesn't need to redefine all build-in functions to
// support double based type.
//////////////////////////////////////////////////////////////////////////////////

#ifndef __gtx_double_h__
#define __gtx_double_h__

//#define GLM_GTX_double 0
#include "../glm.h"

namespace glm
{
    ////////////////////////////////////////////////////////////////////////
    // Types definition

    typedef _xvec2<float> __fvec2GTX;	//!< \brief Vector of 2 single-precision floating-point numbers. (from GLM_GTX_double extension)
    typedef _xvec3<float> __fvec3GTX;	//!< \brief Vector of 3 single-precision floating-point numbers. (from GLM_GTX_double extension)
    typedef _xvec4<float> __fvec4GTX;	//!< \brief Vector of 4 single-precision floating-point numbers. (from GLM_GTX_double extension)
    typedef _xmat2<float> __fmat2GTX;	//!< \brief 2 * 2 matrix of single-precision floating-point numbers. (from GLM_GTX_double extension)
    typedef _xmat3<float> __fmat3GTX;	//!< \brief 3 * 3 matrix of single-precision floating-point numbers. (from GLM_GTX_double extension)
    typedef _xmat4<float> __fmat4GTX;	//!< \brief 4 * 4 matrix of single-precision floating-point numbers. (from GLM_GTX_double extension)
    typedef _xquat<float> __fquatGTX;	//!< \brief quaternion of single-precision floating-point numbers. (from GLM_GTX_double extension)

    typedef _xvec2<double> __dvec2GTX;	//!< \brief Vector of 2 double-precision floating-point numbers. (from GLM_GTX_double extension)
    typedef _xvec3<double> __dvec3GTX;	//!< \brief Vector of 3 double-precision floating-point numbers. (from GLM_GTX_double extension)
    typedef _xvec4<double> __dvec4GTX;	//!< \brief Vector of 4 double-precision floating-point numbers. (from GLM_GTX_double extension)
    typedef _xmat2<double> __dmat2GTX;	//!< \brief 2 * 2 matrix of double-precision floating-point numbers. (from GLM_GTX_double extension)
    typedef _xmat3<double> __dmat3GTX;	//!< \brief 3 * 3 matrix of double-precision floating-point numbers. (from GLM_GTX_double extension)
    typedef _xmat4<double> __dmat4GTX;	//!< \brief 4 * 4 matrix of double-precision floating-point numbers. (from GLM_GTX_double extension)
    typedef _xquat<double> __dquatGTX;	//!< \brief quaternion of double-precision floating-point numbers. (from GLM_GTX_double extension)

    ////////////////////////////////////////////////////////////////////////
    // Trigonometric Functions

    double radians(double degrees); //!< \brief Converts degrees to radians and returns the result. (from GLM_GTX_double extension)
    double degrees(double radians); //!< \brief Converts radians to degrees and returns the result. (from GLM_GTX_double extension)
    double sin(double angle); //!< \brief The standard trigonometric sine function. The values returned by this function will range from [-1, 1]. (from GLM_GTX_double extension)
    double cos(double angle); //!< \brief The standard trigonometric cosine function. The values returned by this function will range from [-1, 1]. (from GLM_GTX_double extension)
    double tan(double angle); //!< \brief The standard trigonometric tangent function. (from GLM_GTX_double extension)
    double asin(double x); //!< \brief Arc sine. Returns an angle whose sine is x. The rqnge of values returned by this function is [-PI/2, PI/2]. Results are undefined if |x| > 1. (from GLM_GTX_double extension)
    double acos(double x); //!< \brief Arc cosine. Returns an angle whose sine is x. The range of values returned by this function is [0, PI]. Results are undefined if |x| > 1. (from GLM_GTX_double extension)
    double atan(double y, double x); //!< \brief Arc tangent. Returns an angle whose tangent is y/x. The signs of x and y are used to determine what quadrant the angle is in. The range of values returned by this function is [-PI, PI]. Results are undefined if x and y are both 0. (from GLM_GTX_double extension)
    double atan(double y_over_x); //!< \brief Arc tangent. Returns an angle whose tangent is y_over_x. The range of values returned by this function is [-PI/2, PI/2]. (from GLM_GTX_double extension)

    ////////////////////////////////////////////////////////////////////////
    // Exponential Functions

    double pow(double x, double y); //!< \brief Returns x raised to the y power. (from GLM_GTX_double extension)
    double exp(double x); //!< \brief Returns the natural exponentiation of x, i.e., e^x. (from GLM_GTX_double extension)
    double log(double x); //!< \brief Returns the natural logarithm of x, i.e., returns the value y which satisfies the equation x = e^y. Results are undefined if x <= 0. (from GLM_GTX_double extension)
    double exp2(double x); //!< \brief Returns 2 raised to the x power. (from GLM_GTX_double extension)
    double log2(double x); //!< \brief Returns the base 2 log of x, i.e., returns the value y, which satisfies the equation x = 2 ^ y. (from GLM_GTX_double extension)
    double sqrt(double x); //!< \brief Returns the positive square root of x. (from GLM_GTX_double extension)
    double inversesqrt(double x); //!< \brief Returns the reciprocal of the positive square root of x. (from GLM_GTX_double extension)

    ////////////////////////////////////////////////////////////////////////
    // Common Functions

    double floor(double x); //!< \brief Returns a value equal to the nearest integer that is less then or equal to x. (from GLM_GTX_double extension)
    double ceil(double x); //!< \brief Returns a value equal to the nearest integer that is greater than or equal to x. (from GLM_GTX_double extension)
    double fract(double x); //!< \brief Return x - floor(x). (from GLM_GTX_double extension)
    double mod(double x, double y); //!< \brief Modulus. Returns x - y * floor(x / y) for each component in x using the floating point value y. (from GLM_GTX_double extension)
    double mix(double x, double y, double a); //!< \brief Returns x * (1.0 - a) + y * a, i.e., the linear blend of x and y using the floating-point value a. The value for a is not restricted to the range [0, 1]. (from GLM_GTX_double extension)
    double step(double edge, double x); //!< \brief Returns 0.0 if x <= edge; otherwise, it returns 1.0. (from GLM_GTX_double extension)
    double smoothstep(double edge0, double edge1, double x); //!< \brief Returns 0.0 if x <= edge0 and 1.0 if x >= edge1 and performs smooth Hermite interpolation between 0 and 1 when edge0 < x, edge1. (from GLM_GTX_double extension)

    ////////////////////////////////////////////////////////////////////////
    // Geometric Functions

    double length(double x); //!< \brief Returns the length of x, i.e., sqrt(x * x). (from GLM_GTX_double extension)
    double dot(double v1, double v2); //!< \brief Returns the dot product of x and y, i.e., result = x * y. (from GLM_GTX_double extension)
    double faceforward(double N, double I, double Nref); //!< \brief If dot(Nref, I) < 0.0, return N, otherwise, return -N. (from GLM_GTX_double extension)
    double reflect(double I, double N); //!< \brief For the incident vector I and surface orientation N, returns the reflection direction : result = I - 2.0 * dot(N, I) * N. (from GLM_GTX_double extension)
    double refract(double I, double N, double eta); //!< \brief For the incident vector I and surface normal N, and the ratio of indices of refraction eta, return the refraction vector. (from GLM_GTX_double extension)

    ////////////////////////////////////////////////////////////////////////
    // Noise Functions

    double noise1(double x); //!< \brief Returns a 1D noise value based on the input value x. (from GLM_GTX_double extension)
}

#endif//__gtx_double_h__
