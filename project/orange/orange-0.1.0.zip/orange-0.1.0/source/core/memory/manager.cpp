#include <core/precompiled.h>
#include <core/memory/manager.h>

namespace o {
namespace core {

// SMemoryInfo
SMemoryInfo::SMemoryInfo(const std::string& Filename, int Line, const std::string& Typename, size_t TypeSize, size_t FullSize) :
	Filename(Filename),
	Line(Line),
	Typename(Typename),
	TypeSize(TypeSize),
	FullSize(FullSize)
{}

// CMemoryManager
void CMemoryManager::New(void* const Pointer, const SMemoryInfo& MemoryInfo)
{
	MemoryMap.insert(std::make_pair(Pointer, MemoryInfo));
}

void CMemoryManager::New(const void* const Pointer, const SMemoryInfo& MemoryInfo)
{
	MemoryMap.insert(std::make_pair(Pointer, MemoryInfo));
}

void CMemoryManager::Delete(void* const Pointer)
{
	MemoryMap.erase(Pointer);
}

void CMemoryManager::Delete(const void* const Pointer)
{
	MemoryMap.erase(Pointer);
}

CMemoryManager::const_iterator CMemoryManager::Begin() const
{
	return MemoryMap.begin();
}

CMemoryManager::const_iterator CMemoryManager::End() const
{
	return MemoryMap.end();
}

size_t CMemoryManager::GetSize() const
{
	return MemoryMap.size();
}

}//namespace core
}//namespace o
