#include <core/precompiled.h>
#include <core/resource/message.h>

namespace o {
namespace core {

CErrorMessage::CErrorMessage()
{}

CErrorMessage::~CErrorMessage()
{}

void CErrorMessage::Read(const TLangMap& LangMap)
{
	_LangMap = LangMap;
}

std::string CErrorMessage::Find(int Message) const
{
	TLangMap::const_iterator it = _LangMap.find(Message);
	if(it != _LangMap.end())
		return it->second;
	return std::string();
}

}//namespace core
}//namespace o
