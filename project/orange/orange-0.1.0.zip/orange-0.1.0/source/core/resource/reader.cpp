#include <core/precompiled.h>
#include <core/resource/reader.h>

namespace o {
namespace core {

// CFileDesc
CFileDesc::CFileDesc(const std::string& Filename, size_t Size) : 
	_Filename(Filename),
	_Extension(""),
	_Size(Size)
{
	_ExtractExtension();
}

// CFileDesc
CFileDesc::CFileDesc() : 
	_Filename(""),
	_Extension(""),
	_Size(0)
{}

void CFileDesc::_ExtractExtension()
{
	for(size_t i = _Filename.size(); i > 0; --i)
	{
		if(_Filename[i] != '.')
			continue;
		_Extension = &_Filename.c_str()[i + 1];
		return;
	}

	//o_error(_Extension == "", format("Unenable to extract filename extension of %s", _Filename.c_str()).c_str());
}

}//namespace core
}//namespace o
