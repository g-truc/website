#include <core/precompiled.h>
#include <core/resource/reader_local.h>
#include <core/resource/manager.h>

namespace o {
namespace core {

// CReaderLocal
CResource* CReaderLocal::Load(const std::string& Filename)
{
	FILE* File = fopen((std::string(LOCAL_DIRECTORY) + Filename).c_str(), "rb");
	if(File == null)
		return null;

	fseek(File, 0, SEEK_END);
	int Size = ftell(File);
	fseek(File, 0, SEEK_SET);

	byte* Buffer = new_array(byte, Size + 1);
	fread(Buffer, Size, 1, File);
	Buffer[Size] = 0;

	fclose(File);

	return new_object(CResource)(Filename, Buffer, Size);
}

}//namespace core
}//namespace o

