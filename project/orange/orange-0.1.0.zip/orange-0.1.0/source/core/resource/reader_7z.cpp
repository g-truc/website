#include <core/precompiled.h>
#include <core/resource/reader_7z.h>
#include <core/resource/manager.h>
#include <core/error/error.h>

#define PACKAGE_FORMAT "pack%2.2d.7z"

namespace o {
namespace core {

SZ_RESULT SzFileReadImp(void* object, void* buffer, size_t size, size_t* processedSize)
{
	CReader7z::SDataAccess* Stream = static_cast<CReader7z::SDataAccess*>(object);
	size_t processedSizeLoc = fread(buffer, 1, size, Stream->File);
	if (processedSize != 0)
		*processedSize = processedSizeLoc;
	return SZ_OK;
}

SZ_RESULT SzFileSeekImp(void *object, CFileSize pos)
{
	CReader7z::SDataAccess* Stream = static_cast<CReader7z::SDataAccess*>(object);
	int Result = fseek(Stream->File, long(pos), SEEK_SET);
	if(Result == 0)
		return SZ_OK;
	return SZE_FAIL;
}

// SArchiveInfo for CReader7z
CReader7z::SArchiveInfo::SArchiveInfo()
{
	DataAccess.Stream.Read = SzFileReadImp;
	DataAccess.Stream.Seek = SzFileSeekImp;

	MainAlloc.Alloc = SzAlloc;
	MainAlloc.Free = SzFree;

	TempAlloc.Alloc = SzAllocTemp;
	TempAlloc.Free = SzFreeTemp;

	SzArDbExInit(&Database);
}

CReader7z::SArchiveInfo::~SArchiveInfo()
{
	o_error(DataAccess.File != null, "Archive not closed");

	SzArDbExFree(&Database, MainAlloc.Free);
}

// CReader7z
CReader7z::CReader7z() :
	_FileIndex(null),
	_ArchiveInfo(null)
{
	_RegisterArchives();
}

CReader7z::~CReader7z()
{
	if(_FileIndex != null)
		delete_array(_FileIndex);
	if(_ArchiveInfo != null)
		delete_array(_ArchiveInfo);
}

CResource* CReader7z::Load(const std::string& Filename)
{
	CResource* Resource = null; // File not found if Load return null

	for(int j = _ArchiveNumber - 1; j >= 0; --j)
	{
		// Search in the files indexes if the file is present
		TFileIndex& FileIndex = _FileIndex[j];
		TFileIndex::iterator it = FileIndex.find(Filename);
		if(it == FileIndex.end())
			continue;
		SArchiveInfo& ArchiveInfo = _ArchiveInfo[j];
		ArchiveInfo.DataAccess.File = fopen(ArchiveInfo.Filename.c_str(), "rb");

		for(uint i = 0; i < ArchiveInfo.Database.Database.NumFiles; ++i)
		{
			// Get file description of the current file
			CFileItem* FileItem = ArchiveInfo.Database.Database.Files + i;

			// Check if the file is the one we look for
			if(std::string(FileItem->Name) != Filename)
			{
				printf("File : %s\n", FileItem->Name);
				continue;
			}

			// Extract data of the file we want
			size_t Offset, FullSize, FileSize;
			uint BlockIndex = 0xFFFFFFFF;
			byte* Buffer = 0;
			SZ_RESULT res = SzExtract(
				&ArchiveInfo.DataAccess.Stream, &ArchiveInfo.Database, i, 
				&BlockIndex, &Buffer, &FullSize, 
				&Offset, &FileSize, 
				&ArchiveInfo.MainAlloc, &ArchiveInfo.TempAlloc);

			//o_error(res != SZ_OK, format("Unable to extract %s from %s", Filename.c_str(), ArchiveInfo.Filename.c_str()).c_str());

			byte* Data = new_array(byte, FileSize + 1);
			memcpy(Data, Buffer + Offset, FileSize);
			Data[FileSize] = 0;

			ArchiveInfo.MainAlloc.Free(Buffer);

			Resource = new_object(CResource)(Filename, Data, FileSize);
			break;
		}

		fclose(ArchiveInfo.DataAccess.File);
		ArchiveInfo.DataAccess.File = null;

		if(Resource != null)
			break;
	}

	return Resource;
}

void CReader7z::_RegisterArchives()
{
	// Initialize 7z CRC table
	InitCrcTable();

	// Search the number of pack available
	_ArchiveNumber = 9;
	while(_ArchiveNumber >= 0)
	{
		std::string Path = std::string(LOCAL_DIRECTORY) + format(PACKAGE_FORMAT, _ArchiveNumber);
		FILE* Stream = fopen(Path.c_str(), "rb");
		//std::ifstream Stream(Path.c_str(), std::ios::in | std::ios::binary);
		//if(Stream.fail() || Stream.bad())
		if(!Stream)
		{
			--_ArchiveNumber;
			continue;
		}
		fclose(Stream);
		break;
	}
	
	// Plus 1 to allocate the right number of pack
	++_ArchiveNumber;

	// No pack found
	if(_ArchiveNumber == 0)
		return;

	_FileIndex = new_array(TFileIndex, _ArchiveNumber);
	_ArchiveInfo = new_array(SArchiveInfo, _ArchiveNumber);

	for(int i = 0; i < _ArchiveNumber; ++i)
	{
		std::string Path = std::string(LOCAL_DIRECTORY) + format(PACKAGE_FORMAT, i);
		_FillIndex(_ArchiveInfo[i], _FileIndex[i], Path);
	}
}

void CReader7z::_FillIndex(SArchiveInfo& ArchiveInfo, TFileIndex& FileIndex, const std::string& ArchiveName)
{
	ArchiveInfo.Filename = ArchiveName;
	ArchiveInfo.DataAccess.File = fopen(ArchiveName.c_str(), "rb");
	//o_error(ArchiveInfo.DataAccess.File == null, format("Can't open file %s", ArchiveName.c_str()).c_str());

	SZ_RESULT Result = SzArchiveOpen(
		&ArchiveInfo.DataAccess.Stream, 
		&ArchiveInfo.Database, 
		&ArchiveInfo.MainAlloc, 
		&ArchiveInfo.TempAlloc);

	if(Result == SZ_OK)
	{
		for(uint i = 0; i < ArchiveInfo.Database.Database.NumFiles; ++i)
		{
			CFileItem* Fileitem = ArchiveInfo.Database.Database.Files + i;
			FileIndex.insert(std::string(Fileitem->Name));
			// Test
			printf("File: %d Bytes, %s\n", Fileitem->Size, Fileitem->Name);
		}
	}

	fclose(ArchiveInfo.DataAccess.File);
	ArchiveInfo.DataAccess.File = null;
/*
	else if(Result == SZE_OUTOFMEMORY)
		printf("\nERROR : can not allocate memory\n");
	else     
		printf("\nERROR #%d\n", Result);
*/
}

}//namespace core
}//namespace o

