#include <core/precompiled.h>
#include <core/sg/graph.h>

namespace o {
namespace core {

CSceneGraph::CSceneGraph() :
    _Root(new_object(CFrame))
{}

CSceneGraph::~CSceneGraph()
{
    Clear();
    delete _Root;
    _Root = null;
}

CFrame* CSceneGraph::Create(CFrame* Parent)
{
    if(!Parent)
        return _Root;
    return new_object(CFrame(Parent));
}

handle CSceneGraph::CreateByHandle(handle ParentName)
{
    CFrame* Parent = static_cast<CFrame*>(_Root->Find(ParentName));
    if(ParentName == null)
		return handle::Null();
    CFrame* Frame = new_object(CFrame(Parent));
    return Frame->Name();
}

void CSceneGraph::Destroy(CFrame* Node)
{
    if(Node != null)
        Node->Release();
}

void CSceneGraph::DestroyByHandle(handle NodeName)
{
    CFrame* Node = static_cast<CFrame*>(_Root->Find(NodeName));
    if(Node != null)
        Node->Release();
}

void CSceneGraph::Clear()
{
    //_Root->Release();
}

}//namespace core
}//namespace o
