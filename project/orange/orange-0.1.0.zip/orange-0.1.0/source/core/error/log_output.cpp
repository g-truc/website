#include <core/precompiled.h>
#include <core/error/log_output.h>

namespace o {
namespace core {
/*
// LoggerDebug
void LoggerDebug::NewObject(const char* type, size_t size, const char* file, int line)
{
	OutputDebugString(format("%s, line %d: new object of %s, %d bytes\n", file, line, type, size).c_str());
}

void LoggerDebug::NewArray(const char* type, size_t size, const char* file, int line)
{
	OutputDebugString(format("%s, line %d: new array of %s, %d bytes\n", file, line, type, size).c_str());
}

void LoggerDebug::DeleteObject(const char* object, const char* file, int line)
{
	OutputDebugString(format("%s, line %d: delete object from %s\n", file, line, object).c_str());
}

void LoggerDebug::DeleteArray(const char* array, const char* file, int line)
{
	OutputDebugString(format("%s, line %d: delete array from %s\n", file, line, array).c_str());
}

void LoggerDebug::Test(const char* expression, bool result, const char* message, const char* file, int line)
{
	OutputDebugString(format("%s, line %d: test of %s is %s\n", file, line, expression, result ? "true" : "false").c_str());
}

void LoggerDebug::Warning(const char* expression, const char* message, const char* file, int line)
{
	OutputDebugString(format("%s, line %d: warning from %s: %s\n", file, line, expression, message).c_str());
}

void LoggerDebug::Error(const char* expression, const char* message, const char* file, int line)
{
	OutputDebugString(format("%s, line %d: error from %s: %s\n", file, line, expression, message).c_str());
}

void LoggerDebug::Message(const char* message, const char* filename, int line)
{
	OutputDebugString(format("%s, line %d: %s\n", filename, line, message).c_str());
}

// LoggerMessageBox
void LoggerMessageBox::NewObject(const char* type, size_t size, const char* filename, int line)
{
	MessageBox(NULL, format("%s, line %d: new object of %s, %d bytes\n", filename, line, type, size).c_str(), "New Object", MB_OK);
}

void LoggerMessageBox::NewArray(const char* type, size_t size, const char* file, int line)
{
	MessageBox(NULL, format("%s, line %d: new array of %s, %d bytes\n", file, line, type, size).c_str(), "New Array", MB_OK);
}

void LoggerMessageBox::DeleteObject(const char* object, const char* file, int line)
{
	MessageBox(NULL, format("%s, line %d: delete object from %s\n", file, line, object).c_str(), "Delete Object", MB_OK);
}

void LoggerMessageBox::DeleteArray(const char* array, const char* file, int line)
{
	MessageBox(NULL, format("%s, line %d: delete array from %s\n", file, line, array).c_str(), "Delete Array", MB_OK);
}

void LoggerMessageBox::Test(const char* expression, bool result, const char* message, const char* file, int line)
{
	MessageBox(NULL, format("%s, line %d: test of %s is %s\n", file, line, expression, result ? "true" : "false").c_str(), "Test", MB_OK);
}

void LoggerMessageBox::Warning(const char* expression, const char* message, const char* file, int line)
{
	MessageBox(NULL, format("%s, line %d: warning from %s: %s\n", file, line, expression, message).c_str(), "Test", MB_OK);
}

void LoggerMessageBox::Error(const char* expression, const char* message, const char* file, int line)
{
	MessageBox(NULL, format("%s, line %d: error from %s: %s\n", file, line, expression, message).c_str(), "Test", MB_OK);
}

void LoggerMessageBox::Message(const char* message, const char* filename, int line)
{
	MessageBox(NULL, format("%s, line %d: %s\n", filename, line, message).c_str(), "Message", MB_OK);
}
*/
// LoggerText
LoggerText::LoggerText(const char* Filename)
{
	file = fopen(Filename, "w");
}

LoggerText::~LoggerText()
{
	fclose(file);
}

void LoggerText::Flush()
{
	fflush(file);
}

void LoggerText::NewObject(const char* type, size_t size, const char* filename, int line)
{
	fprintf(file, "OBJECT ALLOCATED: %s, line %d: new object of %s, %d bytes\n", filename, line, type, size);
}

void LoggerText::NewArray(const char* type, size_t size, const char* filename, int line)
{
	fprintf(file, "ARRAY ALLOCATED: %s, line %d: new array of %s, %d bytes\n", filename, line, type, size);
}

void LoggerText::DeleteObject(const char* object, const char* filename, int line)
{
	fprintf(file, "OBJECT DELETED: %s, line %d: delete object from %s\n", filename, line, object);
}

void LoggerText::DeleteArray(const char* array, const char* filename, int line)
{
	fprintf(file, "ARRAY DELETED: %s, line %d: delete array from %s\n", filename, line, array);
}

void LoggerText::Test(const char* expression, bool result, const char* message, const char* filename, int line)
{
	fprintf(file, "TEST: %s, line %d: test of %s is %s\n", filename, line, expression, result ? "true" : "false");
}

void LoggerText::Warning(const char* expression, const char* message, const char* filename, int line)
{
	fprintf(file, "WARNING: %s, line %d: warning from %s: %s\n", filename, line, expression, message);
}

void LoggerText::Error(const char* expression, const char* message, const char* filename, int line)
{
	fprintf(file, "ERROR_TARGET: %s, line %d: error from %s: %s\n", filename, line, expression, message);
}

void LoggerText::Message(const char* message, const char* filename, int line)
{
	fprintf(file, "MESSAGE: %s, line %d: %s\n", filename, line, message);
}

// LoggerStream
LoggerStream::LoggerStream(FILE* Stream) :
	Stream(Stream)
{}

LoggerStream::~LoggerStream()
{}

void LoggerStream::NewObject(const char* type, size_t size, const char* filename, int line)
{
	fprintf(Stream, "OBJECT ALLOCATED: %s, line %d: new object of %s, %d bytes\n", filename, line, type, size);
}

void LoggerStream::NewArray(const char* type, size_t size, const char* filename, int line)
{
	fprintf(Stream, "ARRAY ALLOCATED: %s, line %d: new array of %s, %d bytes\n", filename, line, type, size);
}

void LoggerStream::DeleteObject(const char* object, const char* filename, int line)
{
	fprintf(Stream, "OBJECT DELETED: %s, line %d: delete object from %s\n", filename, line, object);
}

void LoggerStream::DeleteArray(const char* array, const char* filename, int line)
{
	fprintf(Stream, "ARRAY DELETED: %s, line %d: delete array from %s\n", filename, line, array);
}

void LoggerStream::Test(const char* expression, bool result, const char* message, const char* filename, int line)
{
	fprintf(Stream, "TEST: %s, line %d: test of %s is %s\n", filename, line, expression, result ? "true" : "false");
}

void LoggerStream::Warning(const char* expression, const char* message, const char* filename, int line)
{
	fprintf(Stream, "WARNING: %s, line %d: warning from %s: %s\n", filename, line, expression, message);
}

void LoggerStream::Error(const char* expression, const char* message, const char* filename, int line)
{
	fprintf(Stream, "ERROR_TARGET: %s, line %d: error from %s: %s\n", filename, line, expression, message);
}

void LoggerStream::Message(const char* message, const char* filename, int line)
{
	fprintf(Stream, "MESSAGE: %s, line %d: %s\n", filename, line, message);
}

}// namespace core
}// namespace o
