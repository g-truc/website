#include <core/precompiled.h>
#include <core/error/log_manager.h>

namespace o {
namespace core {

void LogDelete()
{
	Log::Destroy();
}

Log* Log::object = null;

Log* Log::Instance()
{
	if(object == null)
	{
		object = new_object(Log);
		atexit(LogDelete);
	}
	return object;
}

void Log::Destroy()
{
	delete_object(object);
}

Log::Log() :
	memoryAllocated(0),
	newObjectCount(0),
	deleteObjectCount(0),
	newArrayCount(0),
	deleteArrayCount(0),
	autoFlush(false)
{}

Log::~Log()
{
	for(std::multimap<flag, Logger*>::iterator it = loggerMap.begin(); it != loggerMap.end(); ++it)
	{
		it->second->Flush();
		delete_object(it->second);
	}
}

void Log::Register(flag target, Logger* logger)
{
	loggerMap.insert(std::make_pair(target, logger));
}

void Log::Flush()
{
	for(TLoggerMap::iterator it = loggerMap.begin(); it != loggerMap.end(); ++it)
		it->second->Flush();
}

void Log::NewObject(flag target, const char* type, size_t size, const char* file, int line)
{
	newObjectCount++;
	memoryAllocated += size;
	for(TLoggerMap::iterator it = loggerMap.begin(); it != loggerMap.end(); ++it)
		if(it->first & target)
			it->second->NewObject(type, size, file, line);
	if(autoFlush)
		Flush();
}

void Log::NewArray(flag target, const char* type, size_t size, const char* file, int line)
{
	newArrayCount++;
	memoryAllocated += size;
	for(TLoggerMap::iterator it = loggerMap.begin(); it != loggerMap.end(); ++it)
		if(it->first & target)
			it->second->NewArray(type, size, file, line);
	if(autoFlush)
		Flush();
}

void Log::DeleteObject(flag target, const char* object, const char* file, int line)
{
	deleteObjectCount++;
	for(TLoggerMap::iterator it = loggerMap.begin(); it != loggerMap.end(); ++it)
		if(it->first & target)
			it->second->DeleteObject(object, file, line);
	if(autoFlush)
		Flush();
}

void Log::DeleteArray(flag target, const char* array, const char* file, int line)
{
	deleteArrayCount++;
	for(TLoggerMap::iterator it = loggerMap.begin(); it != loggerMap.end(); ++it)
		if(it->first & target)
			it->second->DeleteArray(array, file, line);
	if(autoFlush)
		Flush();
}

void Log::Test(flag target, const char* expression, bool result, const char* message, const char* file, int line)
{
	for(TLoggerMap::iterator it = loggerMap.begin(); it != loggerMap.end(); ++it)
		if(it->first & target)
			it->second->Test(expression, result, message, file, line);
	if(autoFlush)
		Flush();
}

void Log::Warning(flag target, const char* expression, const char* message, const char* file, int line)
{
	for(TLoggerMap::iterator it = loggerMap.begin(); it != loggerMap.end(); ++it)
		if(it->first & target)
			it->second->Warning(expression, message, file, line);
	if(autoFlush)
		Flush();
}

void Log::Error(flag target, const char* expression, const char* message, const char* filename, int line)
{
	for(TLoggerMap::iterator it = loggerMap.begin(); it != loggerMap.end(); ++it)
		if(it->first & target)
			it->second->Error(expression, message, filename, line);
	if(autoFlush)
		Flush();
}

void Log::Message(flag target, const char* message, const char* filename, int line)
{
	//for(TLoggerMap::iterator it = loggerMap.lower_bound(target); it != loggerMap.upper_bound(target); ++it)
	for(TLoggerMap::iterator it = loggerMap.begin(); it != loggerMap.end(); ++it)
		if(it->first & target)
			it->second->Message(message, filename, line);
	if(autoFlush)
		Flush();
}

}//namespace core
}//namespace o
