#include <core/precompiled.h>
#include <core/error/error.h>
#include <core/error/log_xml.h>

namespace o {
namespace core {

void deleteError()
{
	Error::Destroy();
}

Error::Error()
{
	Log::Instance()->Register(ALL, LoggerXML::Create("log.xml"));
	atexit(deleteError);
}

Error::~Error()
{}

}//namespace core
}//namespace o
