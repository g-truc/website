#include <core/precompiled.h>
#include <core/component/manager.h>

namespace o {
namespace core {

// IMessage
IMessage::IMessage(handle SenderId, handle TypeId) :
	TypeId(TypeId),
	SenderId(SenderId),
	MessageId()
{}

// IComponent
IComponent::IComponent(handle ObjectId, handle TypeId) :
	TypeId(TypeId),
	ObjectId(ObjectId),
	ComponentId()
{}

// CObjectManager
CObjectManager::CObjectManager()
{}

CObjectManager::~CObjectManager()
{
	_Clear();
}

size_t CObjectManager::Size() const
{
	return _ComponentMap.size();
}

CObjectManager::iterator CObjectManager::Begin(handle TypeId)
{
	return _TypeMap.lower_bound(TypeId);
}

CObjectManager::const_iterator CObjectManager::Begin(handle TypeId) const
{
	return _TypeMap.lower_bound(TypeId);
}

CObjectManager::iterator CObjectManager::End(handle TypeId)
{
	return _TypeMap.upper_bound(TypeId);
}

CObjectManager::const_iterator CObjectManager::End(handle TypeId) const
{
	return _TypeMap.upper_bound(TypeId);
}

CObjectManager::iterator CObjectManager::Begin()
{
	return _TypeMap.begin();
}

CObjectManager::const_iterator CObjectManager::Begin() const
{
	return _TypeMap.begin();
}

CObjectManager::iterator CObjectManager::End()
{
	return _TypeMap.end();
}

CObjectManager::const_iterator CObjectManager::End() const
{
	return _TypeMap.end();
}

IComponent* CObjectManager::CreateComponent(const std::string& Key, handle ObjectId, IParameter* Parameter)
{
	// Create component instance
	IComponent* Component = CreateObject(Key, ObjectId, Parameter);

	_ObjectMap.insert(std::make_pair(Component->ObjectId, Component));
	_TypeMap.insert(std::make_pair(Component->TypeId, Component));
	_ComponentMap.insert(std::make_pair(Component->ComponentId, Component));

	return Component;
}

void CObjectManager::ReleaseComponent(EBroadcastTarget Target, handle Index)
{
	switch(Target)
	{
	case TARGET_TYPE:
		_ReleaseByType(Index);
		break;
	case TARGET_OBJECT:
		_ReleaseByObject(Index);
		break;
	case TARGET_COMPONENT:
		_ReleaseByComponent(Index);
		break;
	}
}

handle CObjectManager::FindComponentId(handle ObjectId, handle TypeId)
{
	handle Result = handle::Null();

	for(TTypeMap::iterator it = _TypeMap.lower_bound(TypeId); it != _TypeMap.upper_bound(TypeId); ++it)
	{
		if(it->second->ObjectId != ObjectId)
			continue;
		Result = it->second->ComponentId;
		break;
	}

	return Result;
}

void CObjectManager::Broadcast(EBroadcastTarget Target, handle Index, const IMessage* Message)
{
	_ClearReleaseList();

	switch(Target)
	{
	case TARGET_TYPE:
		_BroadcastByType(Index, Message);
		break;
	case TARGET_OBJECT:
		_BroadcastByObject(Index, Message);
		break;
	case TARGET_COMPONENT:
		_BroadcastByComponent(Index, Message);
		break;
	}
}

const IComponent* CObjectManager::GetComponent(handle ComponentId) const
{
	IComponent* Component = null;
	TComponentMap::const_iterator it = _ComponentMap.find(ComponentId);
	if(it != _ComponentMap.end())
		Component = it->second;
	return Component;
}

IComponent* CObjectManager::GetComponent(handle ComponentId)
{
	IComponent* Component = null;
	TComponentMap::iterator it = _ComponentMap.find(ComponentId);
	if(it != _ComponentMap.end())
		Component = it->second;
	return Component;
}

void CObjectManager::_BroadcastByType(handle TypeId, const IMessage* Message)
{
	TTypeMap::iterator it = _TypeMap.lower_bound(TypeId);
	if(it != _TypeMap.end())
	{
		while(it != _TypeMap.upper_bound(TypeId))
		{
			it->second->HandleMessage(Message);
			++it;
		}
	}
	else
	{
		// Warning: Message send to nothing 
	}

	//for(TTypeMap::iterator it = _TypeMap.lower_bound(TypeId); it != _TypeMap.upper_bound(TypeId); ++it)
	//	it->second->HandleMessage(Message);
}

void CObjectManager::_BroadcastByObject(handle ObjectId, const IMessage* Message)
{
	TObjectMap::iterator it = _ObjectMap.lower_bound(ObjectId);
	if(it != _ObjectMap.end())
	{
		while(it != _ObjectMap.upper_bound(ObjectId))
		{
			it->second->HandleMessage(Message);
			++it;
		}
	}
	else
	{
		// Warning: Message send to nothing 
	}

	//for(TObjectMap::iterator it = _ObjectMap.lower_bound(ObjectId); it != _ObjectMap.upper_bound(ObjectId); ++it)
	//	it->second->HandleMessage(Message);
}

void CObjectManager::_BroadcastByComponent(handle ComponentId, const IMessage* Message)
{
	TComponentMap::iterator it = _ComponentMap.find(ComponentId);
	if(it != _ComponentMap.end())
		it->second->HandleMessage(Message);
	else
	{
		// Warning: Message send to nothing
	}
}

void CObjectManager::_ReleaseByType(handle TypeId)
{
	TTypeMap::iterator it = _TypeMap.lower_bound(TypeId);
	if(it != _TypeMap.end())
	{
		// Copy components pointers in the release list
		while(it != _TypeMap.upper_bound(TypeId))
		{
			// Copy components pointers in the release list
			_ReleaseList.push_back(it->second);

			// Delete the component pointer from the map sorted by component object identifier
			for(TObjectMap::iterator it2 = _ObjectMap.begin(); it2 != _ObjectMap.end(); ++it2)
			if(it2->second->ComponentId == it->second->ComponentId)
			{
				_ObjectMap.erase(it2);
				break;
			}

			// Delete the component pointer from the map sorted by component identifier
			_ComponentMap.erase(it->second->ComponentId);
		}

		// Erase components pointers from the map sorted by object identifier
		_TypeMap.erase(_TypeMap.lower_bound(TypeId), _TypeMap.upper_bound(TypeId));
	}
	else
	{
		// Warning: Message send to nothing 
	}
}

void CObjectManager::_ReleaseByObject(handle ObjectId)
{
	TObjectMap::iterator it = _ObjectMap.lower_bound(ObjectId);
	if(it != _ObjectMap.end())
	{
		while(it != _ObjectMap.upper_bound(ObjectId))
		{
			// Copy components pointers in the release list
			_ReleaseList.push_back(it->second);

			// Delete the component pointer from the map sorted by component type
			for(TTypeMap::iterator it2 = _TypeMap.begin(); it2 != _TypeMap.end(); ++it2)
			if(it2->second->ComponentId == it->second->ComponentId)
			{
				_TypeMap.erase(it2);
				break;
			}

			// Delete the component pointer from the map sorted by component identifier
			_ComponentMap.erase(it->second->ComponentId);
		}

		// Erase components pointers from the map sorted by object identifier
		_ObjectMap.erase(_ObjectMap.lower_bound(ObjectId), _ObjectMap.upper_bound(ObjectId));
	}
	else
	{
		// Warning: Message send to nothing 
	}
}

void CObjectManager::_ReleaseByComponent(handle ComponentId)
{
	TComponentMap::iterator it = _ComponentMap.find(ComponentId);
	if(it != _ComponentMap.end())
	{
		_ReleaseList.push_back(it->second);

		// Delete the component pointer from the map sorted by component object identifier
		for(TObjectMap::iterator it2 = _ObjectMap.begin(); it2 != _ObjectMap.end(); ++it2)
		if(it2->second->ComponentId == ComponentId)
		{
			_ObjectMap.erase(it2);
			break;
		}

		// Delete the component pointer from the map sorted by component type
		for(TTypeMap::iterator it2 = _TypeMap.begin(); it2 != _TypeMap.end(); ++it2)
		if(it2->second->ComponentId == ComponentId)
		{
			_TypeMap.erase(it2);
			break;
		}

		_ComponentMap.erase(ComponentId);
	}
	else
	{
		// Warning: No Component for this identifier
	}
}

void CObjectManager::_ClearReleaseList()
{
	for(TReleaseList::iterator it = _ReleaseList.begin(); it != _ReleaseList.end(); ++it)
		delete *it;
	_ReleaseList.clear();
}

void CObjectManager::_Clear()
{
	// Free all components in the release list
	_ClearReleaseList();

	// Free all components in component maps
	for(TComponentMap::iterator it = _ComponentMap.begin(); it != _ComponentMap.end(); ++it)
		delete it->second;
	_ComponentMap.clear();
	_TypeMap.clear();
	_ObjectMap.clear();
}

}//namespace core
}//namespace o
