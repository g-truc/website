#ifndef __RES_TEXT_H__
#define __RES_TEXT_H__

#include <orange.h>

class CText : public o::core::IAsset, public o::core::IType<CText>
{
	friend class o::core::CCreator<o::core::IAsset, CText>;

public:
	static CText* Create(const char* Filename);
	static void Release(CText* Text);

	virtual bool Load(const o::core::PResource& Resource);
	virtual handle GetType() const{return CText::Type;}

	void Print() const;

private:
	CText();
	~CText();

	std::string _Content;
};

#endif//__RES_TEXT_H__
