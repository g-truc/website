#include <orange.h>

class Class1
{
public:
	Class1() : integer(0) {printf("Class1 Constructor\n");}
	~Class1(){printf("Class1 Destructor\n");}

private:
	int integer;
};

class Class2
{
public:
	Class2() : integer(0) {printf("Class2 Constructor\n");}
	~Class2(){printf("Class2 Destructor\n");}

private:
	int integer;
};

class Class3
{
public:
	Class3(int i) : integer(i) {printf("Class3 Constructor\n");}
	~Class3(){printf("Class3 Destructor\n");}

private:
	int integer;
};

void info()
{
	// Display all allocated objects information
	o::core::CMemoryManager* MemoryManager = o::core::CMemoryManager::GetInstance();
	for(o::core::CMemoryManager::const_iterator it = MemoryManager->Begin(); it != MemoryManager->End(); ++it)
	{
		printf("====================\n");
		printf("Type: %s\n", it->second.Typename.c_str());
		printf("Memory size: %d bytes, %d bytes per element\n", it->second.FullSize, it->second.TypeSize);
		printf("Allocation from line %d of %s\n", it->second.Line, it->second.Filename.c_str());
		if(sizeof(void*) == 8)
			printf("64 bits Address: %.16x\n", it->first);
		else // if(sizeof(void*) == 4)
			printf("32 bits Address: %.8x\n", it->first);
	}
}

int main()
{
	info();

	// Memory allocation for one object, like "new Class" in this sample
	Class1* Object = new_object(Class1);
	// Memory allocation for array, like "new Class[2]" in this sample
	Class2* Array = new_array(Class2, 2);

	info();

	// Free memory for one object, like "delete Object" in this sample
	delete_object(Object);
	// Free memory for an array, like "delete[] Array" in this sample
	delete_array(Array);
	// delete_***** macro are safe delete, the pointer takes null value

	info();
/*
	// When parameters are used new_object can't be used, memory must be registred wish register_custom
	// Create an instance with one parameter. To use more than one parameter, process like this : new_custom(Class3)(1, 1.0f, "Hi");
	Class3* Register = new_custom(Class3)(1);
	register_custom(Class3, Register);
	delete_custom(Register);
*/
	system("pause");

	return 0;
}
