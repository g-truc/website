#include "precompiled.h"
#include "component_test1.h"
#include "component_test2.h"

int main()
{
	// Register componants
	o::core::CObjectManager* ObjectManager = o::core::CObjectManager::GetInstance();
	ObjectManager->Register("test1", o::core::ComponentCreator<CTestComponent1>());
	ObjectManager->Register("test2", o::core::ComponentCreator<CTestComponent2>());

	// Create an object identifier
	handle ObjectId;

	// Create a component
	CTestParameter1 TestParameter1;
	CTestComponent1* TestComponent1 = static_cast<CTestComponent1*>(ObjectManager->CreateComponent("test1", ObjectId, &TestParameter1));

	// Create 2 instances of CTestComponent2
	CTestComponent2* TestComponent2a = static_cast<CTestComponent2*>(ObjectManager->CreateComponent("test2", ObjectId, null));
	CTestComponent2* TestComponent2b = static_cast<CTestComponent2*>(ObjectManager->CreateComponent("test2", ObjectId, null));

	// Call a user function of TestComponent1 that send a message to all CTestComponent2 instances
	TestComponent1->Update();

	// Use iterator to go over CTestComponent2 instances
	for(o::core::CObjectManager::iterator it = ObjectManager->Begin(CTestComponent2::Type); it != ObjectManager->End(CTestComponent2::Type); ++it)
		static_cast<CTestComponent2*>(it->second)->Print();

	// Use iterator to go over all components
	for(o::core::CObjectManager::iterator it = ObjectManager->Begin(); it != ObjectManager->End(); ++it)
		static_cast<ITestComponent*>(it->second)->Print();

	// Return the number of component instances
	printf("Number of components: %d\n", ObjectManager->Size());

	// Delete a component
	ObjectManager->ReleaseComponent(o::core::TARGET_COMPONENT, TestComponent1->ComponentId);

	// Send a message to no one, use to flush the release list
	ObjectManager->Broadcast(o::core::TARGET_COMPONENT, handle::Null(), null);

	printf("Number of components: %d\n", ObjectManager->Size());

	system("pause");

	return 0;
}
