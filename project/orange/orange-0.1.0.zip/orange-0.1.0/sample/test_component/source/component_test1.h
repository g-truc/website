#ifndef __COMPONENT_TEST1_H__
#define __COMPONENT_TEST1_H__

#include "component_test.h"

class CTestParameter1 : public o::core::IParameter
{
public:
	CTestParameter1();

	const handle TypeId;
};

class CTestComponent1 : public ITestComponent, public o::core::IType<CTestComponent1>
{
//	friend class o::core::CObjectManager;
//	friend class o::core::CComponentCreator<CTestComponent1>;

public:
	CTestComponent1(handle ObjectId, const o::core::IParameter* Parameter);
	virtual ~CTestComponent1(){}

public:
	void Update();
	virtual void Print();

	virtual bool HandleMessage(const o::core::IMessage* Message){return true;}
};

#endif//__COMPONENT_TEST1_H__
