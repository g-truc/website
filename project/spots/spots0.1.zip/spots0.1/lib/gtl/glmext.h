//////////////////////////////////////////////////////////////////////////////////
// OpenGL Mathematics Copyright (c) 2005 G-Truc Creation (www.g-truc.net)
//////////////////////////////////////////////////////////////////////////////////
// Groove (groove[at]g-truc.net)
// Created : 2005-01-14
// Updated : 2005-04-03
// Licence : This source is under GNU LGPL licence
//////////////////////////////////////////////////////////////////////////////////

#ifndef __glmext_h__
#define __glmext_h__

#if defined(_WINDOWS_) || defined(_WINDOWS_H)
#error windows.h included before glmext.h
#endif

#include "./glm.h"
#include "./glm/gtc/gtc.h"
#include "./glm/gtx/gtx.h"

#endif //__glmext_h__
