//////////////////////////////////////////////////////////////////////////////////
// OpenGL Mathematics Copyright (c) 2005 G-Truc Creation (www.g-truc.net)
//////////////////////////////////////////////////////////////////////////////////
// Author  : Groove (groove[at]g-truc.net)
// Created : 2005-01-27
// Updated : 2005-02-27
// Licence : This source is under GNU LGPL licence
// File    : _mat4.h
//////////////////////////////////////////////////////////////////////////////////

#ifndef __mat4_h__
#define __mat4_h__

namespace glm
{
    template <typename T> class _xvec4;

    template <typename T> class _xmat4
    {
    private:
        // Data
        _xvec4<T> value[4];

    public:
        int _size () const {return 4;}

    public:
        // Constructor
	    _xmat4();
        _xmat4(const T x);
        _xmat4(const T x0, const T y0, const T z0, const T w0,
               const T x1, const T y1, const T z1, const T w1,
               const T x2, const T y2, const T z2, const T w2,
               const T x3, const T y3, const T z3, const T w3);
	    _xmat4(const _xvec4<T> & v0, 
               const _xvec4<T> & v1,
               const _xvec4<T> & v2,
               const _xvec4<T> & v3);

        // Accesses
        _xvec4<T>& operator[](int i) {return value[i];}
        const _xvec4<T> & operator[](int i) const {return value[i];}
        operator T*() {return &value[0][0];}
	    operator const T*() const {return &value[0][0];}

        // Operators
        _xmat4<T> & operator= (const _xmat4<T> & m);
	    _xmat4<T> operator+ (const _xmat4<T> & m) const;
	    _xmat4<T> & operator+= (const _xmat4<T> & m);
	    _xmat4<T> operator- (const _xmat4<T> & m) const;
	    _xmat4<T> & operator-= (const _xmat4<T> & m);
	    _xmat4<T> operator* (const T s) const;
	    _xmat4<T> & operator*= (const T s);
        _xvec4<T> operator* (const _xvec4<T> & v) const;
	    _xmat4<T> operator/ (const T s) const;
	    _xmat4<T> & operator/= (const T s);
        _xmat4<T> operator* (const _xmat4<T> & m) const;
	    _xmat4<T> & operator*= (const _xmat4<T> & m);
        _xmat4<T> operator/ (const _xmat4<T> & m) const;
	    _xmat4<T> & operator/= (const _xmat4<T> & m);
	    _xmat4<T> operator- () const;
        _xmat4<T> operator++ ();
	    _xmat4<T> operator++ (int n) const;
	    _xmat4<T> operator-- ();
	    _xmat4<T> operator-- (int n) const;
    };

    template <typename T> _xmat4<T> operator* (const T s, const _xmat4<T> & m)
    {
        return m * s;
    }

    template <typename T> _xvec4<T> operator* (const _xvec4<T> & v, const _xmat4<T> & m)
    {
        _xmat3<T> Transpose;
        Transpose[0][0] = m[0][0];
        Transpose[1][0] = m[0][1];
        Transpose[2][0] = m[0][2];
        Transpose[3][0] = m[0][3];

        Transpose[0][1] = m[1][0];
        Transpose[1][1] = m[1][1];
        Transpose[2][1] = m[1][2];
        Transpose[3][1] = m[1][3];

        Transpose[0][2] = m[2][0];
        Transpose[1][2] = m[2][1];
        Transpose[2][2] = m[2][2];
        Transpose[3][2] = m[2][3];

        Transpose[0][3] = m[3][0];
        Transpose[1][3] = m[3][1];
        Transpose[2][3] = m[3][2];
        Transpose[3][3] = m[3][3];
        return Transpose * v;
    }
} //namespace glm

#endif //__mat4_h__
