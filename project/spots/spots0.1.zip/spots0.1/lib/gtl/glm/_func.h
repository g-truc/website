//////////////////////////////////////////////////////////////////////////////////
// OpenGL Mathematics Copyright (c) 2005 G-Truc Creation (www.g-truc.net)
//////////////////////////////////////////////////////////////////////////////////
// Author  : Groove (groove[at]g-truc.net)
// Created : 2005-01-12
// Updated : 2005-02-15
// Licence : This source is under GNU LGPL licence
// File    : _func.h
//////////////////////////////////////////////////////////////////////////////////

#ifndef __func_h__
#define __func_h__

/*!
 *  \brief OpenGL Mathematics
 *  \author Christophe [Groove] Riccio
 *  \version 0.2
 *  \date    2005
 *  \bug boarf 1.
 *  \bug boarf 2.
 *  \warning ark 1.
 *  \warning ark 2.
 */

#include "./_vec2.h"
#include "./_vec3.h"
#include "./_vec4.h"
/*#ifdef WIN32
#pragma warning (disable : 4244)
#endif //WIN32
*/
namespace glm
{
    ////////////////////////////////////////////////////////////////////////
    // Trigonometric Functions

    //! \brief Convert a angle from degrees to radians.
    //! \param degrees A angle express in degrees.
    //! \return A angle express in radians
    template <typename genType> genType radians(const genType & degrees);
    template <typename genType> genType degrees(const genType & radians);
    template <typename genType> genType sin(const genType & angle);
    float sin(float angle);
    template <typename genType> genType cos(const genType & angle);
    float cos(float angle);
    template <typename genType> genType tan(const genType & angle);
    float tan(float angle);
    template <typename genType> genType asin(const genType & x);
    float asin(float x);
    template <typename genType> genType acos(const genType & x);
    float acos(float x);
    template <typename genType> genType atan(const genType & y, const genType & x);
    float atan(float y, float x);
    template <typename genType> genType atan(const genType & y_over_x);
    float atan(float y_over_x);

    ////////////////////////////////////////////////////////////////////////
    // Exponential Functions

    template <typename genType> genType pow(const genType & x, const genType & y);
    float pow(float x, float y);
    template <typename genType> genType exp(const genType & x);
    float exp(float x);
    template <typename genType> genType log(const genType & x);
    float log(float x);
    template <typename genType> genType exp2(const genType & x);
    float exp2(float x);
    template <typename genType> genType log2(const genType & x);
    float log2(float x);
    template <typename genType> genType sqrt(const genType & x);
    float sqrt(float x);
    template <typename genType> genType inversesqrt(const genType & x);
    float inversesqrt(float x);

    ////////////////////////////////////////////////////////////////////////
    // Common Functions

    template <typename genType> genType abs(const genType & x);
    float abs(float x);
    template <typename genType> genType sign(const genType & x);
    float sign(float x);
    template <typename genType> genType floor(const genType & x);
    float floor(float x);
    template <typename genType> genType ceil(const genType & x);
    float ceil(float x);
    template <typename genType> genType fract(const genType & x);
    float fract(float x);
    template <typename genType> genType mod(const genType & x, float y);
    template <typename genType> genType mod(const genType & x, const genType & y);
    float mod(float x, float y);
    float min(float x, float y);
    template <typename genType> genType min(const genType & x, float y);
    template <typename genType> genType min(const genType & x, const genType & y);
    float max(float x, float y);
    template <typename genType> genType max(const genType & x, float y);
    template <typename genType> genType max(const genType & x, const genType & y);
    float clamp(float x, float minVal, float maxVal);
    template <typename genType> genType clamp(const genType & x, float minVal, float maxVal);
    template <typename genType> inline genType clamp(const genType & x, const genType & minVal, const genType & maxVal);
    float mix(float x, float y, float a);
    template <typename genType> genType mix(const genType & x, const genType & y, const genType & a);
    template <typename genType> genType mix(const genType & x, const genType & y, float a);
    float step(float edge, float x);
    template <typename genType> genType step(float edge, const genType & x);
    template <typename genType> genType step(const genType & edge, const genType & x);
    float smoothstep(float edge0, float edge1, float x);
    template <typename genType> genType smoothstep(float edge0, float edge1, const genType & x);
    template <typename genType> genType smoothstep(const genType & edge0, const genType & edge1, const genType & x);

    ////////////////////////////////////////////////////////////////////////
    // Geometric Functions

    template <typename genType> float length(const genType & x);
    float length(float x);
    template <typename genType> float distance(const genType & p0, const genType & p1);
    template <typename genType> float dot(const genType & x, const genType & y);
    float dot(float v1, float v2);
    template <typename T> _xvec3<T> cross(const _xvec3<T> & x, const _xvec3<T> & y);
    /*! 
     *  \brief Return a vector with a norm equal to 1.
     *  \param The vector witch need to be normelized.
     *  \exception if x is null then the returned value is undefined
     */
    template <typename genType> genType normalize(const genType & x);
    float normalize(float x);
    template <typename genType> genType faceforward(const genType & N, const genType & I, const genType & Nref);
    template <typename genType> genType reflect(const genType & I, const genType & N);
    template <typename genType> genType refract(const genType & I, const genType & N, float eta);

    ////////////////////////////////////////////////////////////////////////
    // Matrix Functions

    template <typename genType> genType matrixCompMult(const genType & x, const genType & y);

    ////////////////////////////////////////////////////////////////////////
    // Vector Relational Functions

    template <typename T> _bvec2 lessThan(const _xvec2<T> & x, const _xvec2<T> & y);
    template <typename T> _bvec3 lessThan(const _xvec3<T> & x, const _xvec3<T> & y);
    template <typename T> _bvec4 lessThan(const _xvec4<T> & x, const _xvec4<T> & y);
    template <typename T> _bvec2 lessThanEqual(const _xvec2<T> & x, const _xvec2<T> & y);
    template <typename T> _bvec3 lessThanEqual(const _xvec3<T> & x, const _xvec3<T> & y);
    template <typename T> _bvec4 lessThanEqual(const _xvec4<T> & x, const _xvec4<T> & y);
    template <typename T> _bvec2 greaterThan(const _xvec2<T> & x, const _xvec2<T> & y);
    template <typename T> _bvec3 greaterThan(const _xvec3<T> & x, const _xvec3<T> & y);
    template <typename T> _bvec4 greaterThan(const _xvec4<T> & x, const _xvec4<T> & y);
    template <typename T> _bvec2 greaterThanEqual(const _xvec2<T> & x, const _xvec2<T> & y);
    template <typename T> _bvec3 greaterThanEqual(const _xvec3<T> & x, const _xvec3<T> & y);
    template <typename T> _bvec4 greaterThanEqual(const _xvec4<T> & x, const _xvec4<T> & y);
    template <typename T> _bvec2 equal(const _xvec2<T> & x, const _xvec2<T> & y);
    _bvec2 equal(const _bvec2 & x, const _bvec2 & y);
    template <typename T> _bvec3 equal(const _xvec3<T> & x, const _xvec3<T> & y);
    _bvec3 equal(const _bvec3 & x, const _bvec3 & y);
    template <typename T> _bvec4 equal(const _xvec4<T> & x, const _xvec4<T> & y);
    _bvec4 equal(const _bvec4 & x, const _bvec4 & y);
    template <typename T> _bvec2 notEqual(const _xvec2<T> & x, const _xvec2<T> & y);
    _bvec2 notEqual(const _bvec2 & x, const _bvec2 & y);
    template <typename T> _bvec3 notEqual(const _xvec3<T> & x, const _xvec3<T> & y);
    _bvec3 notEqual(const _bvec3 & x, const _bvec3 & y);
    template <typename T> _bvec4 notEqual(const _xvec4<T> & x, const _xvec4<T> & y);
    _bvec4 notEqual(const _bvec4 & x, const _bvec4 & y);
    template <typename T> bool any(const T & x);
    template <typename T> bool all(const T & x);
#ifdef CC_VC71 // With VC compiler the C++ key word 'not' isn't define
    template <typename genType> genType not(const genType & x);
#elif CC_GCC3
    // ! overloading to replace not bug 3
    template <typename genType> genType operator not(const genType & x);
#endif

    ////////////////////////////////////////////////////////////////////////
    // Noise Functions

    float noise1(float x);
    template <typename genType> float noise1(const genType & x);
    glm::_xvec2<float> noise2(float x);
    template <typename genType> glm::_xvec2<float> noise2(const genType & x);
    glm::_xvec3<float> noise3(float x);
    template <typename genType> glm::_xvec3<float> noise3(const genType & x);
    glm::_xvec4<float> noise4(float x);
    template <typename genType> glm::_xvec4<float> noise4(const genType & x);
    
} //namespace glm

#endif //__func_h__
