//////////////////////////////////////////////////////////////////////////////////
// OpenGL Mathematics Copyright (c) 2005 G-Truc Creation (www.g-truc.net)
//////////////////////////////////////////////////////////////////////////////////
// Author  : Groove (groove[at]g-truc.net)
// Created : 2005-01-10
// Updated : 2005-02-02
// Licence : This source is under GNU LGPL licence
// File    : _vec2.h
//////////////////////////////////////////////////////////////////////////////////

#ifndef __vec2_h__
#define __vec2_h__

namespace glm
{
    template <typename T> class _xvec3;
    template <typename T> class _xvec4;
    class _bvec2;

    // vec2 and ivec2 declaration
    template <typename T> 
    class _xvec2
    {
    public:
        int _size() const;

    public:
        // Data
        /* ISO C++ version unavailable with VC7.1 ...
            union{T x, r, s;};
            union{T y, g, t;};
        */
        // Solution away from ISO C++ but available with VC7.1 and GCC without -pedantic
        union 
        {
            struct{T x, y;};
            struct{T r, g;};
            struct{T s, t;};
        };

	    // Constructors
        _xvec2();
	    _xvec2(const T x, const T y);
        _xvec2(T f);

        // Convertions
        _xvec2(const _xvec3<T> & v);
        _xvec2(const _xvec4<T> & v);
        _xvec2(const _bvec2 & v);

        template <typename U>
        _xvec2(const _xvec2<U> & v)
        {
            this->x = T(v.x);
            this->y = T(v.y);
        }

        // Accesses
        T& operator[](int i);
        T operator[](int i) const;
        operator T*();
	    operator const T*() const;

        // Operators
	    _xvec2<T> operator+ (const T s) const;
	    _xvec2<T> & operator+= (const T s);
        _xvec2<T> operator+ (const _xvec2<T> & v) const;
	    _xvec2<T> & operator+= (const _xvec2<T> & v);
	    _xvec2<T> operator- (const T s) const;
	    _xvec2<T> & operator-= (const T s);
	    _xvec2<T> operator- (const _xvec2<T> & v) const;
	    _xvec2<T> & operator-= (const _xvec2<T> & v);
	    _xvec2<T> operator* (const T s) const;
	    _xvec2<T> & operator*= (const T s);
	    _xvec2<T> operator* (const _xvec2<T> & v) const;
	    _xvec2<T> & operator*= (const _xvec2<T> & v);
	    _xvec2<T> operator/ (const T s) const;
	    _xvec2<T> & operator/= (const T s);
	    _xvec2<T> operator/ (const _xvec2<T> & v) const;
	    _xvec2<T> & operator/= (const _xvec2<T> & v);
        _xvec2<T> operator- () const;
        _xvec2<T> operator++ ();
	    _xvec2<T> operator++ (int n) const;
	    _xvec2<T> operator-- ();
	    _xvec2<T> operator-- (int n) const;
    };

    template <typename T> _xvec2<T> operator+ (const T s, const _xvec2<T> & v)
    {
        return v + s;
    }

    template <typename T> _xvec2<T> operator- (const T s, const _xvec2<T> & v)
    {
        _xvec2<T> result;
        result.x = s - v.x;
        result.y = s - v.y;
        return result;
    }

    template <typename T> _xvec2<T> operator* (const T s, const _xvec2<T> & v)
    {
        return v * s;
    }

    //////////////////////////////////////////////////////////

    class _bvec3;
    class _bvec4;

    // bvec2 declaration
    class _bvec2
    {
    public:
        int _size () const;

    public:
        // Data
        union{bool x, r, s;};
        union{bool y, g, t;};

        // Constructors
	    _bvec2();
	    _bvec2(const bool x, const bool y);
        _bvec2(bool b);
	    _bvec2(const _bvec3 & v);
        _bvec2(const _bvec4 & v);

        // Convertions
        template <typename U>
        _bvec2(const _xvec2<U> & v)
        {
            this->x = bool(v.x);
            this->y = bool(v.y);
        }

        // Accesses
        bool& operator[](int i);
        bool operator[](int i) const;
        operator bool*();
	    operator const bool*() const;

        // Operators
	    _bvec2 operator-- ();
	    _bvec2 operator-- (int n) const;
        _bvec2 operator++ ();
	    _bvec2 operator++ (int n) const;
	    _bvec2 operator! () const;
    };
} //namespace glm

#endif //__vec2_h__
