//////////////////////////////////////////////////////////////////////////////////
// OpenGL Mathematics Copyright (c) 2005 G-Truc Creation (www.g-truc.net)
//////////////////////////////////////////////////////////////////////////////////
// Author  : Groove (groove[at]g-truc.net)
// Created : 2005-03-04
// Updated : 2005-03-04
// Licence : This source is under GNU LGPL licence
// File    : _sampler.h
//////////////////////////////////////////////////////////////////////////////////

#ifndef __sampler_h__
#define __sampler_h__

namespace glm
{
    class _sampler
    {
    private:
        unsigned int value;

    public:
        _sampler & operator= (unsigned int sampler);
        operator const unsigned int() const;
    };
}

#include "_sampler.inl"

#endif //__sampler_h__
