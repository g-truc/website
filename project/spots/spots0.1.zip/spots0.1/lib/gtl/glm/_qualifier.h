//////////////////////////////////////////////////////////////////////////////////
// OpenGL Mathematics Copyright (c) 2005 G-Truc Creation (www.g-truc.net)
//////////////////////////////////////////////////////////////////////////////////
// Author  : Groove (groove[at]g-truc.net)
// Created : 2005-03-04
// Updated : 2005-03-04
// Licence : This source is under GNU LGPL licence
// File    : _qualifier.h
//////////////////////////////////////////////////////////////////////////////////

#ifndef __qualifier_h__
#define __qualifier_h__

#ifndef uniform
#define uniform
#endif

#ifndef attrib
#define attrib
#endif

#ifndef in
#define in
#endif

#ifndef out
#define out
#endif

#ifndef inout
#define inout
#endif

#include "_qualifier.inl"

#endif //__qualifier_h__
