//////////////////////////////////////////////////////////////////////////////////
// OpenGL Mathematics Copyright (c) 2005 G-Truc Creation (www.g-truc.net)
//////////////////////////////////////////////////////////////////////////////////
// Groove (groove[at]g-truc.net)
// Created : 2005-02-28
// Updated : 2005-04-23
// Licence : This source is under GNU LGPL licence
// File : _ext.h
//////////////////////////////////////////////////////////////////////////////////

#ifndef __ext_h__
#define __ext_h__

#include "../../glm.h"
#include "./_quat.h"

namespace glm
{
    // GLM_GT_quaternion
    template <typename T> float length(const _quat<T> & q);
    template <typename T> _quat<T> normalize(const _quat<T> & q);
    template <typename T> _quat<T> dot(const _quat<T> & q1, const _quat<T> & q2);
    template <typename T> _quat<T> cross(const _quat<T> & q1, const _quat<T> & q2);
    template <typename T> _quat<T> mix(const _quat<T> & x, const _quat<T> & y, float a);
    template <typename T> _quat<T> pow(const _quat<T> & x, T y);

    template <typename T> _quat<T> conjugateGT(const _quat<T> & q);
    template <typename T> _quat<T> inverseGT(const _quat<T> & q);
    template <typename T> _quat<T> rotateGT(const _quat<T> & q, float angle, float x, float y, float z);
    template <typename T> _quat<T> squadGT(const _quat<T> & x, const _quat<T> & y, float s1, float s2, float a);
    template <typename T> float rotationAngleGT(const _quat<T> & x);
    template <typename T> _xvec3<T> rotationAxisGT(const _quat<T> & x);
    template <typename T> _xmat3<T> mat3GT(const _quat<T> & x);
    template <typename T> _xmat4<T> mat4GT(const _quat<T> & x);
    template <typename T> _quat<T> quatGT(const _xmat3<T> & x);
    template <typename T> _quat<T> quatGT(const _xmat4<T> & x);

    // GLM_GT_transform
    template <typename T> _xmat4<T> translate3DGT(const _xmat4<T> & m, T x, T y, T z);
    template <typename T> _xmat4<T> rotate3DGT(const _xmat4<T> & m, T angle, T x, T y, T z);
    template <typename T> _xmat3<T> rotate3DGT(const _xmat3<T> & m, T angle, T x, T y, T z);
    template <typename T> _xmat4<T> scale3DGT(const _xmat4<T> & m, T x, T y, T z);
    template <typename T> _xmat3<T> scale3DGT(const _xmat3<T> & m, T x, T y, T z);
    template <typename T> _xmat3<T> translate2DGT(const _xmat3<T> & m, T x, T y);
    template <typename T> _xmat3<T> rotate2DGT(const _xmat3<T> & m, T angle, T x, T y);
    template <typename T> _xmat2<T> rotate2DGT(const _xmat2<T> & m, T angle, T x, T y);
    template <typename T> _xmat3<T> scale2DGT(const _xmat3<T> & m, T x, T y);
    template <typename T> _xmat2<T> scale2DGT(const _xmat2<T> & m, T x, T y);

    // GLM_GT_transpose
    template <typename T> _xmat2<T> transposeGT(const _xmat2<T> & m);
    template <typename T> _xmat3<T> transposeGT(const _xmat3<T> & m);
    template <typename T> _xmat4<T> transposeGT(const _xmat4<T> & m);

    // GLM_GT_orthonormalize
    template <typename T> _xmat3<T> orthonormalizeGT(const _xmat3<T> & m);

    // GLM_GT_inverse
    template <typename T> _xmat2<T> inverseGT(const _xmat2<T> & m);
    template <typename T> _xmat3<T> inverseGT(const _xmat3<T> & m);
    template <typename T> _xmat4<T> inverseGT(const _xmat4<T> & m);

    // GLM_GT_determinant
    template <typename T> T determinantGT(const _xmat2<T> & m);
    template <typename T> T determinantGT(const _xmat3<T> & m);
    template <typename T> T determinantGT(const _xmat4<T> & m);

    // GLM_GT_length2
    template <typename genType> float length2GT(const genType & x);
    float length2GT(float x);
    template <typename T> float length2GT(const _quat<T> & q);

    // GLM_GT_matrix_cross_product
    template <typename T> _xmat3<T> matrixCross3GT(const _xvec3<T> & x);
    template <typename T> _xmat4<T> matrixCross4GT(const _xvec3<T> & x);

    // GLM_GT_projection
	template <typename T> _xvec2<T> projGT(const _xvec2<T> & x, const _xvec2<T> & Normal);
    template <typename T> _xvec3<T> projGT(const _xvec3<T> & x, const _xvec3<T> & Normal);
    template <typename T> _xvec4<T> projGT(const _xvec4<T> & x, const _xvec4<T> & Normal);

    // GLM_GT_perpendicular
	template <typename T> _xvec2<T> perpGT(const _xvec2<T> & x, const _xvec2<T> & Normal);
    template <typename T> _xvec3<T> perpGT(const _xvec3<T> & x, const _xvec3<T> & Normal);
    template <typename T> _xvec4<T> perpGT(const _xvec4<T> & x, const _xvec4<T> & Normal);

    // GLM_GT_optimum_pow
    template <typename genType> genType pow2GT(const genType & x);
    template <typename genType> genType pow3GT(const genType & x);

    // GLM_GT_double

    // GLM_GT_color_space
    template <typename genType> genType rgbGT(const genType & hsv);
    template <typename genType> genType hsvGT(const genType & rgb);

    // GLM_GT_vector_comp_mult
    template <typename T> _xvec2<T> vectorCompMultGT(const _xmat2<T> & x, const _xvec2<T> & y);
    template <typename T> _xvec3<T> vectorCompMultGT(const _xmat3<T> & x, const _xvec3<T> & y);
    template <typename T> _xvec4<T> vectorCompMultGT(const _xmat4<T> & x, const _xvec4<T> & y);
}

#endif //__ext_h__
