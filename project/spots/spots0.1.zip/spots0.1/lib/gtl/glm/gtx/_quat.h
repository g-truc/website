//////////////////////////////////////////////////////////////////////////////////
// OpenGL Mathematics Copyright (c) 2005 G-Truc Creation (www.g-truc.net)
//////////////////////////////////////////////////////////////////////////////////
// Author  : Groove (groove[at]g-truc.net)
// Created : 2005-04-03
// Updated : 2005-04-03
// Licence : This source is under GNU LGPL licence
// File    : _quat.h
//////////////////////////////////////////////////////////////////////////////////

#ifndef __quat_h__
#define __quat_h__

namespace glm
{
    template <typename T> class _xvec3;
    template <typename T> class _xvec4;

    // __quatGTX declaration
    template <typename T> class _quat
    {
    public:
        T x, y, z, w;

	    // Constructors
        _quat();
	    _quat(const _xvec3<T> x, const T y);
        _quat(const T x, const T y, const T z, const T w);

        // Convertions
        _quat(const _xvec4<T> x);

        // Accesses
        T& operator[](int i);
        T operator[](int i) const;
        operator T*();
	    operator const T*() const;

        // Operators
        _quat<T>  operator+ (const _quat<T> & q) const;
        _quat<T>& operator+=(const _quat<T> & q);
        _quat<T>  operator- (const _quat<T> & q) const;
        _quat<T>& operator-=(const _quat<T> & q);
        _quat<T>  operator* (T s) const;
        _quat<T>& operator*=(T s);
        _quat<T>  operator* (const _quat<T> & q) const;
        _quat<T>& operator*=(const _quat<T> & q);
        _quat<T>  operator/ (T s) const;
        _quat<T>& operator/=(T s);
        _quat<T>  operator/ (const _quat<T> & q) const;
        _quat<T>& operator/=(const _quat<T> & q);
        _quat<T>  operator- () const;
    };

    template <typename T> _quat<T> operator* (const T s, const _quat<T> & q)
    {
        return q * s;
    }
}

#endif //__quat_h__
