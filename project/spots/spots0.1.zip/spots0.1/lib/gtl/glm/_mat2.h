//////////////////////////////////////////////////////////////////////////////////
// OpenGL Mathematics Copyright (c) 2005 G-Truc Creation (www.g-truc.net)
//////////////////////////////////////////////////////////////////////////////////
// Author  : Groove (groove[at]g-truc.net)
// Created : 2005-01-27
// Updated : 2005-02-27
// Licence : This source is under GNU LGPL licence
// File    : _mat2.h
//////////////////////////////////////////////////////////////////////////////////

#ifndef __mat2_h__
#define __mat2_h__

namespace glm
{
    template <typename T> class _xvec2;

    template <typename T> class _xmat2
    {
    private:
        // Data 
        _xvec2<T> value[2];

    public:
        int _size() const {return 2;}

    public:
        // Constructors
	    _xmat2();
        _xmat2(const T x);
        _xmat2(const T x1, const T y1, 
               const T x2, const T y2);
	    _xmat2(const _xvec2<T> & v1, 
               const _xvec2<T> & v2);

        // Accesses
        _xvec2<T>& operator[](int i) {return value[i];}
        const _xvec2<T> & operator[](int i) const {return value[i];}
        operator T*() {return &value[0][0];}
	    operator const T*() const {return &value[0][0];}

        // Operators
        _xmat2<T> & operator=(const _xmat2<T> & m);
	    _xmat2<T> operator+(const _xmat2<T> & m) const;
	    _xmat2<T> & operator+=(const _xmat2<T> & m);
	    _xmat2<T> operator-(const _xmat2<T> & m) const;
	    _xmat2<T> & operator-=(const _xmat2<T> & m);
	    _xmat2<T> operator*(const T s) const;
	    _xmat2<T> & operator*=(const T s);
        _xvec2<T> operator*(const _xvec2<T> & v) const;
	    _xmat2<T> operator/ (const T s) const;
	    _xmat2<T> & operator/= (const T s);
	    _xmat2<T> operator* (const _xmat2<T> & m) const;
	    _xmat2<T> & operator*= (const _xmat2<T> & m);
        _xmat2<T> operator/ (const _xmat2<T> & m) const;
	    _xmat2<T> & operator/= (const _xmat2<T> & m);
	    _xmat2<T> operator- () const;
        _xmat2<T> operator++ ();
	    _xmat2<T> operator++ (int n) const;
	    _xmat2<T> operator-- ();
	    _xmat2<T> operator-- (int n) const;
    };

    template <typename T> _xmat2<T> operator* (const T s, const _xmat2<T> & m)
    {
        return m * s;
    }

    template <typename T> _xvec2<T> operator* (const _xvec2<T> & v, const _xmat2<T> & m)
    {
        _xmat2<T> Transpose;
        Transpose[0][0] = m[0][0];
        Transpose[1][0] = m[0][1];
        Transpose[1][1] = m[1][1];
        Transpose[0][1] = m[1][0];
        return Transpose * v;
    }

} //namespace glm

#endif //__mat2_h__
