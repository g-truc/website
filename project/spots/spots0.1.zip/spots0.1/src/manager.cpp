//////////////////////////////////////////////////////////////////////////////
// Spots Battle, Copyright (c) 2005 G-Truc Creation (www.g-truc.net)
// Under GPL licence 
//////////////////////////////////////////////////////////////////////////////
// Groove (groove@g-truc.net)
// 2005-05-02
//////////////////////////////////////////////////////////////////////////////

#include "manager.h"
#include "rand.h"

CManager::CManager()
{

}

CManager::~CManager()
{
    std::list<CUnit*>::iterator it, end = m_Units.end();
    for(it = m_Units.begin(); it != end; it++)
        delete (*it);
}

void CManager::Update()
{
    std::list<CUnit*>::const_iterator it, end = m_Units.end();
    for(it = m_Units.begin(); it != end; it++)
        (*it)->Update();
}

void CManager::Render() const
{
    std::list<CUnit*>::const_iterator it, end = m_Units.end();

    glBegin(GL_POINTS);
        for(it = m_Units.begin(); it != end; it++)
        {
            glColor3fv((*it)->Color());
            glVertex2fv((*it)->Position());
        }
    glEnd();
}

const CUnit* CManager::Create(EUnit Unit, ETeam Team)
{
    CUnit* pUnit = new CUnit;
    m_Units.push_back(pUnit);

    pUnit->m_Team = Team;
    //pUnit->Position() = glm::vec2(RandFloat(10, 630), RandFloat(10, 470));

    switch(Team)
    {
    default:
        pUnit->Color() = glm::vec3(1.0f, 0.0f, 1.0f);
        break;
    case TEAM_CLASS1:
        pUnit->Color() = glm::vec3(0.0f, 0.0f, 1.0f);
        pUnit->Position() = glm::vec2(RandFloat(10, 320), RandFloat(10, 240));
        break;
    case TEAM_CLASS2:
        pUnit->Color() = glm::vec3(1.0f, 1.0f, 0.0f);
        pUnit->Position() = glm::vec2(RandFloat(320, 630), RandFloat(240, 470));
        break;
    case TEAM_CLASS3:
        pUnit->Color() = glm::vec3(1.0f, 0.0f, 0.0f);
        pUnit->Position() = glm::vec2(RandFloat(320, 630), RandFloat(10, 240));
        break;
    case TEAM_CLASS4:
        pUnit->Color() = glm::vec3(0.0f, 1.0f, 0.0f);
        pUnit->Position() = glm::vec2(RandFloat(10, 320), RandFloat(240, 470));
        break;
    }

    switch(Unit)
    {
    default:
    case UNIT_CLASS1:
        pUnit->Health() = 250;
        pUnit->HealthMax() = 250;
        pUnit->Speed() = 0.2f;
        pUnit->WeaponPower() = 10;
        pUnit->WeaponRange() = 15;
        break;
    case UNIT_CLASS2:
        pUnit->Health() = 250;
        pUnit->HealthMax() = 250;
        pUnit->Speed() = 1.0f;
        pUnit->WeaponPower() = 10;
        pUnit->WeaponRange() = 10;
        break;
    case UNIT_CLASS3:
        pUnit->Health() = 250;
        pUnit->HealthMax() = 250;
        pUnit->Speed() = 0.2f;
        pUnit->WeaponPower() = 100;
        pUnit->WeaponRange() = 10;
        break;
    case UNIT_CLASS4:
        pUnit->Health() = 2500;
        pUnit->HealthMax() = 2500;
        pUnit->Speed() = 0.2f;
        pUnit->WeaponPower() = 10;
        pUnit->WeaponRange() = 10;
        break;
    }

    return pUnit;
}

CUnit* CManager::Targeting(CUnit* pUnit)
{
    CUnit* pTarget = 0;
    float fDistanceMin;
    std::list<CUnit*>::const_iterator it, end = m_Units.end();

    for(it = m_Units.begin(); it != end; it++)
    {
        // 2005-05-02 - Skipping the wrong case
        if((*it)->m_Health <= 0)
            continue;
        if((*it)->m_Team == pUnit->m_Team)
            continue;

        float fDistance = glm::distance((*it)->m_Position, pUnit->m_Position);
        if(!pTarget)
        {
            pTarget = *it;
            fDistanceMin = fDistance;
            continue;
        }

        if(fDistance < fDistanceMin)
        {
            pTarget = *it;
            fDistanceMin = fDistance;
            continue;
        }
    }

    return pTarget;
}

