//////////////////////////////////////////////////////////////////////////////
// Spots Battle, Copyright (c) 2005 G-Truc Creation (www.g-truc.net)
// Under GPL licence 
//////////////////////////////////////////////////////////////////////////////
// Groove (groove@g-truc.net)
// 2005-05-02
//////////////////////////////////////////////////////////////////////////////

#ifndef RAND_H
#define RAND_H

#include <cstdlib>

class CRandomFloat
{
public:
	float operator()()
	{
		return 2 * (rand() - RAND_MAX / 2 ) / (float(RAND_MAX));
	}

    float operator()(float fMin, float fMax)
    {
        return (rand () / (float(RAND_MAX)) * (fMax - fMin)) + fMin;
    }
};

class CRandomInt
{
public:
	int operator()(int iMin, int iMax)
	{
		return long((float(rand()) / float(RAND_MAX) * (iMax - iMin)) + iMin);
	}
};

static CRandomFloat RandFloat;
static CRandomInt RandInt;

#endif //RAND_H
