//////////////////////////////////////////////////////////////////////////////
// Spots Battle, Copyright (c) 2005 G-Truc Creation (www.g-truc.net)
// Under GPL licence 
//////////////////////////////////////////////////////////////////////////////
// Groove (groove@g-truc.net)
// 2005-05-02
//////////////////////////////////////////////////////////////////////////////

#include "timer_global.h"
#include "window_sdl.h"

CTimerGlobal::CTimerGlobal()
{
    m_fDecal = 0;
}

CTimerGlobal::~CTimerGlobal()
{

}

void CTimerGlobal::Init()
{
	m_fStartTime = SDL_GetTicks () / 1000.f;
    m_fStartDecal = 0.0f;
    m_fDecal = 0.0f;
}

float CTimerGlobal::Time()
{
    if (!m_fStartDecal)
        m_fTimeCurrent = static_cast<float>(SDL_GetTicks () / 1000.f - m_fStartTime) - m_fDecal;
	return m_fTimeCurrent;
}

void CTimerGlobal::Stop()
{
    if(!m_fStartDecal)
    {
        m_fStartDecal = static_cast<float>(SDL_GetTicks () / 1000.f);
    }
}

void CTimerGlobal::Play()
{
    if(m_fStartDecal)
    {
        m_fDecal += static_cast<float>(SDL_GetTicks () / 1000.f) - m_fStartDecal;
        m_fStartDecal = 0.f;
    }
}
