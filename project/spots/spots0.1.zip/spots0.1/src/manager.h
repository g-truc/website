//////////////////////////////////////////////////////////////////////////////
// Spots Battle, Copyright (c) 2005 G-Truc Creation (www.g-truc.net)
// Under GPL licence 
//////////////////////////////////////////////////////////////////////////////
// Groove (groove@g-truc.net)
// 2005-05-02
//////////////////////////////////////////////////////////////////////////////

#ifndef __MANAGER_H__
#define __MANAGER_H__

#include "singleton.h"
#include "unit.h"
#include <list>

class CManager : public CSingleton<CManager>
{
    friend class CSingleton<CManager>;

public:
    const CUnit* Create(EUnit Unit, ETeam Team);
    void Update();
    void Render() const;

    CUnit* Targeting(CUnit* pUnit);

private:
    CManager();
    ~CManager();
    
    std::list<CUnit*> m_Units;
};

#endif //__MANAGER_H__
