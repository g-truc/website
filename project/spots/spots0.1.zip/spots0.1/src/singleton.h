//////////////////////////////////////////////////////////////////////////////
// Spots Battle, Copyright (c) 2005 G-Truc Creation (www.g-truc.net)
// Under GPL licence 
//////////////////////////////////////////////////////////////////////////////
// Groove (groove@g-truc.net)
// 2005-05-02
//////////////////////////////////////////////////////////////////////////////

#ifndef __SINGLETON_H__
#define __SINGLETON_H__

template <typename T> class CSingleton
{
private:
    static T* m_pInstance;

public:
    static T* Instance ()
    {
	    if (m_pInstance == 0)
		    m_pInstance = new T;
	    return m_pInstance;
    }

    static void Kill ()
    {
	    if (m_pInstance != 0)
	    {
		    delete m_pInstance;
		    m_pInstance = 0;
	    }
    }
};

template <typename T> T* CSingleton<T>::m_pInstance = 0;

#endif //__SINGLETON_H__
