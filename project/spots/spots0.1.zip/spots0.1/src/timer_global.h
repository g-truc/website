//////////////////////////////////////////////////////////////////////////////
// Spots Battle, Copyright (c) 2005 G-Truc Creation (www.g-truc.net)
// Under GPL licence 
//////////////////////////////////////////////////////////////////////////////
// Groove (groove@g-truc.net)
// 2005-05-02
//////////////////////////////////////////////////////////////////////////////

#ifndef __TIMER_GLOBAL_H__
#define __TIMER_GLOBAL_H__

#include "singleton.h"

class CTimerGlobal : public CSingleton<CTimerGlobal>
{
    friend class CSingleton<CTimerGlobal>;

private:
    float m_fStartTime;
    float m_fDecal;
    float m_fStartDecal;
    float m_fTimeCurrent;

	CTimerGlobal();
    ~CTimerGlobal();
    
public:
	void Stop();
    void Play();
	void Init();
	float Time();
};

#endif //__TIMER_GLOBAL_H__
