//////////////////////////////////////////////////////////////////////////////
// Spots Battle, Copyright (c) 2005 G-Truc Creation (www.g-truc.net)
// Under GPL licence 
//////////////////////////////////////////////////////////////////////////////
// Groove (groove@g-truc.net)
// 2005-05-02
//////////////////////////////////////////////////////////////////////////////

#ifndef WINDOW_SDL_H
#define WINDOW_SDL_H

#include "util.h"
#include "singleton.h"
#include <sdl.h>

class CWindowSDL : public CSingleton<CWindowSDL>
{
    friend class CSingleton<CWindowSDL>;

private:
	SDL_Surface* m_pSurface;
	unsigned short m_unHeight;
	unsigned short m_unWidth;
    bool m_bCreate;

	void _Resize(unsigned short unWidth, unsigned short unHeight);

	CWindowSDL ();
	~CWindowSDL ();

public:
	void Swap();
	bool Create(const char* szName, unsigned short unWidth, unsigned short unHeight, unsigned char ucColor, bool bFullscreen);
    void SetCursorPosition(int x, int y);

	unsigned short Height() const;
	unsigned short Width() const;
};

#endif //WINDOW_SDL_H

