//////////////////////////////////////////////////////////////////////////////
// Spots Battle, Copyright (c) 2005 G-Truc Creation (www.g-truc.net)
// Under GPL licence 
//////////////////////////////////////////////////////////////////////////////
// Groove (groove@g-truc.net)
// 2005-05-02
//////////////////////////////////////////////////////////////////////////////

#ifndef __MAIN_H__
#define __MAIN_H__

#include "timer_local.h"

class CMain
{
public:
    CMain();
    ~CMain();

    void Begin();
    void Event();
    void Update();
    void Render();
    void End();

private:
    bool m_bExit;
    CTimerLocal m_Timer;
};

#endif //__MAIN_H__
