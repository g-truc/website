//////////////////////////////////////////////////////////////////////////////
// Spots Battle, Copyright (c) 2005 G-Truc Creation (www.g-truc.net)
// Under GPL licence 
//////////////////////////////////////////////////////////////////////////////
// Groove (groove@g-truc.net)
// 2005-05-02
//////////////////////////////////////////////////////////////////////////////

#include "main.h"
#include "window_sdl.h"
#include "manager.h"

CMain::CMain()
{
    CWindowSDL* pWindow = CWindowSDL::Instance();
    if(!pWindow->Create("Spots Battle", 640, 480, 32, false))
		return;

    Begin();

    while(!m_bExit)
    {
        Event();
        Update();
        Render();
        CWindowSDL::Instance()->Swap();
    }
    End();
}

CMain::~CMain()
{
    SDL_Quit();
}

void CMain::Begin()
{
	m_bExit = false;

    glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
    glPointSize(4.0f);

    CWindowSDL* pWindow = CWindowSDL::Instance();
    glViewport(0, 0, pWindow->Width(), pWindow->Height());
    glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0, pWindow->Width(), 0, pWindow->Height(), -1, 1);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

    for(int i = 0; i < 128; i++)
        CManager::Instance()->Create(UNIT_CLASS1, TEAM_CLASS1);

    for(int i = 0; i < 128; i++)
        CManager::Instance()->Create(UNIT_CLASS2, TEAM_CLASS2);

    for(int i = 0; i < 128; i++)
        CManager::Instance()->Create(UNIT_CLASS3, TEAM_CLASS3);

    for(int i = 0; i < 128; i++)
        CManager::Instance()->Create(UNIT_CLASS4, TEAM_CLASS4);

    m_Timer.Init();
}

void CMain::Event()
{
    SDL_Event Event;
    while(SDL_PollEvent(&Event))
    {
	    switch(Event.type)
	    {
	    case SDL_QUIT:
		    m_bExit = true;
            break;
        case SDL_KEYDOWN:
            switch(Event.key.keysym.sym)
            {
            case 27:
                m_bExit = true;
                break;
            default:
                break;
            }
		    break;
	    default:
		    break;
	    }
    }
}

void CMain::Update()
{
    if(m_Timer.Time() > 0.01f)
    {
        m_Timer.Init();
        CManager::Instance()->Update();
    }
}

void CMain::Render()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glLoadIdentity();

    CManager::Instance()->Render();
}

void CMain::End()
{

}

int main(int argc, char* argv[])
{
    CMain();

	return 0;
}
