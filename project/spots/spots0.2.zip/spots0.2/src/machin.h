#ifndef __FSM_H__
#define __FSM_H__

#include "smart_ptr.h"
#include "rules.h"
#include <map>

class CMachin
{
public:
    CMachin();
	CMachin(const CSmartPtr<CRules> & Rules);
	~CMachin();

    TState operator()(TEvent Event);
	TState GetState() const;
	bool SetState(TState State);
    TEvent EventPoll() const;

private:
    CState* m_pState;
	CSmartPtr<CRules> m_Rules;
};

#endif //__FSM_H__
