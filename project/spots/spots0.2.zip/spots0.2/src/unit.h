//////////////////////////////////////////////////////////////////////////////
// Spots Battle, Copyright (c) 2005 G-Truc Creation (www.g-truc.net)
// Under GPL licence 
//////////////////////////////////////////////////////////////////////////////
// Groove (groove@g-truc.net)
// 2005-05-02
//////////////////////////////////////////////////////////////////////////////

#ifndef __UNIT_H__
#define __UNIT_H__

#include "util.h"
#include "machin.h"
#include "agent.h"

typedef enum
{
    UNIT_CLASS1,
    UNIT_CLASS2,
    UNIT_CLASS3,
    UNIT_CLASS4
} EUnit;

typedef enum
{
    TEAM_CLASS1,
    TEAM_CLASS2,
    TEAM_CLASS3,
    TEAM_CLASS4
} ETeam;

typedef enum
{
    EVENT_SELF_DIE              = 0x0001,
    EVENT_SELF_FIRED            = 0x0002,
    EVENT_SELF_LOW_HEALTH       = 0x0004,
    EVENT_SELF_FULL_HEALTH      = 0x0008,
    EVENT_SELF_IN_SECURITY      = 0x0010,
    EVENT_TARGET_DIE            = 0x0020,
    EVENT_TARGET_OUT_OF_RANGE   = 0x0040,
    EVENT_TARGET_BINDED         = 0x0080,
    EVENT_TARGET_SELECTED       = 0x0100,
    EVENT_TARGET_NONE           = 0x0200,
    EVENT_HELP                  = 0x0400
} EEvent;

typedef enum
{
    STATE_NULL,
    STATE_IDLE,
    STATE_MOVE,
    STATE_ATTACK,
    STATE_DEATH,
    STATE_VICTORY,
    STATE_RIPOSTE,
    STATE_REGENERATION,
    STATE_ESCAPE
} EState;

class CUnit : public CAgent
{
    friend class CManager;

public:
    ETeam& Team(){return m_Team;}
    ETeam Team() const{return m_Team;}
    glm::vec2& Position(){return m_Position;}
    glm::vec2 Position() const{return m_Position;}
    glm::vec3& Color(){return m_Color;}
    glm::vec3 Color() const{return m_Color;}
    float& Speed(){return m_Speed;}
    float Speed() const{return m_Speed;}
    int& Health(){return m_Health;}
    int Health() const{return m_Health;}
    int& HealthMax(){return m_HealthMax;}
    int HealthMax() const{return m_HealthMax;}
    int& WeaponPower(){return m_WeaponPower;}
    int WeaponPower() const{return m_WeaponPower;}
    int& WeaponRange(){return m_WeaponRange;}
    int WeaponRange() const{return m_WeaponRange;}

    void Update();

private:
    CUnit(TAgent Agent, CSmartPtr<CRules> pRules);
    ~CUnit();

    void _ActionMove();
    void _ActionFire();
    void _ActionDie();
    void _ActionTargeting();
    void _ActionIdle();
    void _ActionRiposte();
    void _ActionRegeneration();
    void _ActionEscape();

    bool _EventSelfDie() const;
    bool _EventEnnemyDie() const;
    bool _EventTargetOutOfRange() const;
    bool _EventNoTarget() const;
    bool _EvenOnFire() const;
    bool _EvenLowHealth() const;
    bool _EvenFullHealth() const;
    bool _EventInSecurity() const;

    CUnit* m_pTarget;
    CUnit* m_pEnnemy;

    ETeam m_Team;
    glm::vec2 m_Position;
    glm::vec3 m_Color;
    float m_Speed;
    int m_Health;
    int m_HealthMax;
    int m_WeaponPower;
    int m_WeaponRange;
};

#endif //__UNIT_H__
