#ifndef __AI_MESSAGE_H__
#define __AI_MESSAGE_H__

#include "state.h"
#include "smart_ptr.h"
#include "timer_local.h"
#include <list>

typedef int TGroup;
typedef int TAgent;
typedef int TOrder;

class CMessage
{
    friend class CSmartPtr<CMessage>;

public:
    static CSmartPtr<CMessage> Create(TAgent Emitter, TEvent Event, float Delay = 0.0f);
    TAgent Emitter() const;
    void AddReceiver(TAgent Agent);
    std::list<TAgent> Receivers() const;
    std::list<TAgent>& Receivers();
    TEvent Event() const;
    bool Delay();

private:
    CMessage();
    ~CMessage();

    TAgent m_Emitter;
    std::list<TAgent> m_Receivers;
    TEvent m_Event;
    float m_Delay;
    CTimerLocal m_Timer;
};

#endif //__AI_MESSAGE_H__
