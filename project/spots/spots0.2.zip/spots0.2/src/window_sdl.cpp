//////////////////////////////////////////////////////////////////////////////
// Spots Battle, Copyright (c) 2005 G-Truc Creation (www.g-truc.net)
// Under GPL licence 
//////////////////////////////////////////////////////////////////////////////
// Groove (groove@g-truc.net)
// 2005-05-02
//////////////////////////////////////////////////////////////////////////////

#include "window_sdl.h"

CWindowSDL::CWindowSDL ()
{
    //SDL_ShowCursor (SDL_DISABLE);
	m_pSurface = 0;
    m_bCreate = false;
}

CWindowSDL::~CWindowSDL ()
{
    //SDL_ShowCursor(SDL_ENABLE);
	if(m_pSurface)
		SDL_FreeSurface(m_pSurface);
}

unsigned short CWindowSDL::Height () const
{
	return m_unHeight;
}

unsigned short CWindowSDL::Width () const
{
	return m_unWidth;
}

void CWindowSDL::Swap()
{
	SDL_GL_SwapBuffers();
}

void CWindowSDL::SetCursorPosition(int x, int y)
{
    SDL_WarpMouse(x, y);
}

bool CWindowSDL::Create(const char* szName, unsigned short unWidth, unsigned short unHeight, unsigned char ucColor, bool bFullscreen)
{
    if(m_bCreate)
        SDL_FreeSurface(m_pSurface);

	m_unHeight = unHeight;
	m_unWidth = unWidth;

    if(SDL_Init (SDL_INIT_VIDEO) < 0)
        return false;

	unsigned int uiVideoFlags = SDL_OPENGL;
	if (bFullscreen)
		uiVideoFlags |= SDL_FULLSCREEN;

    SDL_GL_SetAttribute (SDL_GL_DOUBLEBUFFER, 1);
    SDL_GL_SetAttribute (SDL_GL_DEPTH_SIZE, 16);
    SDL_GL_SetAttribute (SDL_GL_STENCIL_SIZE, 0);
    SDL_GL_SetAttribute (SDL_GL_ACCUM_RED_SIZE, 0);
    SDL_GL_SetAttribute (SDL_GL_ACCUM_GREEN_SIZE, 0);
    SDL_GL_SetAttribute (SDL_GL_ACCUM_BLUE_SIZE, 0);
    SDL_GL_SetAttribute (SDL_GL_ACCUM_ALPHA_SIZE, 0);

	if((m_pSurface = SDL_SetVideoMode (unWidth, unHeight, ucColor, uiVideoFlags)) == 0)
		return false;

    SDL_WM_SetCaption (szName, szName);
	_Resize (unWidth, unHeight);
    //SDL_ShowCursor (SDL_DISABLE);

	return(m_bCreate = true);
}

void CWindowSDL::_Resize(unsigned short unWidth, unsigned short unHeight)
{
	if(unHeight == 0)
		unHeight = 1;

    glViewport(0, 0, unWidth, unHeight);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.f, float(unWidth) / float(unHeight), 0.1f, 512);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

