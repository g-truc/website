#include "machin.h"
#include "rules.h"

CMachin::CMachin()
{
    m_pState = 0;
}

CMachin::CMachin(const CSmartPtr<CRules> & Rules)
{
    m_pState = 0;
    m_Rules = Rules;
}

CMachin::~CMachin()
{

}

TState CMachin::operator()(TEvent Event)
{
    if(m_pState == 0)
        return -1;
    TState NewState = m_pState->Event(Event);
    if(NewState != m_pState->Index())
    {
        m_pState = m_Rules->FindState(NewState);
        if(!m_pState)
            return -1;
    }
    return NewState;
}

TEvent CMachin::EventPoll() const
{
    return m_pState->EventPoll();
}

TState CMachin::GetState() const
{
    if(!m_pState)
        return -1;
    return m_pState->Index();
}

bool CMachin::SetState(TState State)
{
    m_pState = m_Rules->FindState(State);
    return m_pState != 0;
}
