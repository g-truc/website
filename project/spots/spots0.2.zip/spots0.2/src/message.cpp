#include "message.h"

CMessage::CMessage()
{

}

CMessage::~CMessage()
{

}

CSmartPtr<CMessage> CMessage::Create(TAgent Emitter, TEvent Event, float Delay)
{
    CSmartPtr<CMessage> pMessage = new CMessage;
    pMessage->m_Emitter = Emitter;
    pMessage->m_Event = Event;
    pMessage->m_Delay = Delay;
    pMessage->m_Timer.Init();
    return pMessage;
}

void CMessage::AddReceiver(TAgent Agent)
{
    m_Receivers.push_back(Agent);
}

TAgent CMessage::Emitter() const
{
    return m_Emitter;
}

std::list<TAgent> CMessage::Receivers() const
{
    return m_Receivers;
}

std::list<TAgent>& CMessage::Receivers()
{
    return m_Receivers;
}

TEvent CMessage::Event() const
{
    return m_Event;
}

bool CMessage::Delay()
{
    return (m_Timer.Time() < m_Delay); 
}
