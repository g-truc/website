#ifndef __GTL_UTIL_TIMER__
#define __GTL_UTIL_TIMER__

#include <cstdlib>
#ifndef _WIN32
#include <sys/time.h>
#else
#include <windows.h>
#endif

class CTimer
{
public:
	CTimer(float StartTime = 0);

	/// Returns the elapsed time, expressed in seconds, since the last call of getElapsedTime().
	float getElapsedTime();

	/**
	Returns the elapsed time since the creation of the clock.
	CAUTION : each call of getTime() MUST BE preceeded by a call of getElapsedTime().
	*/
	float getTime() const;

private:
	float m_StartTime, m_CurrentTime;
#ifndef _WIN32
	timeval m_AbsoluteTime, m_NewTime;
#else
	LARGE_INTEGER m_AbsoluteTime, m_NewTime, m_TicksPerSecond;
#endif
};

#endif //__GTL_UTIL_TIMER__
