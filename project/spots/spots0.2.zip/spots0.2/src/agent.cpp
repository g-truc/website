#include "agent.h"
#include "message.h"
#include "router.h"
#include "rules.h"

CAgent::CAgent(TAgent Agent, CSmartPtr<CRules> pRules) :
    m_Agent(Agent),
    m_Machin(pRules)
{
    CRouter::Instance()->Register(this);
}

CAgent::~CAgent()
{
    CRouter::Instance()->Release(this);
}

bool CAgent::operator< (const CAgent & Agent) const
{
    return this < &Agent;
}

void CAgent::Recv(CSmartPtr<CMessage> pMessage)
{
    m_Machin(pMessage->Event());
}
