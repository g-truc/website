//////////////////////////////////////////////////////////////////////////////
// Spots Battle, Copyright (c) 2005 G-Truc Creation (www.g-truc.net)
// Under GPL licence 
//////////////////////////////////////////////////////////////////////////////
// Groove (groove@g-truc.net)
// 2005-05-02
//////////////////////////////////////////////////////////////////////////////

#include "unit.h"
#include "manager.h"
#include "router.h"

CUnit::CUnit(TAgent Agent, CSmartPtr<CRules> pRules) :
    CAgent(Agent, pRules)
{
    m_pEnnemy = 0;
    m_pTarget = 0;

    m_Machin.SetState(STATE_IDLE);
}

CUnit::~CUnit()
{


}

void CUnit::Update()
{
    switch(m_Machin.GetState())
    {
    default:
        break;
    case STATE_IDLE:
        if(_EventSelfDie())
        {
            _ActionDie();
            m_Machin(EVENT_SELF_DIE);
            return;
        }
        if(_EvenOnFire())
        {
            m_Machin(EVENT_SELF_FIRED);
            return;
        }
        _ActionTargeting();
        if(_EventNoTarget())
            m_Machin(EVENT_TARGET_NONE);
        else
            m_Machin(EVENT_TARGET_SELECTED);
        break;

    case STATE_MOVE:
        if(_EventSelfDie())
        {
            _ActionDie();
            m_Machin(EVENT_SELF_DIE);
            return;
        }
        if(_EvenOnFire())
        {
            m_Machin(EVENT_SELF_FIRED);
            return;
        }
        if(_EventEnnemyDie())
        {
            m_Machin(EVENT_TARGET_DIE);
            return;
        }
        if(!_EventTargetOutOfRange())
        {
            m_Machin(EVENT_TARGET_BINDED);
            return;
        }
        _ActionMove();
        break;

    case STATE_ATTACK:
        if(_EventSelfDie())
        {
            _ActionDie();
            m_Machin(EVENT_SELF_DIE);
            return;
        }
        if(_EvenLowHealth())
        {
            m_Machin(EVENT_SELF_LOW_HEALTH);
            return;
        }
        if(_EventEnnemyDie())
        {
            m_Machin(EVENT_TARGET_DIE);
            return;
        }
        if(_EvenOnFire())
        {
            m_Machin(EVENT_SELF_FIRED);
            return;
        }
        if(_EventTargetOutOfRange())
        {
            m_Machin(EVENT_TARGET_OUT_OF_RANGE);
            return;
        }

        _ActionFire();
        break;

    case STATE_ESCAPE:
        if(_EventSelfDie())
        {
            _ActionDie();
            m_Machin(EVENT_SELF_DIE);
            return;
        }
        if(_EvenOnFire())
        {
            m_Machin(EVENT_SELF_FIRED);
            return;
        }
        if(_EventEnnemyDie())
        {
            m_Machin(EVENT_TARGET_DIE);
            return;
        }
        if(_EventInSecurity())
        {
            m_Machin(EVENT_SELF_IN_SECURITY);
            return;
        }

        {
            CSmartPtr<CMessage> pMessage = CMessage::Create(m_Agent, EVENT_HELP);
            pMessage->Receivers() = CManager::Instance()->RangeUnits(this, 128);
            CRouter::Instance()->Recv(pMessage);
        }
        _ActionEscape();
        break;

    case STATE_REGENERATION:
        if(_EventSelfDie())
        {
            _ActionDie();
            m_Machin(EVENT_SELF_DIE);
            return;
        }
        if(_EvenOnFire())
        {
            m_Machin(EVENT_SELF_FIRED);
            return;
        }
        if(_EvenFullHealth())
        {
            m_Machin(EVENT_SELF_FULL_HEALTH);
            return;
        }

        _ActionRegeneration();
        break;

    case STATE_RIPOSTE:
        if(_EventSelfDie())
        {
            _ActionDie();
            m_Machin(EVENT_SELF_DIE);
            return;
        }
        if(_EvenLowHealth())
        {
            m_Machin(EVENT_SELF_LOW_HEALTH);
            return;
        }

        _ActionRiposte();
        m_Machin.SetState(STATE_MOVE);
        break;

    case STATE_DEATH:
        break;

    case STATE_VICTORY:
        break;
    }
}

bool CUnit::_EventSelfDie() const
{
    return m_Health <= 0;
}

bool CUnit::_EventEnnemyDie() const
{
    return m_pTarget->m_Health <= 0;
}

bool CUnit::_EventTargetOutOfRange() const
{
    return glm::distance(m_Position, m_pTarget->m_Position) > m_WeaponRange;
}

bool CUnit::_EventNoTarget() const
{
    return !m_pTarget;
}

bool CUnit::_EvenOnFire() const
{
    return m_pEnnemy != 0 && m_pEnnemy != m_pTarget;
}

bool CUnit::_EvenLowHealth() const
{
    return m_Health < m_HealthMax / 2;
}

bool CUnit::_EvenFullHealth() const
{
    return m_Health == m_HealthMax;
}

bool CUnit::_EventInSecurity() const
{
    return glm::distance(m_Position, m_pTarget->m_Position) > m_pTarget->m_WeaponRange * 10;
}

void CUnit::_ActionMove()
{
    glm::vec2 Direction = glm::normalize(m_pTarget->m_Position - m_Position);
    m_Position += Direction * m_Speed;
}  

void CUnit::_ActionFire()
{
    m_pTarget->m_Health -= m_WeaponPower;
    m_pTarget->m_pEnnemy = this;
}   

void CUnit::_ActionDie()
{
    m_Color *= 0.33f;
}

void CUnit::_ActionTargeting()
{
    CManager* pManager = CManager::Instance();
    m_pTarget = pManager->Targeting(this);
}

void CUnit::_ActionRiposte()
{
    m_pTarget = m_pEnnemy;
    m_pEnnemy = 0;
}

void CUnit::_ActionRegeneration()
{
    m_Health += m_HealthMax / 100;
    if(m_Health > m_HealthMax)
        m_Health = m_HealthMax;
}

void CUnit::_ActionEscape()
{
    glm::vec2 Direction = -glm::normalize(m_pTarget->m_Position - m_Position);
    m_Position += Direction * m_Speed * 2.0f;

    if(m_Position.x > 630)
        m_Position.x = 630;
    if(m_Position.x < 10)
        m_Position.x = 10;
    if(m_Position.y > 470)
        m_Position.y = 470;
    if(m_Position.y < 10)
        m_Position.y = 10;
}
