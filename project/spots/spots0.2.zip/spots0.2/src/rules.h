#ifndef __RULES_H__
#define __RULES_H__

#include "state.h"

class CRules
{
    typedef std::map<TState, CState*> TStates;

public:
	CRules();
	~CRules();

	CState* Create(TState State);
	bool Delete(TState State);
    CState* FindState(TState State);

private:
	TStates m_States;
};

#endif //__RULES_H__
