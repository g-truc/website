#include "rules.h"

CRules::CRules()
{}

CRules::~CRules()
{
    for
    (
        TStates::iterator it = m_States.begin();
        it != m_States.end();
        it++
    )
    {
        delete it->second;
    }
}

CState* CRules::Create(TState State)
{
    if(m_States.find(State) != m_States.end())
        return 0;
    CState* pState = new CState(State);
    m_States.insert(std::make_pair(State, pState));
    return pState;
}

bool CRules::Delete(TState State)
{
    TStates::iterator it = m_States.find(State);
    if(it == m_States.end())
        return false;
    m_States.erase(it);
    return true;
}

CState* CRules::FindState(TState State)
{
    TStates::iterator it = m_States.find(State);
    if(it == m_States.end())
        return 0;
    return it->second;
}
