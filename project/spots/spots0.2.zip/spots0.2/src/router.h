#ifndef __AI_ROUTER_H__
#define __AI_ROUTER_H__

#include "agent.h"
#include "message.h"
#include "singleton.h"
#include <set>
#include <list>

class CRouter : public CSingleton<CRouter>
{
    friend class CSingleton<CRouter>;
    friend class CAgent;

    typedef std::set<CAgent*> TAgentsSet;
    typedef std::list<CSmartPtr<CMessage> > TMessagesList;

public:
    void Recv(CSmartPtr<CMessage> pMessage);
    void Send();
    bool Register(CAgent* pAgent);
    bool Release(CAgent* pAgent);

public:
    CRouter();
    ~CRouter();

private:
    std::set<CAgent*> m_Agents;
    std::list<CSmartPtr<CMessage> > m_Messages;
};

#endif //__AI_ROUTER_H__
