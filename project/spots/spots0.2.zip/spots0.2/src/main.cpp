//////////////////////////////////////////////////////////////////////////////
// Spots Battle, Copyright (c) 2005 G-Truc Creation (www.g-truc.net)
// Under GPL licence 
//////////////////////////////////////////////////////////////////////////////
// Groove (groove@g-truc.net)
// 2005-05-02
//////////////////////////////////////////////////////////////////////////////

#include "main.h"
#include "window_sdl.h"
#include "manager.h"
#include "smart_ptr.h"
#include "factory.h"

class B
{

};

class D1 : public B
{

};

class D2 : public B
{

};

CMain::CMain()
{
    printf("%s : %d\n", "STATE_IDLE", STATE_IDLE);
    printf("%s : %d\n", "STATE_MOVE", STATE_MOVE);
    printf("%s : %d\n", "STATE_ATTACK", STATE_ATTACK);
    printf("%s : %d\n", "STATE_RIPOSTE", STATE_RIPOSTE);
    printf("%s : %d\n", "STATE_ESCAPE", STATE_ESCAPE);
    printf("%s : %d\n", "STATE_REGENERATION", STATE_REGENERATION);
    printf("%s : %d\n", "STATE_DEATH", STATE_DEATH);
    printf("%s : %d\n", "STATE_VICTORY", STATE_VICTORY);

    CWindowSDL* pWindow = CWindowSDL::Instance();
    if(!pWindow->Create("Spots Battle", 640, 480, 32, false))
		return;

    Begin();

    while(!m_bExit)
    {
        Event();
        Update();
        Render();
        CWindowSDL::Instance()->Swap();
    }
    End();
}

CMain::~CMain()
{
    SDL_Quit();
}

void CMain::Begin()
{
	m_bExit = false;

    glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
    glPointSize(4.0f);

    CWindowSDL* pWindow = CWindowSDL::Instance();
    glViewport(0, 0, pWindow->Width(), pWindow->Height());
    glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0, pWindow->Width(), 0, pWindow->Height(), -1, 1);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

    CSmartPtr<CRules> pRules = new CRules;
    CState* pStateIdle = pRules->Create(STATE_IDLE);
    CState* pStateMove = pRules->Create(STATE_MOVE);
    CState* pStateAttack = pRules->Create(STATE_ATTACK);
    CState* pStateRiposte = pRules->Create(STATE_RIPOSTE);
    CState* pStateEscape = pRules->Create(STATE_ESCAPE);
    CState* pStateRegeneration = pRules->Create(STATE_REGENERATION);
    CState* pStateDeath = pRules->Create(STATE_DEATH);
    CState* pStateVictory = pRules->Create(STATE_VICTORY);

    // Idle
    pStateIdle->AddTransition(EVENT_SELF_DIE, STATE_DEATH);
    pStateIdle->AddTransition(EVENT_TARGET_SELECTED, STATE_MOVE);
    pStateIdle->AddTransition(EVENT_TARGET_NONE, STATE_VICTORY);
    pStateIdle->AddTransition(EVENT_HELP, STATE_IDLE);

    // Move
    pStateMove->AddTransition(EVENT_SELF_DIE, STATE_DEATH);
    pStateMove->AddTransition(EVENT_SELF_FIRED, STATE_RIPOSTE);
    pStateMove->AddTransition(EVENT_SELF_LOW_HEALTH, STATE_ESCAPE);
    pStateMove->AddTransition(EVENT_TARGET_BINDED, STATE_ATTACK);
    pStateMove->AddTransition(EVENT_TARGET_DIE, STATE_IDLE);
    pStateMove->AddTransition(EVENT_HELP, STATE_IDLE);

    // Attack
    pStateAttack->AddTransition(EVENT_SELF_DIE, STATE_DEATH);
    pStateAttack->AddTransition(EVENT_SELF_LOW_HEALTH, STATE_ESCAPE);
    pStateAttack->AddTransition(EVENT_TARGET_OUT_OF_RANGE, STATE_MOVE);
    pStateAttack->AddTransition(EVENT_TARGET_DIE, STATE_IDLE);
    pStateAttack->AddTransition(EVENT_HELP, STATE_IDLE);

    // Riposte
    pStateRiposte->AddTransition(EVENT_SELF_DIE, STATE_DEATH);
    pStateRiposte->AddTransition(EVENT_SELF_LOW_HEALTH, STATE_ESCAPE);
    pStateRiposte->AddTransition(EVENT_TARGET_SELECTED, STATE_MOVE);

    // Escape
    pStateEscape->AddTransition(EVENT_SELF_DIE, STATE_DEATH);
    pStateEscape->AddTransition(EVENT_SELF_FIRED, STATE_RIPOSTE);
    pStateEscape->AddTransition(EVENT_TARGET_DIE, STATE_REGENERATION);
    pStateEscape->AddTransition(EVENT_SELF_IN_SECURITY, STATE_REGENERATION);

    // Regeneration
    pStateRegeneration->AddTransition(EVENT_SELF_DIE, STATE_DEATH);
    pStateRegeneration->AddTransition(EVENT_SELF_FIRED, STATE_RIPOSTE);
    pStateRegeneration->AddTransition(EVENT_SELF_FULL_HEALTH, STATE_IDLE);

    for(int i = 0; i < 128; i++)
        CManager::Instance()->Create(pRules, UNIT_CLASS1, TEAM_CLASS1);
    for(int i = 0; i < 128; i++)
        CManager::Instance()->Create(pRules, UNIT_CLASS2, TEAM_CLASS2);
    for(int i = 0; i < 128; i++)
        CManager::Instance()->Create(pRules, UNIT_CLASS3, TEAM_CLASS3);
    for(int i = 0; i < 128; i++)
        CManager::Instance()->Create(pRules, UNIT_CLASS4, TEAM_CLASS4);

    m_Timer.Init();
}

void CMain::Event()
{
    SDL_Event Event;
    while(SDL_PollEvent(&Event))
    {
	    switch(Event.type)
	    {
	    case SDL_QUIT:
		    m_bExit = true;
            break;
        case SDL_KEYDOWN:
            switch(Event.key.keysym.sym)
            {
            case 27:
                m_bExit = true;
                break;
            default:
                break;
            }
		    break;
	    default:
		    break;
	    }
    }
}

void CMain::Update()
{
    if(m_Timer.Time() > 0.01f)
    {
        m_Timer.Init();
        CManager::Instance()->Update();
    }
}

void CMain::Render()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glLoadIdentity();

    CManager::Instance()->Render();
}

void CMain::End()
{

}

int main(int argc, char* argv[])
{
    CMain();

	return 0;
}
