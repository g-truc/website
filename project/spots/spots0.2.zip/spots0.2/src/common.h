#ifndef __COMMON_H__
#define __COMMON_H__

#define interface struct

#endif //__COMMON_H__
