//////////////////////////////////////////////////////////////////////////////
// Spots Battle, Copyright (c) 2005 G-Truc Creation (www.g-truc.net)
// Under GPL licence 
//////////////////////////////////////////////////////////////////////////////
// Groove (groove@g-truc.net)
// 2005-05-02
//////////////////////////////////////////////////////////////////////////////

#include "timer_local.h"
#include "window_sdl.h"

CTimerLocal::CTimerLocal()
{

}

void CTimerLocal::Init()
{
	m_fStartTime = SDL_GetTicks () / 1000.f;
}

float CTimerLocal::Time() const
{
	return static_cast<float>(SDL_GetTicks() / 1000.f - m_fStartTime);
}
