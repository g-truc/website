#ifndef __STATE_H__
#define __STATE_H__

#include <map>

typedef int TEvent;
typedef int TState;

class CState
{
    friend class CRules;

    typedef std::map<TEvent, TState> TTransistion;
    typedef std::map<TEvent, TState>::iterator TTransistionIT;
    typedef std::map<TEvent, TState>::const_iterator TTransistionCIT;

public:
    TState Index() const{return m_Index;}
	void AddTransition(TEvent Event, TState State);
	void DelTransition(TState State);
    TState Event(TEvent Event);
    TEvent EventPoll() const;

private:
	CState(TState Index);
	~CState();

	TState m_Index;
    TTransistion m_Transition;
};

#endif //__STATE_H__
