#include "./timer.h"

CTimer::CTimer(float StartTime) : 
    m_StartTime(StartTime), 
    m_CurrentTime(StartTime)
{
#ifndef _WIN32
	gettimeofday(&m_AbsoluteTime, NULL);
#else
	QueryPerformanceFrequency(&m_TicksPerSecond);
	QueryPerformanceCounter(&m_AbsoluteTime);
#endif
}

float CTimer::getElapsedTime()
{
	float ElapsedTime;

#ifndef _WIN32
	gettimeofday(&m_NewTime, NULL);
	ElapsedTime = (m_NewTime.tv_usec - m_AbsoluteTime.tv_usec )/1000000. + m_NewTime.tv_sec - m_AbsoluteTime.tv_sec;
	m_AbsoluteTime = m_NewTime;
#else
	QueryPerformanceCounter(&m_NewTime);
	ElapsedTime = (float(m_NewTime.QuadPart) - float(m_AbsoluteTime.QuadPart)) / float(m_TicksPerSecond.QuadPart);
	m_AbsoluteTime = m_NewTime;
#endif
	m_CurrentTime += ElapsedTime;
	return ElapsedTime;
}

float CTimer::getTime() const
{
	return m_CurrentTime;
}
