#include "state.h"
#include "machin.h"

CState::CState(TState Index) : 
    m_Index(Index)
{}

CState::~CState()
{

}

void CState::AddTransition(TEvent Event, TState State)
{
    m_Transition.insert(std::pair<TEvent, TState>(Event, State));
}

void CState::DelTransition(TState State)
{
    TTransistionIT it = m_Transition.begin();
    while(it != m_Transition.end())
    {
        if(it->second == State)
        {
            TTransistionIT it2 = it;
            it++;
            m_Transition.erase(it2);
        }
        else
        {
            it++;
        }
    }
}

TState CState::Event(TEvent Event)
{
    TTransistionIT it = m_Transition.find(Event);
    if(it != m_Transition.end())
        return it->second;
    return m_Index;
}

TEvent CState::EventPoll() const
{
    TEvent Events = 0;
    for
    (
        TTransistionCIT it = m_Transition.begin();
        it != m_Transition.end();
        it++
    )
    {
        Events |= it->first;
    }
    return Events;
}
