#ifndef __SMART_PTR_H__
#define __SMART_PTR_H__

template <typename T>
class CSmartPtr
{
public:
    CSmartPtr();
    CSmartPtr(const CSmartPtr & SmartPtr);
    CSmartPtr(T* pPointer);
    ~CSmartPtr();

    T& operator*();
    T* operator->();
    CSmartPtr& operator=(const CSmartPtr & SmartPtr);
    CSmartPtr& operator=(T* pPointer);
	bool operator==(const CSmartPtr & SmartPtr) const;
	bool operator!=(const CSmartPtr & SmartPtr) const;

private:
    int* m_pReference;
    T* m_pPointer;
};

template <typename T>
CSmartPtr<T>::CSmartPtr()
{
    m_pPointer = 0;
}

template <typename T>
CSmartPtr<T>::CSmartPtr(const CSmartPtr & SmartPtr)
{
    m_pReference = SmartPtr.m_pReference;
    m_pPointer = SmartPtr.m_pPointer;
    (*m_pReference)++;
}

template <typename T>
CSmartPtr<T>::CSmartPtr(T* pPointer)
{
    m_pReference = new int;
    m_pPointer = pPointer;
    (*m_pReference) = 1;
}

template <typename T>
CSmartPtr<T>::~CSmartPtr()
{
    if(!m_pPointer)
        return;

    (*m_pReference)--;
    if(*m_pReference <= 0)
    {
        delete m_pReference;
        delete m_pPointer;
    }
}

template <typename T>
CSmartPtr<T>& CSmartPtr<T>::operator=(const CSmartPtr<T> & SmartPtr)
{
    if(m_pPointer)
    {
        (*m_pReference)--;
        if(*m_pReference <= 0)
        {
            delete m_pReference;
            delete m_pPointer;
        }
    }

    m_pReference = SmartPtr.m_pReference;
    m_pPointer = SmartPtr.m_pPointer;
    (*m_pReference)++;

    return *this;
}

template <typename T>
CSmartPtr<T>& CSmartPtr<T>::operator=(T* pPointer)
{
    if(m_pPointer)
    {
        (*m_pReference)--;
        if(*m_pReference <= 0)
        {
            delete m_pReference;
            delete m_pPointer;
        }
    }

    m_pReference = new int;
    m_pPointer = pPointer;
    (*m_pReference) = 1;

    return *this;
}

template <typename T>
bool CSmartPtr<T>::operator==(const CSmartPtr<T> & SmartPtr) const
{
	return m_pPointer == SmartPtr.m_pPointer;
}

template <typename T>
bool CSmartPtr<T>::operator!=(const CSmartPtr<T> & SmartPtr) const
{
	return m_pPointer != SmartPtr.m_pPointer;
}

template <typename T>
T& CSmartPtr<T>::operator*()
{
    return *m_pPointer;
}

template <typename T>
T* CSmartPtr<T>::operator->()
{
    return m_pPointer;
}

#endif //__SMART_PTR_H__
