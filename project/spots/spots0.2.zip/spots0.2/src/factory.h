#ifndef __FACTORY_H__
#define __FACTORY_H__

#include "common.h"
#include "singleton.h"
#include <map>

template <typename T>
interface ICreator
{
    virtual T* Alloc() = 0;
};

template<typename K, typename T>
class CAbstractFactory;

template <typename K, typename T, typename R>
class CCreator : public ICreator<T>
{
    friend class CAbstractFactory<K, T>;

public:
    virtual T* Alloc(){return new R;}
    static CCreator* Instance(){static CCreator Instance; return &Instance;}

private:
    CCreator(){}
    ~CCreator(){}
};

template<typename K, typename T>
class CAbstractFactory
{
public:
    bool Register(K Key, ICreator<T>* pCreator);
    T* Create(K Key);

protected:
    std::map<K, ICreator<T>*> m_Creators;
};

template<typename K, typename T>
bool CAbstractFactory<K, T>::Register(K Key, ICreator<T>* pCreator)
{
    if(m_Creators.find(Key) != m_Creators.end())
        return false;
    m_Creators.insert(std::make_pair(Key, pCreator));
    return true;
}

#endif //__FACTORY_H__
