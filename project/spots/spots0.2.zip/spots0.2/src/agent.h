#ifndef __AI_AGENT_H__
#define __AI_AGENT_H__

#include "message.h"
#include "machin.h"
#include "smart_ptr.h"

typedef int TAgent;

class CAgent
{
public:
    CAgent(TAgent Agent, CSmartPtr<CRules> pRules);
    virtual ~CAgent();
    void Send(CSmartPtr<CMessage> pMessage);
    void Recv(CSmartPtr<CMessage> pMessage);
	bool operator< (const CAgent & Agent) const;
    TAgent Index() const{return m_Agent;}
    
protected:
    CMachin m_Machin;
    TAgent m_Agent;
};

#endif //__AI_AGENT_H__
