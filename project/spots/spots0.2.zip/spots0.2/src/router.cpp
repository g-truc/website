#include "router.h"
#include "message.h"

CRouter::CRouter()
{

}

CRouter::~CRouter()
{

}

void CRouter::Recv(CSmartPtr<CMessage> pMessage)
{

}

void CRouter::Send()
{
    for(TMessagesList::iterator it = m_Messages.begin(); it != m_Messages.end(); it++)
    {
        CSmartPtr<CMessage> pMessage = *it;
        if(!pMessage->Delay())
            continue;
        std::list<TAgent> Receivers = pMessage->Receivers();
        for(std::list<TAgent>::iterator it1 = Receivers.begin(); it1 != Receivers.end(); it1++)
        for(std::set<CAgent*>::iterator it2 = m_Agents.begin(); it2 != m_Agents.end(); it2++)
        {
            if(*it1 == (*it2)->Index())
            {
                (*it2)->Recv(pMessage);
                break;
            }
        }
        m_Messages.erase(it);
    }
}

bool CRouter::Register(CAgent* pAgent)
{
    std::set<CAgent*>::iterator it = m_Agents.find(pAgent);
    if(it != m_Agents.end())
        return false;
    m_Agents.insert(pAgent);
    return true;
}

bool CRouter::Release(CAgent* pAgent)
{
    std::set<CAgent*>::iterator it = m_Agents.find(pAgent);
    if(it == m_Agents.end())
        return false;

    m_Agents.erase(it);
    return true;
}
