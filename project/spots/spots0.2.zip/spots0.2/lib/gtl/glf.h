//////////////////////////////////////////////////////////////////////////////////
// OpenGL Mathematics Copyright (c) 2005 G-Truc Creation (www.g-truc.net)
//////////////////////////////////////////////////////////////////////////////////
// Groove (groove[at]g-truc.net)
// Created : 2005-01-14
// Updated : 2005-01-14
// Licence : This source is under GNU LGPL licence
//////////////////////////////////////////////////////////////////////////////////

#ifndef __glf_h_
#define __glf_h_

#include "./glm.h"
#include "./glmext.h"
#ifdef WIN32
#include <windows.h>
#endif //WIN32
#include "./gl.h"
#include "./glext.h"
#include "./glu.h"

#endif //__glf_h_
