//////////////////////////////////////////////////////////////////////////////////
// OpenGL Mathematics Copyright (c) 2005 G-Truc Creation (www.g-truc.net)
//////////////////////////////////////////////////////////////////////////////////
// Groove (groove[at]g-truc.net)
// Created : 2005-01-14
// Updated : 2005-03-06
// Licence : This source is under GNU LGPL licence
//////////////////////////////////////////////////////////////////////////////////

/*
Compiler identifier :
CC_VC71
CC_GCC3
*/

#ifndef __glm_h__
#define __glm_h__

#if defined(_WINDOWS_) || defined(_WINDOWS_H)
#error windows.h included before glm.h
#endif

#include "./glm/_vec2.inl"
#include "./glm/_vec3.inl"
#include "./glm/_vec4.inl"
#include "./glm/_mat2.inl"
#include "./glm/_mat3.inl"
#include "./glm/_mat4.inl"
#include "./glm/_func.inl"
//#include "./glm/_sampler.h"
//#include "./glm/_qualifier.h"

namespace glm
{
    typedef _xvec2<float>   vec2;
    typedef _xvec2<int>     ivec2;
    typedef _bvec2          bvec2;
    typedef _xvec3<float>   vec3;
    typedef _xvec3<int>     ivec3;
    typedef _bvec3          bvec3;
    typedef _xvec4<float>   vec4;
    typedef _xvec4<int>     ivec4;
    typedef _bvec4          bvec4;
    typedef _xmat2<float>   mat2;
    typedef _xmat3<float>   mat3;
    typedef _xmat4<float>   mat4;
/*
    typedef _sampler        sampler1D;
    typedef _sampler        sampler2D;
    typedef _sampler        sampler3D;
    typedef _sampler        samplerCube;
    typedef _sampler        sampler1DShadow;
    typedef _sampler        sampler2DShadow;
    typedef _sampler        samplerRect;
    typedef _sampler        samplerRectShadow;
*/
} //namespace glm

#endif //__glm_h__
