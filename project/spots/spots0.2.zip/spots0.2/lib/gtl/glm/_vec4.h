//////////////////////////////////////////////////////////////////////////////////
// OpenGL Mathematics Copyright (c) 2005 G-Truc Creation (www.g-truc.net)
//////////////////////////////////////////////////////////////////////////////////
// Author  : Groove (groove[at]g-truc.net)
// Created : 2005-01-10
// Updated : 2005-02-02
// Licence : This source is under GNU LGPL licence
// File    : _vec4.h
//////////////////////////////////////////////////////////////////////////////////

#ifndef __vec4_h__
#define __vec4_h__

namespace glm
{
    template <typename T> class _xvec2;
    template <typename T> class _xvec3;
    class _bvec4;

    // vec4 and ivec4 declaration
    template <typename T> 
    class _xvec4
    {
    public:
        int _size() const;

    public:
        // Data
        /* ISO C++ version unavailable with VC7.1 ...
            union{T x, r, s;};
            union{T y, g, t;};
            union{T z, b, q;};
            union{T w, a, p;};
        */
        // Solution away from ISO C++ but available with VC7.1 and GCC without -pedantic
        union 
        {
            struct{T x, y, z, w;};
            struct{T r, g, b, a;};
            struct{T s, t, q, p;};
        };

        // Constructors
	    _xvec4();
	    _xvec4(const T x, const T y, const T z, const T w);
        _xvec4(T f);

        // Convertions
        _xvec4(const _xvec2<T> & v1, const _xvec2<T> & v2);
        _xvec4(const _xvec3<T> & v1, T v2);
        _xvec4(T v1, const _xvec3<T> & v2);
        _xvec4(T v1, T v2, const _xvec2<T> & v3);
        _xvec4(T v1, const _xvec2<T> & v2, T v3);
        _xvec4(const _xvec2<T> & v1, T v2, T v3);
        _xvec4(const _bvec4 & v);

        template <typename U>
        _xvec4(const _xvec4<U> & v)
        {
            this->x = T(v.x);
            this->y = T(v.y);
            this->z = T(v.z);
            this->w = T(v.w);
        }

        // Accesses
        T& operator[](int i);
        T operator[](int i) const;
        operator T*();
	    operator const T*() const;

        // Operators
	    _xvec4<T> operator+ (const T s) const;
	    _xvec4<T> & operator+= (const T s);
	    _xvec4<T> operator+(const _xvec4<T> & v) const;
	    _xvec4<T> & operator+=(const _xvec4<T> & v);
	    _xvec4<T> operator- (const T s) const;
	    _xvec4<T> & operator-= (const T s);
	    _xvec4<T> operator-(const _xvec4<T> & v) const;
	    _xvec4<T> & operator-=(const _xvec4<T> & v);
	    _xvec4<T> operator*(const T s) const;
	    _xvec4<T> & operator*=(const T s);
	    _xvec4<T> operator* (const _xvec4<T> & v) const;
	    _xvec4<T> & operator*= (const _xvec4<T> & v);
	    _xvec4<T> operator/(const T s) const;
	    _xvec4<T> & operator/=(const T s);
	    _xvec4<T> operator/ (const _xvec4<T> & v) const;
	    _xvec4<T> & operator/= (const _xvec4<T> & v);
        _xvec4<T> operator-() const;
	    _xvec4<T> operator++();
	    _xvec4<T> operator++(int n) const;
	    _xvec4<T> operator--();
        _xvec4<T> operator--(int n) const;
    };

    template <typename T> _xvec4<T> operator+ (const T s, const _xvec4<T> & v)
    {
        return v + s;
    }

    template <typename T> _xvec4<T> operator- (const T s, const _xvec4<T> & v)
    {
        _xvec4<T> result;
        result.x = s - v.x;
        result.y = s - v.y;
        result.z = s - v.z;
        result.w = s - v.w;
        return result;
    }

    template <typename T> _xvec4<T> operator* (const T s, const _xvec4<T> & v)
    {
        return v * s;
    }

    //////////////////////////////////////////////////////////

    class _bvec2;
    class _bvec3;

    // bvec4 declaration
    class _bvec4
    {
    public:
        int _size() const;

    public:
        // Data
        union{bool x, r, s;};
        union{bool y, g, t;};
        union{bool z, b, q;};
        union{bool w, a, p;};

        // Constructors
	    _bvec4();
	    _bvec4(const bool x, const bool y, const bool z, const bool w);
        _bvec4(bool b);
        _bvec4(const _bvec2 & v1, const _bvec2 & v2);
        _bvec4(const _bvec3 & v1, bool v2);
        _bvec4(bool v1, const _bvec3 & v2);
        _bvec4(bool v1, bool v2, const _bvec2 & v3);
        _bvec4(bool v1, const _bvec2 & v2, bool v3);
        _bvec4(const _bvec2 & v1, bool v2, bool v3);

        // Convertions
        template <typename U>
        _bvec4(const _xvec4<U> & v)
        {
            this->x = bool(v.x);
            this->y = bool(v.y);
            this->z = bool(v.z);
            this->w = bool(v.w);
        }

        // Accesses
        bool& operator[](int i);
        bool operator[](int i) const;
        operator bool*();
	    operator const bool*() const;

        // Operators
	    _bvec4 operator++();
	    _bvec4 operator++(int n) const;
        _bvec4 operator--();
	    _bvec4 operator--(int n) const;
        _bvec4 operator!() const ;
    };
} //namespace glm

#endif //__vec4_h__

