//////////////////////////////////////////////////////////////////////////////////
// OpenGL Mathematics Copyright (c) 2005 G-Truc Creation (www.g-truc.net)
//////////////////////////////////////////////////////////////////////////////////
// Groove (groove[at]g-truc.net)
// Created : 2005-04-03
// Updated : 2005-04-24
// Licence : This source is under GNU LGPL licence
//////////////////////////////////////////////////////////////////////////////////

#ifndef __glx_h__
#define __glx_h__

#define GLM_GT_quaternion                0
#define GLM_GT_transform                 1
#define GLM_GT_transpose                 1
#define GLM_GT_orthonormalize            1
#define GLM_GT_inverse                   1
#define GLM_GT_determinant               1
#define GLM_GT_length2                   1
#define GLM_GT_matrix_cross_product      1
#define GLM_GT_projection                1
#define GLM_GT_perpendicular             1
#define GLM_GT_optimum_pow               1
#define GLM_GT_complex                   1
#define GLM_GT_double                    1
#define GLM_GT_color_space               1
#define GLM_GT_vector_comp_mult          1

#include "../../glm.h"
#include "./_ext.inl"
#include "./_quat.inl"

namespace glm
{
    // GLM_GT_quaternion
    typedef _quat<float>     __quatGT;

    // GLM_GT_double
    typedef _xvec2<double>   __dvec2GT;
    typedef _xvec3<double>   __dvec3GT;
    typedef _xvec4<double>   __dvec4GT;
    typedef _xmat2<double>   __dmat2GT;
    typedef _xmat3<double>   __dmat3GT;
    typedef _xmat4<double>   __dmat4GT;
    typedef _quat<double>    __dquatGT;
} //namespace glm

#endif //__glx_h__
