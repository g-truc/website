//////////////////////////////////////////////////////////////////////////////////
// OpenGL Mathematics Copyright (c) 2005 G-Truc Creation (www.g-truc.net)
//////////////////////////////////////////////////////////////////////////////////
// Author  : Groove (groove[at]g-truc.net)
// Created : 2005-01-10
// Updated : 2005-02-02
// Licence : This source is under GNU LGPL licence
// File    : _vec3.h
//////////////////////////////////////////////////////////////////////////////////

#ifndef __vec3_h__
#define __vec3_h__

namespace glm
{
    template <typename T> class _xvec2;
    template <typename T> class _xvec4;
    class _bvec3;

    // vec3 and ivec3 declaration
    template <typename T> 
    class _xvec3
    {
    public:
        int _size() const;

    public:
        // Data
        /* ISO C++ version unavailable with VC7.1 ...
            union{T x, r, s;};
            union{T y, g, t;};
            union{T z, b, q;};
        */
        // Solution away from ISO C++ but available with VC7.1 and GCC without -pedantic
        union 
        {
            struct{T x, y, z;};
            struct{T r, g, b;};
            struct{T s, t, q;};
        };

        // Constructors
	    _xvec3();
	    _xvec3(const T x, const T y, const T z);
        _xvec3(T f);

        // Convertions
        _xvec3(const _xvec2<T> & v1, T v2);
        _xvec3(T v1, const _xvec2<T> & v2);
        _xvec3(const _xvec4<T> & v);
        _xvec3(const glm::_bvec3 & v);

        template <typename U>
        _xvec3(const _xvec3<U> & v)
        {
            this->x = T(v.x);
            this->y = T(v.y);
            this->z = T(v.z);
        }

        // Accesses
        T& operator [] (int i);
        T operator [] (int i) const;
        operator T* ();
	    operator const T* () const;

        // Operators
	    _xvec3<T> operator+ (const T s) const;
	    _xvec3<T> & operator+= (const T s);
	    _xvec3<T> operator+ (const _xvec3<T> & v) const;
	    _xvec3<T> & operator+= (const _xvec3<T> & v);
	    _xvec3<T> operator- (const T s) const;
	    _xvec3<T> & operator-= (const T s);
	    _xvec3<T> operator- (const _xvec3<T> & v) const;
	    _xvec3<T> & operator-= (const _xvec3<T> & v);
        _xvec3<T> operator* (const T s) const;
	    _xvec3<T> & operator*= (const T s);
	    _xvec3<T> operator* (const _xvec3<T> & v) const;
	    _xvec3<T> & operator*= (const _xvec3<T> & v);
        _xvec3<T> operator/ (const T s) const;
	    _xvec3<T> & operator/= (const T s);
	    _xvec3<T> operator/ (const _xvec3<T> & v) const;
	    _xvec3<T> & operator/= (const _xvec3<T> & v);
        _xvec3<T> operator- () const;
        _xvec3<T> operator++ ();
	    _xvec3<T> operator++ (int n) const;
	    _xvec3<T> operator-- ();
	    _xvec3<T> operator-- (int n) const;
    };

    template <typename T> _xvec3<T> operator+ (const T s, const _xvec3<T> & v)
    {
        return v + s;
    }

    template <typename T> _xvec3<T> operator- (const T s, const _xvec3<T> & v)
    {
        _xvec3<T> result;
        result.x = s - v.x;
        result.y = s - v.y;
        result.z = s - v.z;
        return result;
    }

    template <typename T> _xvec3<T> operator* (const T s, const _xvec3<T> & v)
    {
        return v * s;
    }

    //////////////////////////////////////////////////////////

    class _bvec2;
    class _bvec4;

    // bvec3 declaration
    class _bvec3
    {
    public:
        int _size () const;

    public:
        // Data
        union{bool x, r, s;};
        union{bool y, g, t;};
        union{bool z, b, q;};

        // Constructors
	    _bvec3 ();
	    _bvec3 (const bool x, const bool y, const bool z);
        _bvec3 (bool b);
        _bvec3 (const _bvec2 & v1, bool v2);
        _bvec3 (bool v1, const _bvec2 & v2);
        _bvec3 (const _bvec4 & v);

        // Convertions
        template <typename U>
        _bvec3(const _xvec3<U> & v)
        {
            this->x = bool(v.x);
            this->y = bool(v.y);
            this->z = bool(v.z);
        }

        // Accesses
        bool& operator [] (int i);
        bool operator [] (int i) const;
        operator bool* ();
	    operator const bool* () const;

        // Operators
	    _bvec3 operator-- ();
	    _bvec3 operator++ ();
	    _bvec3 operator-- (int n) const;
	    _bvec3 operator++ (int n) const;
	    _bvec3 operator! () const;
    };
} //namespace glm

#endif //__vec3_h__
