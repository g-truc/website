/***********************************************\
	Mitose
*************************************************
	G-Truc Creation, www.g-truc.net
	par Groove, groove@g-truc.net
*************************************************
	main_sdl.cpp, 15/07/2004
\***********************************************/

#include "mitose.h"

SDL_Surface *g_pWindow;

void Quitter (int iValue);
void Redimensionner (int iWidth, int iHeight);
void CreerFenetre (bool bFullscreen);

void Quitter (int iValue)
{
	SDL_FreeSurface (g_pWindow);
	SDL_Quit ();
	exit (iValue);
}

void Redimensionner (int iWidth, int iHeight)
{
	if (iHeight == 0)
		iHeight = 1;

    glViewport (0, 0, iWidth, iHeight);

    glMatrixMode (GL_PROJECTION);
    glLoadIdentity ();

    gluPerspective (45.f, (float)iWidth / (float)iHeight, 0.1f, 512);

    glMatrixMode (GL_MODELVIEW);
    glLoadIdentity ();
}

void CreerFenetre (bool bFullscreen)
{
    if (SDL_Init (SDL_INIT_VIDEO) < 0)
    {
        printf ("Impossible d'initializing SDL Video : %s", SDL_GetError ());
        Quitter (1);
    }

	int iVideoConf;
	if (bFullscreen)
		iVideoConf = SDL_OPENGL | SDL_FULLSCREEN;
	else
		iVideoConf = SDL_OPENGL;

    SDL_GL_SetAttribute (SDL_GL_DOUBLEBUFFER, 1);
    SDL_GL_SetAttribute (SDL_GL_DEPTH_SIZE, 24);
    SDL_GL_SetAttribute (SDL_GL_STENCIL_SIZE, 0);
    SDL_GL_SetAttribute (SDL_GL_ACCUM_RED_SIZE, 0);
    SDL_GL_SetAttribute (SDL_GL_ACCUM_GREEN_SIZE, 0);
    SDL_GL_SetAttribute (SDL_GL_ACCUM_BLUE_SIZE, 0);
    SDL_GL_SetAttribute (SDL_GL_ACCUM_ALPHA_SIZE, 0);

	if ((g_pWindow = SDL_SetVideoMode (FENETRE_LARGEUR, FENETRE_HAUTEUR, FENETRE_COULEUR, iVideoConf)) == NULL)
	{
        printf ("Impossible de cr�er une fenetre : %s\n", SDL_GetError());
        Quitter (1);
    }

    SDL_WM_SetCaption (FENETRE_NOM, FENETRE_NOM);

	Redimensionner (FENETRE_LARGEUR, FENETRE_HAUTEUR);
}

int main (int argc, char* argv[])
{
	CreerFenetre (FENETRE_FULLSCREEN);
	Initialisation ();

    while (1)
    {
		SDL_Event event;

		while (SDL_PollEvent (&event))
		{
			switch (event.type)
			{
				case SDL_QUIT:
					Quitter (0);

				case SDL_KEYDOWN:
					Quitter (0);
					break;

				default:
					break;
			}
		}

		Afficher ();

		SDL_GL_SwapBuffers ();
	}

	return 0;
}
