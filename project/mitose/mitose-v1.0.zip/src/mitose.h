/***********************************************\
	Mitose
*************************************************
	G-Truc Creation, www.g-truc.net
	par Groove, groove@g-truc.net
*************************************************
	mitose.cpp, 14/08/2004
\***********************************************/

#ifndef EXEMPLE_H
#define EXEMPLE_H

#include "./sdl/include/SDL.h"
#ifdef WIN32
#include <windows.h>
#endif //WIN32
#include <GL/gl.h>
#include <GL/glu.h>
#include <stdio.h>

#define FENETRE_NOM			"Mitose (www.g-truc.net)"
#define FENETRE_LARGEUR		640
#define FENETRE_HAUTEUR		480
#define FENETRE_COULEUR		32
#define FENETRE_FULLSCREEN	true

void Initialisation ();
void Afficher ();

#endif // EXEMPLE_H
