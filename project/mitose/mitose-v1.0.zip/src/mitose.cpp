/***********************************************\
	Mitose
*************************************************
	G-Truc Creation, www.g-truc.net
	par Groove, groove@g-truc.net
*************************************************
	mitose.cpp, 14/08/2004
\***********************************************/

#include "mitose.h"
#include <math.h>

#ifndef M_PI
#define M_PI 3.141592654f
#endif //M_PI

#define SIZE_EFFET 128

float g_fData[SIZE_EFFET][SIZE_EFFET][3];

float RandFloat (float fMin, float fMax)
{
	return (rand () / (float)RAND_MAX * (fMax - fMin)) + fMin;
}

void Afficher ()
{
	static float fRotateX = 0.66f;
	static float fRotateY = 0.33f;
	static float fRotateZ = 0.00f;

	for (int j = 0; j < SIZE_EFFET / 2; j++)
	{
		for (int i = 0; i < SIZE_EFFET / 2; i++)
		{
			g_fData[i][SIZE_EFFET - 1 - j][0] = sinf (i * j / (float)((SIZE_EFFET / 2) * (SIZE_EFFET / 2)) * fRotateX * M_PI);
			g_fData[i][SIZE_EFFET - 1 - j][1] = sinf (i * j / (float)((SIZE_EFFET / 2) * (SIZE_EFFET / 2)) * fRotateY * M_PI);
			g_fData[i][SIZE_EFFET - 1 - j][2] = sinf (i * j / (float)((SIZE_EFFET / 2) * (SIZE_EFFET / 2)) * fRotateZ * M_PI);
		}
	}

	for (int j = 0; j < SIZE_EFFET / 2; j++)
	{
		for (int i = 0; i < SIZE_EFFET / 2; i++)
		{
			g_fData[SIZE_EFFET - 1 - i][SIZE_EFFET - 1 - j][0] = g_fData[i][SIZE_EFFET - 1 - j][0];
			g_fData[SIZE_EFFET - 1 - i][SIZE_EFFET - 1 - j][1] = g_fData[i][SIZE_EFFET - 1 - j][1];
			g_fData[SIZE_EFFET - 1 - i][SIZE_EFFET - 1 - j][2] = g_fData[i][SIZE_EFFET - 1 - j][2];
		}
	}

	for (int j = 0; j < SIZE_EFFET / 2; j++)
	{
		for (int i = 0; i < SIZE_EFFET / 2; i++)
		{
			g_fData[SIZE_EFFET - 1 - i][j][0] = g_fData[i][SIZE_EFFET - 1 - j][0];
			g_fData[SIZE_EFFET - 1 - i][j][1] = g_fData[i][SIZE_EFFET - 1 - j][1];
			g_fData[SIZE_EFFET - 1 - i][j][2] = g_fData[i][SIZE_EFFET - 1 - j][2];
		}
	}

	for (int j = 0; j < SIZE_EFFET / 2; j++)
	{
		for (int i = 0; i < SIZE_EFFET / 2; i++)
		{
			g_fData[i][j][0] = g_fData[i][SIZE_EFFET - 1 - j][0];
			g_fData[i][j][1] = g_fData[i][SIZE_EFFET - 1 - j][1];
			g_fData[i][j][2] = g_fData[i][SIZE_EFFET - 1 - j][2];
		}
	}

	glLoadIdentity ();
	gluLookAt (0, -SIZE_EFFET * 3 / 4, 0, 0, 0, 0, 0, 0, 1);

	glPushMatrix ();
		glRotatef (90, 1.0f, 0.0f, 0.0f);
		glTranslatef (-(SIZE_EFFET - 1) / 2.f, -(SIZE_EFFET - 1) / 2.f, 0);
		glBegin (GL_QUADS);
		for (int j = 0; j < SIZE_EFFET / 2; j++)
		{
			for (int i = 0; i < SIZE_EFFET / 2; i++)
			{
				glColor3f (g_fData[i + 1][j + 0][0], g_fData[i + 1][j + 0][1], g_fData[i + 1][j + 0][2]);
				glVertex2i (i + 1, j + 0);
				glColor3f (g_fData[i + 1][j + 1][0], g_fData[i + 1][j + 1][1], g_fData[i + 1][j + 1][2]);
				glVertex2i (i + 1, j + 1);
				glColor3f (g_fData[i + 0][j + 1][0], g_fData[i + 0][j + 1][1], g_fData[i + 0][j + 1][2]);
				glVertex2i (i + 0, j + 1);
				glColor3f (g_fData[i + 0][j + 0][0], g_fData[i + 0][j + 0][1], g_fData[i + 0][j + 0][2]);		
				glVertex2i (i + 0, j + 0);
			}
		}
		glEnd ();

		glBegin (GL_QUADS);
		for (int j = SIZE_EFFET / 2; j < SIZE_EFFET; j++)
		{
			for (int i = SIZE_EFFET / 2; i < SIZE_EFFET; i++)
			{
				glColor3f (g_fData[i + 1][j + 0][0], g_fData[i + 1][j + 0][1], g_fData[i + 1][j + 0][2]);
				glVertex2i (i + 1, j + 0);
				glColor3f (g_fData[i + 1][j + 1][0], g_fData[i + 1][j + 1][1], g_fData[i + 1][j + 1][2]);
				glVertex2i (i + 1, j + 1);
				glColor3f (g_fData[i + 0][j + 1][0], g_fData[i + 0][j + 1][1], g_fData[i + 0][j + 1][2]);
				glVertex2i (i + 0, j + 1);
				glColor3f (g_fData[i + 0][j + 0][0], g_fData[i + 0][j + 0][1], g_fData[i + 0][j + 0][2]);		
				glVertex2i (i + 0, j + 0);
			}
		}
		glEnd ();

		glBegin (GL_QUADS);
		for (int j = 0; j < SIZE_EFFET / 2; j++)
		{
			for (int i = SIZE_EFFET / 2; i < SIZE_EFFET; i++)
			{
				glColor3f (g_fData[i + 0][j + 0][0], g_fData[i + 0][j + 0][1], g_fData[i + 0][j + 0][2]);		
				glVertex2i (i + 0, j + 0);
				glColor3f (g_fData[i + 1][j + 0][0], g_fData[i + 1][j + 0][1], g_fData[i + 1][j + 0][2]);
				glVertex2i (i + 1, j + 0);
				glColor3f (g_fData[i + 1][j + 1][0], g_fData[i + 1][j + 1][1], g_fData[i + 1][j + 1][2]);
				glVertex2i (i + 1, j + 1);
				glColor3f (g_fData[i + 0][j + 1][0], g_fData[i + 0][j + 1][1], g_fData[i + 0][j + 1][2]);
				glVertex2i (i + 0, j + 1);
			}
		}
		glEnd ();

		glBegin (GL_QUADS);
		for (int j = SIZE_EFFET / 2; j < SIZE_EFFET; j++)
		{
			for (int i = 0; i < SIZE_EFFET / 2; i++)
			{
				glColor3f (g_fData[i + 0][j + 0][0], g_fData[i + 0][j + 0][1], g_fData[i + 0][j + 0][2]);		
				glVertex2i (i + 0, j + 0);
				glColor3f (g_fData[i + 1][j + 0][0], g_fData[i + 1][j + 0][1], g_fData[i + 1][j + 0][2]);
				glVertex2i (i + 1, j + 0);
				glColor3f (g_fData[i + 1][j + 1][0], g_fData[i + 1][j + 1][1], g_fData[i + 1][j + 1][2]);
				glVertex2i (i + 1, j + 1);
				glColor3f (g_fData[i + 0][j + 1][0], g_fData[i + 0][j + 1][1], g_fData[i + 0][j + 1][2]);
				glVertex2i (i + 0, j + 1);
			}
		}
		glEnd ();
	glPopMatrix ();

	fRotateX += 0.001f * SIZE_EFFET;
	fRotateY += 0.001f * SIZE_EFFET;
	fRotateZ += 0.001f * SIZE_EFFET;
}

void Initialisation ()
{
	glClearColor (0.0, 0.0, 0.0, 0.0);
	glShadeModel (GL_SMOOTH);
}
