//////////////////////////////////////////////////////////////////////////////////
// Stuff (c) 2007 G-Truc Creation (www.g-truc.net)
//////////////////////////////////////////////////////////////////////////////////
// File    : async_ptr.hpp
// Author  : Christophe [Groove] Riccio (g.truc.creation [at] gmail [point] com)
// Created : 2007-08-02
// Updated : 2007-08-02
// Licence : This source is under GNU LGPL licence
//////////////////////////////////////////////////////////////////////////////////
// async_ptr allows to shared a variable that isn't already created
//////////////////////////////////////////////////////////////////////////////////

#ifndef __STUFF_ASYNC_PTR_H__
#define __STUFF_ASYNC_PTR_H__

#include <memory>

namespace 
{
	class static_cast_tag{};
	class const_cast_tag{};
	class dynamic_cast_tag{};
}

namespace stuff
{
	template<typename T>
	struct ptr_deleter
	{
		void operator()(T* object)
		{
			delete object;
		}
	};

	template<typename T, class D = ptr_deleter<T> >
	class async_ptr
	{
	private:
		typedef unsigned int size_type;

	public:
		typedef T element_type;

	public:
		async_ptr();
		async_ptr(const async_ptr<T, D>& r);
		async_ptr(T* p);

		// async_ptr will release p by calling d(p)
		async_ptr(T* p, D d);
	/*
		// async_ptr will release p by calling d(p) and create p bu calling a(p)
		template<typename D, typename A>
		async_ptr(T* p, D d, A a);
	*/
		async_ptr(std::auto_ptr<T>& p);

		virtual ~async_ptr();

		template<typename U>
		async_ptr(const async_ptr<U>& r, static_cast_tag);

		template<typename U>
		async_ptr(const async_ptr<U>& r, const_cast_tag);

		template<typename U>
		async_ptr(const async_ptr<U>& r, dynamic_cast_tag);

		T* get() const;
		void reset();
		void reset(T* p);
		void reset(T* p, D d); // async_ptr will release p by calling d(p)
		template<typename A>
		void reset(T* p, D d, A a); // async_ptr will release p by calling d(p) and create p bu calling a(p)

		void swap(async_ptr<T, D>& r);

		size_type use_count() const;
		bool empty() const;
		bool unique() const;
		T* release();

		bool operator!() const;
		bool operator==(const async_ptr<T, D>& r) const;
		bool operator==(const int Null) const;
		bool operator!=(const async_ptr<T, D>& r) const;
		bool operator!=(const int Null) const;
		bool operator<(const async_ptr<T, D>& r) const;

		async_ptr<T, D>& operator=(const async_ptr<T, D>& r);

		T& operator* () const;
		T* operator-> () const;

		static const async_ptr<T, D> null;

	private:
		explicit async_ptr(bool Null);

		void _release();
		void _free();

	public: //(that not sweet but required by cast functions)
		T** object;
		size_type* counter;
		D deleter;
	};

	template<typename T, typename U> 
	async_ptr<T> static_pointer_cast(const async_ptr<U>& r)
	{
		return async_ptr<T>(r, static_cast_tag());
	}

	template<typename T, typename U> 
	async_ptr<T> const_pointer_cast(const async_ptr<U>& r)
	{
		return async_ptr<T>(r, const_cast_tag());
	}

	template<typename T, typename U> 
	async_ptr<T> dynamic_pointer_cast(const async_ptr<U>& r)
	{
		return async_ptr<T>(r, dynamic_cast_tag());
	}

	template<typename T> 
	inline T* get_pointer(const async_ptr<T>& p)
	{
		return p.get();
	}

	template<typename D, typename T> 
	inline D* get_deleter(const async_ptr<T>& p)
	{
		return &p.deleter;
	}
	/*
	template<typename A, typename T> 
	inline A* get_allocator(const async_ptr<T>& p)
	{
		return 0;
	}
	*/
	template<typename T, typename D> 
	inline void swap(async_ptr<T, D>& a, async_ptr<T, D>& b)
	{
		a.swap(b);
	}
}

#include "async_ptr.inl"

#endif//__STUFF_ASYNC_PTR_H__
