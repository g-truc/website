//////////////////////////////////////////////////////////////////////////////////
// Stuff (c) 2007 G-Truc Creation (www.g-truc.net)
//////////////////////////////////////////////////////////////////////////////////
// File    : async_array.hpp
// Author  : Christophe [Groove] Riccio (g.truc.creation [at] gmail [point] com)
// Created : 2007-08-02
// Updated : 2007-08-02
// Licence : This source is under GNU LGPL licence
//////////////////////////////////////////////////////////////////////////////////
// async_array allows to shared an array that isn't already created
//////////////////////////////////////////////////////////////////////////////////

#ifndef __STUFF_ASYNC_ARRAY_H__
#define __STUFF_ASYNC_ARRAY_H__

#include "async_ptr.hpp"

namespace stuff
{
	template<typename T>
	struct array_deleter
	{
		void operator()(T* object)
		{
			delete[] object;
		}
	};

	template<typename T, class D = array_deleter<T> >
	class async_array
	{
	private:
		typedef unsigned int size_type;

	public:
		typedef T element_type;

	public:
		async_array();
		async_array(const async_array<T, D>& r);
		async_array(T* p);

		// async_array will release p by calling d(p)
		async_array(T* p, D d);
	/*
		// async_array will release p by calling d(p) and create p bu calling a(p)
		template<typename D, typename A>
		async_array(T* p, D d, A a);
	*/

		virtual ~async_array();

		T* get() const;
		void reset();
		void reset(T* p);
		void reset(T* p, D d); // async_ptr will release p by calling d(p)
		template<typename A>
		void reset(T* p, D d, A a); // async_ptr will release p by calling d(p) and create p bu calling a(p)

		void swap(async_array<T, D>& r);

		size_type use_count() const;
		bool empty() const;
		bool unique() const;
		T* release();

		bool operator!() const;
		bool operator==(const async_array<T, D>& r) const;
		bool operator==(const int Null) const;
		bool operator!=(const async_array<T, D>& r) const;
		bool operator!=(const int Null) const;
		bool operator<(const async_array<T, D>& r) const;

		async_array<T, D>& operator=(const async_array<T, D>& r);

		T& operator[](std::ptrdiff_t i) const;

		static const async_array<T, D> null;

	private:
		explicit async_array(bool Null);

		void _release();
		void _free();

	public: //(that not sweet but required by cast functions)
		T** object;
		size_type* counter;
		D deleter;
	};

	template<typename D, typename T> 
	inline D* get_deleter(const async_array<T>& p)
	{
		return &p.deleter;
	}
	/*
	template<typename A, typename T> 
	inline A* get_allocator(const async_ptr<T>& p)
	{
		return 0;
	}
	*/
	template<typename T, typename D> 
	inline void swap(async_array<T, D>& a, async_array<T, D>& b)
	{
		a.swap(b);
	}
}

#include "async_array.inl"

#endif//__STUFF_ASYNC_ARRAY_H__
