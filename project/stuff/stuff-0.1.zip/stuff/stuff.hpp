//////////////////////////////////////////////////////////////////////////////////
// Stuff (c) 2007 G-Truc Creation (www.g-truc.net)
//////////////////////////////////////////////////////////////////////////////////
// File    : stuff.hpp
// Author  : Christophe [Groove] Riccio (g.truc.creation [at] gmail [point] com)
// Created : 2007-08-02
// Updated : 2007-08-02
// Licence : This source is under GNU LGPL licence
//////////////////////////////////////////////////////////////////////////////////

#ifndef __STUFF_H__
#define __STUFF_H__

#include "async_ptr.hpp"
#include "async_array.hpp"
#include "singleton.hpp"

#endif//__STUFF_H__
