#include <iostream>
#include <vector>
#include <map>
#include "../async_ptr.hpp"
#include "../async_array.hpp"
#include "../singleton.hpp"
#include <boost/shared_ptr.hpp>
#include <boost/noncopyable.hpp>

namespace
{
	//! CSingleton
	template <typename T> 
	class CSingleton
	{
	public:
		// Get and/or create the singleton instance
		static T* GetInstance();
		// Delete singleton instance if it was created 
		static void Destroy();
		// Test if singleton instance was created
		static bool IsCreated();

	private:
		static T* object;
	};

	template <typename T> 
	T* CSingleton<T>::object = NULL;

	template <typename T> 
	T* CSingleton<T>::GetInstance()
	{
		if(object == NULL)
			object = new T;
		return object;
	}

	template <typename T> 
	void CSingleton<T>::Destroy()
	{
		if(object != NULL)
			delete object;
	}

	template <typename T> 
	bool CSingleton<T>::IsCreated()
	{
		return object != NULL;
	}

	class Class
	{
	public:
		Class(int Pouet) : Pouet(Pouet) {}
		const int Pouet;
	};

	typedef stuff::async_ptr<Class> THandle;

	class CTemplate
	{
	public:

	};

	class CManager : public CSingleton<CManager>
	{
		enum EMessage
		{
			MESSAGE_CREATE_CLASS
		};

		struct IMessage
		{
			virtual EMessage GetType() const = 0;
		};

		struct CMessageCreateClass : public IMessage
		{
			CMessageCreateClass(const THandle& Handle, const CTemplate& Template) :
				Handle(Handle),
				Template(Template)
			{}

			virtual EMessage GetType() const {return MESSAGE_CREATE_CLASS;}

			THandle Handle;
			CTemplate Template;
		};


	public:
		THandle CreateClass(const CTemplate& Template);
		void UseClass(const THandle& Handle);
		void FlushMessages();

	private:
		std::vector<THandle> m_Classes;
		std::vector<IMessage*> m_MessagePool;
	};

	THandle CManager::CreateClass(const CTemplate& Template)
	{
		THandle Handle;
		m_MessagePool.push_back(new CMessageCreateClass(Handle, Template));
		return Handle;
	}

	void CManager::UseClass(const THandle& Handle)
	{
		const Class* pClass = Handle.get();
		if(pClass != 0)
			std::cout << "Manager: " << pClass->Pouet << std::endl;
	}

	void CManager::FlushMessages()
	{
		for(std::vector<IMessage*>::iterator it = m_MessagePool.begin(); it != m_MessagePool.end(); ++it)
		{
			switch((*it)->GetType())
			{
				case MESSAGE_CREATE_CLASS:
				{
					CMessageCreateClass* Message = static_cast<CMessageCreateClass*>(*it);
					m_Classes.push_back(Message->Handle);
					Message->Handle.reset(new Class(76)); //Message->Template
				}
				break;
			}
			delete *it;
		}
		m_MessagePool.clear();
	}
}

class CTruc
{
public:
	virtual void Print() const{printf("Coucou C\n");}
};

class DTruc : public CTruc
{
public:
	virtual void Print() const{printf("Coucou D\n");}
};

void test_aync_ptr_manager()
{
	CManager* Manager = CManager::GetInstance();
	THandle HandleA = Manager->CreateClass(CTemplate());
	THandle HandleB = HandleA;
	Manager->FlushMessages();
	Manager->UseClass(HandleA);
	Manager->UseClass(HandleB);
	HandleB = THandle::null;
	Manager->UseClass(HandleA);
	Manager->UseClass(HandleB);
}

void test_aync_ptr_basic()
{
	stuff::async_ptr<int> RefHandleA;
	stuff::async_ptr<int> RefHandleB = RefHandleA;
	stuff::async_ptr<int> RefHandleC;
	stuff::async_ptr<int> RefHandleD = stuff::async_ptr<int>::null;
	stuff::async_ptr<int> RefHandleE = RefHandleA;
	stuff::async_ptr<int> RefHandleF = stuff::async_ptr<int>::null;
	stuff::async_ptr<CTruc> RefHandleG(new DTruc);
	stuff::async_ptr<int> RefHandleH(new int(76), stuff::ptr_deleter<int>());
	stuff::async_ptr<int> RefHandleI = RefHandleH;
	stuff::async_ptr<int> RefHandleJ;
	RefHandleJ = RefHandleI;

	RefHandleF.reset(new int(77));
	if(RefHandleF != NULL)
		printf("F is not null\n");

	RefHandleC = RefHandleA;
	RefHandleB = RefHandleA;

	RefHandleA.reset(new int(76));
	RefHandleC.reset(new int(82));

	if(!RefHandleA.empty())
		printf("A is not empty\n");

	if(!RefHandleB.empty())
		printf("B is not empty\n");

	if(!RefHandleC.empty())
		printf("C is not empty\n");

	if(RefHandleD.empty())
		printf("D is empty\n");

	if(RefHandleA != NULL)
		printf("A is not null\n");

	if(RefHandleB != NULL)
		printf("B is not null\n");

	if(RefHandleC != NULL)
		printf("C is not null\n");

	if(RefHandleD == NULL)
		printf("D is null\n");

	if(RefHandleA != stuff::async_ptr<int>::null)
		printf("A is not null\n");

	if(RefHandleB != stuff::async_ptr<int>::null)
		printf("B is not null\n");

	if(RefHandleC != stuff::async_ptr<int>::null)
		printf("C is not null\n");

	if(RefHandleD == stuff::async_ptr<int>::null)
		printf("D is null\n");

	RefHandleD = stuff::async_ptr<int>();
	RefHandleD.reset(new int(76));
	RefHandleE = stuff::async_ptr<int>(new int(75));

	if(RefHandleA == RefHandleB)
		printf("A == B\n");

	if(RefHandleA == RefHandleC)
		printf("A == C\n");

	if(RefHandleA != RefHandleD)
		printf("A != D\n");

	printf("A : %d\n", *RefHandleA.get());
	printf("B : %d\n", *RefHandleB.get());
	printf("C : %d\n", *RefHandleC.get());
	printf("D : %d\n", *RefHandleD.get());
	printf("E : %d\n", *RefHandleE.get());

	printf("A : %d\n", *RefHandleA);
	printf("B : %d\n", *RefHandleB);
	printf("C : %d\n", *RefHandleC);
	printf("D : %d\n", *RefHandleD);
	printf("E : %d\n", *RefHandleE);

	RefHandleD.swap(RefHandleE);

	printf("D : %d\n", *RefHandleD);
	printf("E : %d\n", *RefHandleE);

	swap(RefHandleD, RefHandleE);

	printf("D : %d\n", *RefHandleD);
	printf("E : %d\n", *RefHandleE);

	stuff::async_ptr<CTruc> pCTruc = new CTruc();
	pCTruc->Print();
	(*pCTruc).Print();

	stuff::async_ptr<DTruc> pDTruc = new DTruc();
	pDTruc->Print();
	(*pDTruc).Print();

	stuff::async_ptr<const CTruc> pETruc = new CTruc();
	pETruc->Print();
	(*pETruc).Print();

	pCTruc = stuff::static_pointer_cast<CTruc>(pDTruc);
	pCTruc = stuff::dynamic_pointer_cast<CTruc>(pDTruc);
	pCTruc = stuff::const_pointer_cast<CTruc>(pETruc);
}

class CClass : public stuff::singleton<CClass>
{
	friend class stuff::singleton<CClass>;

private:
	CClass(){}
	~CClass(){}
};

void test_singleton()
{
	{
		CClass& Class = stuff::singleton<CClass>::get();
	}
	if(!stuff::singleton<CClass>::empty())
	{
		stuff::singleton<CClass>::release();
	}
}

int main()
{
	

	test_aync_ptr_basic();
	test_aync_ptr_manager();

	system("pause");
}
