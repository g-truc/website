//////////////////////////////////////////////////////////////////////////////////
// Stuff (c) 2007 G-Truc Creation (www.g-truc.net)
//////////////////////////////////////////////////////////////////////////////////
// File    : singleton.hpp
// Author  : Christophe [Groove] Riccio (g.truc.creation [at] gmail [point] com)
// Created : 2007-08-02
// Updated : 2007-08-02
// Licence : This source is under GNU LGPL licence
//////////////////////////////////////////////////////////////////////////////////

#ifndef __STUFF_SINGLETON_H__
#define __STUFF_SINGLETON_H__

#include <boost/noncopyable.hpp>
#include "async_ptr.hpp"

namespace stuff
{
    template <typename T> 
	class singleton : boost::noncopyable
    {
    public:
        // Get and/or create the singleton instance
        static T& get();
        // Delete singleton instance if it was created 
        static void release();
        // Test if singleton instance was created
        static bool empty();

    protected:
		virtual ~singleton();

	private:
		static T* instance;
    };
}

#include "singleton.inl"

#endif //__STUFF_SINGLETON_H__
