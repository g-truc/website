#include "../include/log_xml.h"

namespace eh
{
	// LoggerXML class definision
	LoggerXML::LoggerXML(const char* filename) :
		document(new TiXmlDocument("log")),
		filename(filename)
	{
		TiXmlDeclaration declaration;
		declaration.Parse( "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>", 0, TIXML_ENCODING_UNKNOWN);
		document->InsertEndChild(declaration);
		TiXmlElement element("log");
		document->InsertEndChild(element);
	}

	LoggerXML::~LoggerXML()
	{
		document->SaveFile(filename.c_str());
		delete document;
	}

	void LoggerXML::Flush()
	{
		document->SaveFile(filename.c_str());
	}

	void LoggerXML::NewObject(const char* type, size_t size, const char* filename, int line)
	{
		TiXmlElement element("memory");
		element.SetAttribute("operator", "new object");
		element.SetAttribute("filename", filename);
		element.SetAttribute("line", eh::format("%d", line).c_str());
		element.SetAttribute("type", type);
		element.SetAttribute("size", eh::format("%d", size).c_str());
		document->FirstChildElement()->InsertEndChild(element);

		//fprintf(file, "OBJECT ALLOCATED: %s, line %d: new object of %s, %d bytes\n", filename, line, type, size);
	}

	void LoggerXML::NewArray(const char* type, size_t size, const char* filename, int line)
	{
		TiXmlElement element("memory");
		element.SetAttribute("operator", "new array");
		element.SetAttribute("filename", filename);
		element.SetAttribute("line", eh::format("%d", line).c_str());
		element.SetAttribute("type", type);
		element.SetAttribute("size", eh::format("%d", size).c_str());
		document->FirstChildElement()->InsertEndChild(element);

		//fprintf(file, "ARRAY ALLOCATED: %s, line %d: new array of %s, %d bytes\n", filename, line, type, size);
	}

	void LoggerXML::DeleteObject(const char* object, const char* filename, int line)
	{
		TiXmlElement element("memory");
		element.SetAttribute("operator", "delete object");
		element.SetAttribute("filename", filename);
		element.SetAttribute("line", eh::format("%d", line).c_str());
		element.SetAttribute("object", object);
		document->FirstChildElement()->InsertEndChild(element);

		//fprintf(file, "OBJECT DELETED: %s, line %d: delete object from %s\n", filename, line, object);
	}

	void LoggerXML::DeleteArray(const char* array, const char* filename, int line)
	{
		TiXmlElement element("memory");
		element.SetAttribute("operator", "delete array");
		element.SetAttribute("filename", filename);
		element.SetAttribute("line", eh::format("%d", line).c_str());
		element.SetAttribute("array", array);
		document->FirstChildElement()->InsertEndChild(element);

		//fprintf(file, "ARRAY DELETED: %s, line %d: delete array from %s\n", filename, line, array);
	}

	void LoggerXML::Test(const char* expression, bool result, const char* message, const char* filename, int line)
	{
		TiXmlElement element("test");
		element.SetAttribute("expression", expression);
		element.SetAttribute("result", result ? "true" : "false");
		element.SetAttribute("message", message);
		element.SetAttribute("filename", filename);
		element.SetAttribute("line", eh::format("%d", line).c_str());
		document->FirstChildElement()->InsertEndChild(element);

		//fprintf(file, "TEST: %s, line %d: test of %s is %s\n", filename, line, expression, result ? "true" : "false");
	}

	void LoggerXML::Warning(const char* expression, const char* message, const char* filename, int line)
	{
		TiXmlElement element("caution");
		element.SetAttribute("expression", expression);
		element.SetAttribute("message", message);
		element.SetAttribute("filename", filename);
		element.SetAttribute("line", eh::format("%d", line).c_str());
		document->FirstChildElement()->InsertEndChild(element);

		//fprintf(file, "WARNING: %s, line %d: warning from %s: %s\n", filename, line, expression, message);
	}

	void LoggerXML::Error(const char* expression, const char* message, const char* filename, int line)
	{
		TiXmlElement element("error");
		element.SetAttribute("expression", expression);
		element.SetAttribute("message", message);
		element.SetAttribute("filename", filename);
		element.SetAttribute("line", eh::format("%d", line).c_str());
		document->FirstChildElement()->InsertEndChild(element);

		//fprintf(file, "ERROR: %s, line %d: error from %s: %s\n", filename, line, expression, message);
	}

	void LoggerXML::Message(const char* message, const char* filename, int line)
	{
		TiXmlElement element("message");
		element.SetAttribute("message", message);
		element.SetAttribute("filename", filename);
		element.SetAttribute("line", eh::format("%d", line).c_str());
		document->FirstChildElement()->InsertEndChild(element);

		//fprintf(file, "MESSAGE: %s, line %d: %s\n", filename, line, message);
	}
}
