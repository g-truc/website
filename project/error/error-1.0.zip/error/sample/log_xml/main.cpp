#include <error_xml.h>
#include <cstdlib>
#include <cstdio>

enum TrackedIndex
{
	CLASS1_INDEX, 
	CLASS2_INDEX 
};

class Class1 : public eh::Tracked<CLASS1_INDEX>
{
public:
	Class1() : integer(0) {message("Class1 Constructor");}
	~Class1(){message("Class1 Destructor");}

private:
	int integer;
};

class Class2 : public eh::Tracked<CLASS2_INDEX>
{
public:
	Class2() : integer(0) {message("Class2 Constructor");}
	~Class2(){message("Class2 Destructor");}

private:
	int integer;
};

void test_memory()
{
	message("===== test_memory =====");

	eh::Log* err = eh::Log::Instance();
	// Memory macros allow a global overview of memory leak and could answer to the question "Is there a memory leak in my program ?"
	message(eh::format("Allocated object: %d", err->GetUsageCount()).c_str());

	// Memory allocation for one object, like "new Class" in this sample
	Class1* Object = new_object(Class1);
	// Memory allocation for array, like "new Class[2]" in this sample
	Class1* Array = new_array(Class1, 2);

	// If you used this library, it's high recommended to never used new or delete operators in the full program. 
	// In release mode memory macro are replaced by usual memory operator, they haven't got any cost indend.

	message(eh::format("Allocated object: %d", err->GetUsageCount()).c_str());

	// Free memory for one object, like "delete Object" in this sample
	delete_object(Object);
	// Free memory for an array, like "delete[] Array" in this sample
	delete_array(Array);

	// Some information are available from the Log Class.
	// GetUsageCount : Return the number of variables in memory. This value should be null at the and of the program, otherwise the means that you have a memory leak
	// GetMemoryAllocated : Return the size of memory allocated since the beginning of the program
	// GetNewCount : Return the number of call of new_object and new_array
	// GetDeleteCount : Return the number of call of delete_object and delete_array
	// GetNewObjectCount : Return the number of call of new_object
	// GetNewArrayCount : Return the number of call of new_array
	// GetDeleteObjectCount : Return the number of call of delete_object
	// GetDeleteArrayCount : Return the number of call of delete_array
	message(eh::format("Allocated object: %d", err->GetUsageCount()).c_str());
}

void test_tracker()
{
	message("===== test_tracker =====");

	// Tracker provides more accurate mecanisum than memory macros for finding memory leak. 
	// However, it could be used only with specific classes, whose that inrehit from Tracked classes.
	// Three kide of information are available:
	// GetNewNumber : Return the number of instances of a specific class created since the beginning of the program
	// GetDeleteNumber : Return the number of instances of a specific class deleted since the beginning of the program
	// GetUsageNumber : Return the number of instances current in memory
	// Tracker is only available when NDEBUG isn't define
	// The tracker instance is automaticaly delete at the program exit.
	eh::Tracker* tracker = eh::Tracker::Instance();

	message(eh::format("TRACKER : Number of class1 instance: %d", tracker->GetUsageNumber(CLASS1_INDEX)).c_str());

	// Create 3 instances of Class1 using common memory operators. None if you use this library but you can.
	Class1* Object1 = new Class1;
	Class1* Array1 = new Class1[2];
	
	message(eh::format("TRACKER : Number of class1 instance: %d", tracker->GetUsageNumber(CLASS1_INDEX)).c_str());

	delete Object1;
	delete []Array1;

	message(eh::format("TRACKER : Number of class1 instance: %d", tracker->GetUsageNumber(CLASS1_INDEX)).c_str());

	message(eh::format("TRACKER : Number of class2 instance: %d", tracker->GetUsageNumber(CLASS2_INDEX)).c_str());

	// Create 3 instances of Class2 using memory macros. 
	Class2* Object2 = new_object(Class2);
	Class2* Array2 = new_array(Class2, 2);
	
	message(eh::format("TRACKER : Number of class2 instance: %d", tracker->GetUsageNumber(CLASS2_INDEX)).c_str());

	delete_object(Object2);
	delete_array(Array2);

	message(eh::format("TRACKER : Number of class2 instance: %d", tracker->GetUsageNumber(CLASS2_INDEX)).c_str());
}

void test_log()
{
	// message is use for custom user information.
	message("===== test_log =====");

	// test could be used everywhere in the program to test variables values.
	// At release mode test macro is skip.
	test((1 < 2), "1 < 2 ?");
	test((2 < 1), "2 < 1 ?");

	// warning macro should be used when a none critical issue occur 
	caution(false, "No warning, the program continue");
	caution(true, "A warning, the program continue");

	// error macro should be used to stop the program after a critical error.
	error(false, "No error, the program continue");
	error(true, "An error, the program stop");

	message("None logged");
}

int main()
{
	eh::Log* log = eh::Log::Instance();
	log->Register(eh::ALL, eh::LoggerXML::Create("./log.xml"));

	test_memory();
	test_tracker();
	test_log();

	eh::Log::Destroy();

	system("./log/build/build.bat");
	system("pause");

	return 0;
}
