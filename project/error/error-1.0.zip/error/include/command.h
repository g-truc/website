#ifndef __COMMAND_H__
#define __COMMAND_H__

#include "util.h"
#include "log_manager.h"

#define message(msg)														\
{																			\
	eh::Log::Instance()->Message(eh::MESSAGE, msg, __FILE__, __LINE__);	\
}

#ifdef NDEBUG
#define test(expression, message)	
#else
#define test(expression, message)																	\
{																									\
	eh::Log::Instance()->Test(eh::TEST, #expression, expression, message, __FILE__, __LINE__);	\
}

#endif

#define error(expression, message)															\
{																							\
	if(expression == true)																	\
	{																						\
		eh::Log::Instance()->Error(eh::ERROR, #expression, message, __FILE__, __LINE__);	\
		exit(1);																			\
	}																						\
}

#define caution(expression, message)															\
{																								\
	if(expression == true)																		\
	{																							\
		eh::Log::Instance()->Warning(eh::WARNING, #expression, message, __FILE__, __LINE__);	\
	}																							\
}

#endif//__COMMAND_H__
