#ifndef __LOG_XML_H__
#define __LOG_XML_H__

#include <xml/tinyxml.h>
#include "log_manager.h"

namespace eh
{
	class LoggerXML : public Logger
	{
		friend class Log;

	public:
		static LoggerXML* Create(const char* filename){return new LoggerXML(filename);}
		virtual void NewObject(const char* type, size_t size, const char* filename, int line);
		virtual void NewArray(const char* type, size_t size, const char* filename, int line);
		virtual void DeleteObject(const char* object, const char* filename, int line);
		virtual void DeleteArray(const char* array, const char* filename, int line);
		virtual void Test(const char* expression, bool result, const char* message, const char* filename, int line);
		virtual void Warning(const char* expression, const char* message, const char* filename, int line);
		virtual void Error(const char* expression, const char* message, const char* filename, int line);
		virtual void Message(const char* message, const char* filename, int line);
		virtual void Flush();

	private:
		LoggerXML(const char* filename);
		virtual ~LoggerXML();

		TiXmlDocument* document;
		std::string filename;
	};
}

#endif//__LOG_XML_H__
