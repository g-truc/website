#ifndef __ERROR_XML_H__
#define __ERROR_XML_H__

#include "log_manager.h"
#include "log_output.h"
#include "log_xml.h"
#include "memory.h"
#include "tracker.h"
#include "util.h"
#include "command.h"

#endif//__ERROR_XML_H__
