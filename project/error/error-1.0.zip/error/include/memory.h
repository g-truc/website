#ifndef __MEMORY_H__
#define __MEMORY_H__

#include "util.h"
#include "log_manager.h"

#ifdef NDEBUG

#define new_object(Type) new Type
#define new_array(Type, Size) new Type[Size]
#define delete_object(Object) delete Object
#define delete_array(Array)	delete[] Array

#else
namespace eh
{
	template <typename T>
	inline T* _new_object(const char* Type, const char* File, int Line)
	{
		Log::Instance()->NewObject(MEMORY, Type, sizeof(T), File, Line);
		return new T;	
	}

	template <typename T, int I>
	inline  T* _new_array(const char* Type, const char* File, int Line)
	{
		Log::Instance()->NewArray(MEMORY, Type, sizeof(T) * I, File, Line);
		return new T[I];	
	}
}

#define new_object(Type) eh::_new_object<Type>(#Type, __FILE__, __LINE__)

#define new_array(Type, Size) eh::_new_array<Type, Size>(#Type, __FILE__, __LINE__)

#define delete_object(Object)											\
{																		\
	eh::Log::Instance()->DeleteObject(eh::MEMORY, #Object, __FILE__, __LINE__);	\
	if(Object != null)													\
	{																	\
		delete Object;													\
		Object = null;													\
	}																	\
}										

#define delete_array(Array)												\
{																		\
	eh::Log::Instance()->DeleteArray(eh::MEMORY, #Array, __FILE__, __LINE__);	\
	if(Array != null)													\
	{																	\
		delete[] Array;													\
		Array = null;													\
	}																	\
}
#endif//NDEBUG

#endif//__MEMORY_H__
