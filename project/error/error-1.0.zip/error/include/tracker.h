#ifndef __TRACKER_H__
#define __TRACKER_H__

#include "tracker.h"
#include "util.h"
#include <vector>

namespace eh
{
	template <handle T> 
	class Tracked;

	class Tracker
	{
#ifdef VC60
		friend class Tracked;
#else
		template <handle T> 
		friend class Tracked;
#endif

	private:
		struct Count
		{
			Count();
			int created;
			int deleted;
		};

	public:
		static Tracker* Instance();
		static void Destroy();

		int GetNewNumber(handle Tracked);
		int GetDeleteNumber(handle Tracked);
		int GetUsageNumber(handle Tracked);

	private:
		Tracker(){}
		virtual ~Tracker(){}

		std::vector<Count> count;
		static Tracker* object;

#ifdef VC60
	public:
#endif 
		void AddConstruction(handle Tracked);
		void AddDestruction(handle Tracked);
	};

	template <handle T> 
	class Tracked
	{
	protected:
		Tracked();
		virtual ~Tracked();
		virtual handle GetIndex();
	};

	// Tracked
	template <handle T> 
	Tracked<T>::Tracked()
	{
#ifndef NDEBUG
		Tracker::Instance()->AddConstruction(T);
#endif//NDEBUG
	}

	template <handle T> 
	Tracked<T>::~Tracked()
	{
#ifndef NDEBUG
		Tracker::Instance()->AddDestruction(T);
#endif//NDEBUG
	}

	template <handle T> 
	handle Tracked<T>::GetIndex()
	{
		return T;
	}
}

#endif//__TRACKER_H__
