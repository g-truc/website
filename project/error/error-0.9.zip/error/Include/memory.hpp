#ifndef __MEMORY_HPP__
#define __MEMORY_HPP__

#include "util.hpp"
#include "log.hpp"

#ifdef NDEBUG

#define new_object(Type) new Type
#define new_array(Type, Size) new Type[Size]
#define delete_object(Object) delete Object
#define delete_array(Array)	delete[] Array

#else
namespace gte
{
	template <typename T>
	inline T* _new_object(const char* Type, const char* File, int Line)
	{
		Log::Instance()->NewObject(MEMORY, Type, sizeof(T), File, Line);
		return new T;	
	}

	template <typename T, int I>
	inline  T* _new_array(const char* Type, const char* File, int Line)
	{
		Log::Instance()->NewArray(MEMORY, Type, sizeof(T) * I, File, Line);
		return new T[I];	
	}
}

#define new_object(Type) gte::_new_object<Type>(#Type, __FILE__, __LINE__)

#define new_array(Type, Size) gte::_new_array<Type, Size>(#Type, __FILE__, __LINE__)

#define delete_object(Object)											\
{																		\
	gte::Log::Instance()->DeleteObject(gte::MEMORY, #Object, __FILE__, __LINE__);	\
	if(Object != null)													\
	{																	\
		delete Object;													\
		Object = null;													\
	}																	\
}										

#define delete_array(Array)												\
{																		\
	gte::Log::Instance()->DeleteArray(gte::MEMORY, #Array, __FILE__, __LINE__);	\
	if(Array != null)													\
	{																	\
		delete[] Array;													\
		Array = null;													\
	}																	\
}
#endif//NDEBUG

#endif//__MEMORY_HPP__
