#ifndef __ASSERT_HPP__
#define __ASSERT_HPP__

#include "util.hpp"
#include "log.hpp"

#define message(msg)														\
{																			\
	gte::Log::Instance()->Message(gte::MESSAGE, msg, __FILE__, __LINE__);	\
}

#ifdef NDEBUG
#define test(expression, message)	
#else
#define test(expression, message)																	\
{																									\
	gte::Log::Instance()->Test(gte::TEST, #expression, expression, message, __FILE__, __LINE__);	\
}

#endif

#define error(expression, message)															\
{																							\
	if(expression == true)																	\
	{																						\
		gte::Log::Instance()->Error(gte::ERROR, #expression, message, __FILE__, __LINE__);	\
		exit(1);																			\
	}																						\
}

#define warning(expression, message)															\
{																								\
	if(expression == true)																		\
	{																							\
		gte::Log::Instance()->Warning(gte::WARNING, #expression, message, __FILE__, __LINE__);	\
	}																							\
}

#endif//__ASSERT_HPP__
