#ifndef __UTIL_HPP__
#define __UTIL_HPP__

#include <string>

#define null 0
#define interface struct

typedef unsigned int handle;
typedef unsigned int flag;
#ifdef VC60
typedef __int64 uint64;
#else
typedef unsigned long long uint64;
#endif

namespace gte
{
	std::string format(const char* Msg, ...);
}

#endif//__UTIL_HPP__
