#ifndef __LOGGER_HPP__
#define __LOGGER_HPP__

#include "log.hpp"
#include <cstdio>

namespace gte
{
	class LoggerDebug : public Logger
	{
		friend class Log;

	public:
		static LoggerDebug* Create(){return new LoggerDebug();}
		virtual void NewObject(const char* type, size_t size, const char* file, int line);
		virtual void NewArray(const char* type, size_t size, const char* File, int line);
		virtual void DeleteObject(const char* object, const char* file, int line);
		virtual void DeleteArray(const char* array, const char* file, int line);
		virtual void Test(const char* expression, bool result, const char* message, const char* file, int line);
		virtual void Warning(const char* expression, const char* message, const char* file, int line);
		virtual void Error(const char* expression, const char* message, const char* file, int line);
		virtual void Message(const char* message, const char* filename, int line);

	private:
		LoggerDebug(){}
		virtual ~LoggerDebug(){}
	};

	class LoggerMessageBox : public Logger
	{
		friend class Log;

	public:
		static LoggerMessageBox* Create(){return new LoggerMessageBox();}
		virtual void NewObject(const char* type, size_t size, const char* file, int line);
		virtual void NewArray(const char* type, size_t size, const char* File, int line);
		virtual void DeleteObject(const char* object, const char* file, int line);
		virtual void DeleteArray(const char* array, const char* file, int line);
		virtual void Test(const char* expression, bool result, const char* message, const char* file, int line);
		virtual void Warning(const char* expression, const char* message, const char* file, int line);
		virtual void Error(const char* expression, const char* message, const char* file, int line);
		virtual void Message(const char* message, const char* filename, int line);

	private:
		LoggerMessageBox(){}
		virtual ~LoggerMessageBox(){}
	};

	class LoggerText : public Logger
	{
		friend class Log;

	public:
		static LoggerText* Create(const char* Filename){return new LoggerText(Filename);}
		virtual void NewObject(const char* type, size_t size, const char* filename, int line);
		virtual void NewArray(const char* type, size_t size, const char* filename, int line);
		virtual void DeleteObject(const char* object, const char* filename, int line);
		virtual void DeleteArray(const char* array, const char* filename, int line);
		virtual void Test(const char* expression, bool result, const char* message, const char* filename, int line);
		virtual void Warning(const char* expression, const char* message, const char* filename, int line);
		virtual void Error(const char* expression, const char* message, const char* filename, int line);
		virtual void Message(const char* message, const char* filename, int line);
		virtual void Flush();

	private:
		LoggerText(const char* Filename);
		virtual ~LoggerText();

		FILE* file;
	};

	class LoggerFlux : public Logger
	{
		friend class Log;

	public:
		static LoggerFlux* Create(FILE* flux){return new LoggerFlux(flux);}
		virtual void NewObject(const char* type, size_t size, const char* filename, int line);
		virtual void NewArray(const char* type, size_t size, const char* filename, int line);
		virtual void DeleteObject(const char* object, const char* filename, int line);
		virtual void DeleteArray(const char* array, const char* filename, int line);
		virtual void Test(const char* expression, bool result, const char* message, const char* filename, int line);
		virtual void Warning(const char* expression, const char* message, const char* filename, int line);
		virtual void Error(const char* expression, const char* message, const char* filename, int line);
		virtual void Message(const char* message, const char* filename, int line);

	private:
		LoggerFlux(FILE* flux);
		virtual ~LoggerFlux();

		FILE* flux;
	};
}

#endif//__LOGGER_HPP__
