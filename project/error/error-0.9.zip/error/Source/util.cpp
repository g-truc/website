#include "../include/util.hpp"
#include <cstdarg>

namespace gte
{
	std::string format(const char* Msg, ...)
	{
		char Text[4096];
		va_list List;

		if(Msg == null)
			return std::string();

		va_start(List, Msg);
			vsprintf(Text, Msg, List);
		va_end(List);

		return std::string(Text);
	}
}
