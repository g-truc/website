#include "../include/logger.hpp"
#ifdef WIN32
#include <windows.h>
#endif
#include <string>

namespace gte
{
	// LoggerDebug
	void LoggerDebug::NewObject(const char* type, size_t size, const char* file, int line)
	{
		OutputDebugString(gte::format("%s, line %d: new object of %s, %d bytes\n", file, line, type, size).c_str());
	}

	void LoggerDebug::NewArray(const char* type, size_t size, const char* file, int line)
	{
		OutputDebugString(gte::format("%s, line %d: new array of %s, %d bytes\n", file, line, type, size).c_str());
	}

	void LoggerDebug::DeleteObject(const char* object, const char* file, int line)
	{
		OutputDebugString(gte::format("%s, line %d: delete object from %s\n", file, line, object).c_str());
	}

	void LoggerDebug::DeleteArray(const char* array, const char* file, int line)
	{
		OutputDebugString(gte::format("%s, line %d: delete array from %s\n", file, line, array).c_str());
	}

	void LoggerDebug::Test(const char* expression, bool result, const char* message, const char* file, int line)
	{
		OutputDebugString(gte::format("%s, line %d: test of %s is %s\n", file, line, expression, result ? "true" : "false").c_str());
	}

	void LoggerDebug::Warning(const char* expression, const char* message, const char* file, int line)
	{
		OutputDebugString(gte::format("%s, line %d: warning from %s: %s\n", file, line, expression, message).c_str());
	}

	void LoggerDebug::Error(const char* expression, const char* message, const char* file, int line)
	{
		OutputDebugString(gte::format("%s, line %d: error from %s: %s\n", file, line, expression, message).c_str());
	}

	void LoggerDebug::Message(const char* message, const char* filename, int line)
	{
		OutputDebugString(gte::format("%s, line %d: %s\n", filename, line, message).c_str());
	}

	// LoggerMessageBox
	void LoggerMessageBox::NewObject(const char* type, size_t size, const char* filename, int line)
	{
		MessageBox(NULL, gte::format("%s, line %d: new object of %s, %d bytes\n", filename, line, type, size).c_str(), "New Object", MB_OK);
	}

	void LoggerMessageBox::NewArray(const char* type, size_t size, const char* file, int line)
	{
		MessageBox(NULL, gte::format("%s, line %d: new array of %s, %d bytes\n", file, line, type, size).c_str(), "New Array", MB_OK);
	}

	void LoggerMessageBox::DeleteObject(const char* object, const char* file, int line)
	{
		MessageBox(NULL, gte::format("%s, line %d: delete object from %s\n", file, line, object).c_str(), "Delete Object", MB_OK);
	}

	void LoggerMessageBox::DeleteArray(const char* array, const char* file, int line)
	{
		MessageBox(NULL, gte::format("%s, line %d: delete array from %s\n", file, line, array).c_str(), "Delete Array", MB_OK);
	}

	void LoggerMessageBox::Test(const char* expression, bool result, const char* message, const char* file, int line)
	{
		MessageBox(NULL, gte::format("%s, line %d: test of %s is %s\n", file, line, expression, result ? "true" : "false").c_str(), "Test", MB_OK);
	}

	void LoggerMessageBox::Warning(const char* expression, const char* message, const char* file, int line)
	{
		MessageBox(NULL, gte::format("%s, line %d: warning from %s: %s\n", file, line, expression, message).c_str(), "Test", MB_OK);
	}

	void LoggerMessageBox::Error(const char* expression, const char* message, const char* file, int line)
	{
		MessageBox(NULL, gte::format("%s, line %d: error from %s: %s\n", file, line, expression, message).c_str(), "Test", MB_OK);
	}

	void LoggerMessageBox::Message(const char* message, const char* filename, int line)
	{
		MessageBox(NULL, gte::format("%s, line %d: %s\n", filename, line, message).c_str(), "Message", MB_OK);
	}

	// LoggerText
	LoggerText::LoggerText(const char* Filename)
	{
		file = fopen(Filename, "w");
	}

	LoggerText::~LoggerText()
	{
		fclose(file);
	}

	void LoggerText::Flush()
	{
		fflush(file);
	}

	void LoggerText::NewObject(const char* type, size_t size, const char* filename, int line)
	{
		fprintf(file, "OBJECT ALLOCATED: %s, line %d: new object of %s, %d bytes\n", filename, line, type, size);
	}

	void LoggerText::NewArray(const char* type, size_t size, const char* filename, int line)
	{
		fprintf(file, "ARRAY ALLOCATED: %s, line %d: new array of %s, %d bytes\n", filename, line, type, size);
	}

	void LoggerText::DeleteObject(const char* object, const char* filename, int line)
	{
		fprintf(file, "OBJECT DELETED: %s, line %d: delete object from %s\n", filename, line, object);
	}

	void LoggerText::DeleteArray(const char* array, const char* filename, int line)
	{
		fprintf(file, "ARRAY DELETED: %s, line %d: delete array from %s\n", filename, line, array);
	}

	void LoggerText::Test(const char* expression, bool result, const char* message, const char* filename, int line)
	{
		fprintf(file, "TEST: %s, line %d: test of %s is %s\n", filename, line, expression, result ? "true" : "false");
	}

	void LoggerText::Warning(const char* expression, const char* message, const char* filename, int line)
	{
		fprintf(file, "WARNING: %s, line %d: warning from %s: %s\n", filename, line, expression, message);
	}

	void LoggerText::Error(const char* expression, const char* message, const char* filename, int line)
	{
		fprintf(file, "ERROR: %s, line %d: error from %s: %s\n", filename, line, expression, message);
	}

	void LoggerText::Message(const char* message, const char* filename, int line)
	{
		fprintf(file, "MESSAGE: %s, line %d: %s\n", filename, line, message);
	}

	// LoggerFlux
	LoggerFlux::LoggerFlux(FILE* flux) :
		flux(flux)
	{}

	LoggerFlux::~LoggerFlux()
	{}

	void LoggerFlux::NewObject(const char* type, size_t size, const char* filename, int line)
	{
		fprintf(flux, "OBJECT ALLOCATED: %s, line %d: new object of %s, %d bytes\n", filename, line, type, size);
	}

	void LoggerFlux::NewArray(const char* type, size_t size, const char* filename, int line)
	{
		fprintf(flux, "ARRAY ALLOCATED: %s, line %d: new array of %s, %d bytes\n", filename, line, type, size);
	}

	void LoggerFlux::DeleteObject(const char* object, const char* filename, int line)
	{
		fprintf(flux, "OBJECT DELETED: %s, line %d: delete object from %s\n", filename, line, object);
	}

	void LoggerFlux::DeleteArray(const char* array, const char* filename, int line)
	{
		fprintf(flux, "ARRAY DELETED: %s, line %d: delete array from %s\n", filename, line, array);
	}

	void LoggerFlux::Test(const char* expression, bool result, const char* message, const char* filename, int line)
	{
		fprintf(flux, "TEST: %s, line %d: test of %s is %s\n", filename, line, expression, result ? "true" : "false");
	}

	void LoggerFlux::Warning(const char* expression, const char* message, const char* filename, int line)
	{
		fprintf(flux, "WARNING: %s, line %d: warning from %s: %s\n", filename, line, expression, message);
	}

	void LoggerFlux::Error(const char* expression, const char* message, const char* filename, int line)
	{
		fprintf(flux, "ERROR: %s, line %d: error from %s: %s\n", filename, line, expression, message);
	}

	void LoggerFlux::Message(const char* message, const char* filename, int line)
	{
		fprintf(flux, "MESSAGE: %s, line %d: %s\n", filename, line, message);
	}
}
