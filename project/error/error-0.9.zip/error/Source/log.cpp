#include "../include/log.hpp"

namespace gte
{
	void LogDelete()
	{
		Log::Destroy();
	}

	Log* Log::object = null;

	Log* Log::Instance()
	{
		if(object == null)
		{
			object = new Log();
			atexit(LogDelete);
		}
		return object;
	}

	void Log::Destroy()
	{
		if(object != null)
		{
			delete object;
			object = null;
		}
	}

	Log::Log() :
		memoryAllocated(0),
		newObjectCount(0),
		deleteObjectCount(0),
		newArrayCount(0),
		deleteArrayCount(0)
	{}

	Log::~Log()
	{
		for(std::multimap<handle, Logger*>::iterator it = loggerMap.begin(); it != loggerMap.end(); ++it)
		{
			it->second->Flush();
			delete it->second;
		}
	}

	void Log::Register(handle target, Logger* logger)
	{
		loggerMap.insert(std::make_pair(target, logger));
	}

	void Log::Flush()
	{
		for(std::multimap<handle, Logger*>::iterator it = loggerMap.begin(); it != loggerMap.end(); ++it)
			it->second->Flush();
	}

	void Log::NewObject(flag target, const char* type, size_t size, const char* file, int line)
	{
		newObjectCount++;
		memoryAllocated += size;
		for(std::multimap<handle, Logger*>::iterator it = loggerMap.begin(); it != loggerMap.end(); ++it)
			if(it->first & target)
				it->second->NewObject(type, size, file, line);
	}

	void Log::NewArray(flag target, const char* type, size_t size, const char* file, int line)
	{
		newArrayCount++;
		memoryAllocated += size;
		for(std::multimap<handle, Logger*>::iterator it = loggerMap.begin(); it != loggerMap.end(); ++it)
			if(it->first & target)
				it->second->NewArray(type, size, file, line);
	}

	void Log::DeleteObject(flag target, const char* object, const char* file, int line)
	{
		deleteObjectCount++;
		for(std::multimap<handle, Logger*>::iterator it = loggerMap.begin(); it != loggerMap.end(); ++it)
			if(it->first & target)
				it->second->DeleteObject(object, file, line);
	}

	void Log::DeleteArray(flag target, const char* array, const char* file, int line)
	{
		deleteArrayCount++;
		for(std::multimap<handle, Logger*>::iterator it = loggerMap.begin(); it != loggerMap.end(); ++it)
			if(it->first & target)
				it->second->DeleteArray(array, file, line);
	}

	void Log::Test(flag target, const char* expression, bool result, const char* message, const char* file, int line)
	{
		for(std::multimap<handle, Logger*>::iterator it = loggerMap.begin(); it != loggerMap.end(); ++it)
			if(it->first & target)
				it->second->Test(expression, result, message, file, line);
	}

	void Log::Warning(flag target, const char* expression, const char* message, const char* file, int line)
	{
		for(std::multimap<handle, Logger*>::iterator it = loggerMap.begin(); it != loggerMap.end(); ++it)
			if(it->first & target)
				it->second->Warning(expression, message, file, line);
	}

	void Log::Error(flag target, const char* expression, const char* message, const char* filename, int line)
	{
		for(std::multimap<handle, Logger*>::iterator it = loggerMap.begin(); it != loggerMap.end(); ++it)
			if(it->first & target)
				it->second->Error(expression, message, filename, line);
	}

	void Log::Message(flag target, const char* message, const char* filename, int line)
	{
		//for(std::multimap<handle, Logger*>::iterator it = loggerMap.lower_bound(target); it != loggerMap.upper_bound(target); ++it)
		for(std::multimap<handle, Logger*>::iterator it = loggerMap.begin(); it != loggerMap.end(); ++it)
			if(it->first & target)
				it->second->Message(message, filename, line);
	}
}
