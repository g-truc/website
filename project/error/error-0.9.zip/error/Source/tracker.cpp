#include "../include/tracker.hpp"

namespace gte
{
	// Tracker
	Tracker::Count::Count() :
		created(0),
		deleted(0)
	{}

	void TrackerDelete()
	{
		Tracker::Destroy();
	}

	Tracker* Tracker::object = null;

	Tracker* Tracker::Instance()
	{
		if(object == null)
		{
			object = new Tracker();
			atexit(TrackerDelete);
		}
		return object;
	}

	void Tracker::Destroy()
	{
		if(object != null)
		{
			delete object;
			object = null;
		}
	}

	int Tracker::GetNewNumber(handle Tracked)
	{
		if(Tracked >= count.size())
			count.resize(Tracked + 1);
		return count[Tracked].created;
	}

	int Tracker::GetDeleteNumber(handle Tracked)
	{
		if(Tracked >= count.size())
			count.resize(Tracked + 1);
		return count[Tracked].deleted;
	}

	int Tracker::GetUsageNumber(handle Tracked)
	{
		if(Tracked >= count.size())
			count.resize(Tracked + 1);
		return count[Tracked].created - count[Tracked].deleted;;
	}

	void Tracker::AddConstruction(handle Tracked)
	{
		if(Tracked >= count.size())
			count.resize(Tracked + 1);
		++count[Tracked].created;
	}

	void Tracker::AddDestruction(handle Tracked)
	{
		if(Tracked >= count.size())
			count.resize(Tracked + 1);
		++count[Tracked].deleted;
	}
}
