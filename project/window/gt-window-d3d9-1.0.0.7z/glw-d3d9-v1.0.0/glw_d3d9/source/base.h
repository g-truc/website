/*
    GL Window: Direct3D 9 Edition
    Copyright (C) 2006 G-Truc Creation (www.g-truc.net)

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the Free
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Christophe [Groove] Riccio
    contact@g-truc.net
*/

#ifndef __BASE_H__
#define __BASE_H__

#include "../include/glw_d3d9.h"
#include "timer.h"
#include "singleton.h"

namespace glw
{
    class CWindowD3D : public glw::singleton<CWindowD3D>
    {
        friend class glw::singleton<CWindowD3D>;

    public:
        virtual void init(const Setting& Setting, HWND Window);
        virtual void swap();
        LPDIRECT3DDEVICE9 device() const;

    private:
        CWindowD3D();
        //CWindowD3D(const Setting& Setting);
        virtual ~CWindowD3D();

        D3DFORMAT _getDepthSentil(const Setting& Setting);

        LPDIRECT3D9 m_pD3d;
        LPDIRECT3DDEVICE9 m_pD3dDevice;
    };

    class base : public glw::singleton<base>
    {
        friend class glw::singleton<base>;

    public:
        base();
        ~base();

        void create(const Setting& Setting);
        double time();
        int width() const {return m_Width;}
        int height() const {return m_Height;}

    private:
        void _createWindow(const Setting& Setting);
        void _initScreen(const Setting& Setting);

        glw::timer* m_Timer;
        HINSTANCE m_Instance;
        std::string m_Name;
        WNDCLASSEX m_WinClass;
        HWND m_Window;
        int m_Width;
        int m_Height;

    private:
        base(const base& Window);
        base& operator=(const base& Window);
    };
}

#endif
