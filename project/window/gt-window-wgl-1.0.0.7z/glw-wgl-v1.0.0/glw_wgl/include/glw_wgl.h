/*
    GL Window: WGL Edition
    Copyright (C) 2006 G-Truc Creation (www.g-truc.net)

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the Free
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Christophe [Groove] Riccio
    contact@g-truc.net
*/

#ifndef __GLW_WGL_H__
#define __GLW_WGL_H__

#define GLW_WGL_VERSION 10

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif 

//! For mouse wheel
#define _WIN32_WINNT 0x0400

//! GLW use GLEW to OpenGL extensions loading. Each project witch uses GLW need to link with glew32s.lib.
#define GLEW_STATIC

#include <windows.h>
#include <GL/glew.h>
#include <GL/wglew.h>
#include <string>

#ifndef null
#define null 0
#endif

#define main glw_main

namespace glw
{
    //! Enumeration to report of mouse buttons used
    enum Button
    {
        BUTTON_NONE,                                //!< No button haven't pressed yet
        BUTTON_LEFT             = VK_LBUTTON,       //!< Left button of the mouse have been pressed
        BUTTON_RIGHT            = VK_RBUTTON,       //!< Right button of the mouse have been pressed
        BUTTON_MIDDLE           = VK_MBUTTON,       //!< Middle button of the mouse have been pressed
    	BUTTON_ROLL_UP,                             //!< Mouse wheel have been use in the up direction. This is only available with BUTTON_DOWN event
    	BUTTON_ROLL_DOWN                            //!< Mouse wheel have been use in the down direction. This is only available with BUTTON_DOWN event
    };

    //! Enumeration to report of key used
    enum Key
    {
        KEY_NONE,                           //!< No key have been pressed yet
        KEY_BACKSPACE           = VK_BACK,
        KEY_TAB                 = VK_TAB,
        KEY_ENTER               = VK_RETURN,
        KEY_SHIFT               = VK_SHIFT,
        KEY_SHIFT_LEFT          = VK_LSHIFT,
        KEY_SHIFT_RIGHT         = VK_RSHIFT,
        KEY_CTRL_LEFT           = VK_LCONTROL,
        KEY_CTRL_RIGHT          = VK_RCONTROL,
        KEY_ALT_LEFT            = VK_LMENU,
        KEY_ALT_RIGHT           = VK_RMENU,
        KEY_PAUSE               = VK_PAUSE,
        KEY_CAPS_LOCK           = VK_CAPITAL,
        KEY_ESC                 = VK_ESCAPE,
        KEY_SPACE               = VK_SPACE,
        KEY_PAGE_UP             = VK_PRIOR,
        KEY_PAGE_DOWN           = VK_NEXT,
        KEY_END                 = VK_END,
        KEY_HOME                = VK_HOME,
        KEY_LEFT                = VK_LEFT,
        KEY_UP                  = VK_UP,
        KEY_RIGHT               = VK_RIGHT,
        KEY_DOWN                = VK_DOWN,
        KEY_SELECT              = VK_SELECT,
        KEY_EXEC                = VK_EXECUTE,
        KEY_SNAPSHOT            = VK_SNAPSHOT,
        KEY_INS                 = VK_INSERT,
        KEY_DEL                 = VK_DELETE,
        KEY_0                   = 0x0030,
        KEY_1                   = 0x0031,
        KEY_2                   = 0x0032,
        KEY_3                   = 0x0033,
        KEY_4                   = 0x0034,
        KEY_5                   = 0x0035,
        KEY_6                   = 0x0036,
        KEY_7                   = 0x0037,
        KEY_8                   = 0x0038,
        KEY_9                   = 0x0039,
        KEY_A                   = 0x0041,
        KEY_B                   = 0x0042,
        KEY_C                   = 0x0043,
        KEY_D                   = 0x0044,
        KEY_E                   = 0x0045,
        KEY_F                   = 0x0046,
        KEY_G                   = 0x0047,
        KEY_H                   = 0x0048,
        KEY_I                   = 0x0049,
        KEY_J                   = 0x004A,
        KEY_K                   = 0x004B,
        KEY_L                   = 0x004C,
        KEY_M                   = 0x004D,
        KEY_N                   = 0x004E,
        KEY_O                   = 0x004F,
        KEY_P                   = 0x0050,
        KEY_Q                   = 0x0051,
        KEY_R                   = 0x0052,
        KEY_S                   = 0x0053,
        KEY_T                   = 0x0054,
        KEY_U                   = 0x0055,
        KEY_V                   = 0x0056,
        KEY_W                   = 0x0057,
        KEY_X                   = 0x0058,
        KEY_Y                   = 0x0059,
        KEY_Z                   = 0x005A,
        KEY_WIN_LEFT            = VK_LWIN,
        KEY_WIN_RIGHT           = VK_RWIN,
        KEY_WIN_APPS            = VK_APPS,
        KEY_NUMPAD_0            = VK_NUMPAD0,
        KEY_NUMPAD_1            = VK_NUMPAD1,
        KEY_NUMPAD_2            = VK_NUMPAD2,
        KEY_NUMPAD_3            = VK_NUMPAD3,
        KEY_NUMPAD_4            = VK_NUMPAD4,
        KEY_NUMPAD_5            = VK_NUMPAD5,
        KEY_NUMPAD_6            = VK_NUMPAD6,
        KEY_NUMPAD_7            = VK_NUMPAD7,
        KEY_NUMPAD_8            = VK_NUMPAD8,
        KEY_NUMPAD_9            = VK_NUMPAD9,
        KEY_NUMPAD_MUL          = VK_MULTIPLY,
        KEY_NUMPAD_ADD          = VK_ADD,
        KEY_NUMPAD_SEPARATOR    = VK_SEPARATOR,
        KEY_NUMPAD_SUB          = VK_SUBTRACT,
        KEY_NUMPAD_DECIMAL      = VK_DECIMAL,
        KEY_NUMPAD_DIVIDE       = VK_DIVIDE,
        KEY_F1                  = VK_F1,
        KEY_F2                  = VK_F2,
        KEY_F3                  = VK_F3,
        KEY_F4                  = VK_F4,
        KEY_F5                  = VK_F5,
        KEY_F6                  = VK_F6,
        KEY_F7                  = VK_F7,
        KEY_F8                  = VK_F8,
        KEY_F9                  = VK_F9,
        KEY_F10                 = VK_F10,
        KEY_F11                 = VK_F11,
        KEY_F12                 = VK_F12,
        KEY_F13                 = VK_F13,
        KEY_F14                 = VK_F14,
        KEY_F15                 = VK_F15,
        KEY_F16                 = VK_F16,
        KEY_F17                 = VK_F17,
        KEY_F18                 = VK_F18,
        KEY_F19                 = VK_F19,
        KEY_F20                 = VK_F20,
        KEY_F21                 = VK_F21,
        KEY_F22                 = VK_F22,
        KEY_F23                 = VK_F23,
        KEY_F24                 = VK_F24,
        KEY_NUM_LOCK            = VK_NUMLOCK,
        KEY_SCROLL              = VK_SCROLL
    };

    //! Enumeration of report events
    enum Event
    {
        EVENT_NONE      = 0,            //! No event happen
        KEY_PRESS       = (1 << 0),     //! A key has been press
        KEY_RELEASE     = (1 << 1),     //! A key has been release
        BUTTON_PRESS    = (1 << 2),     //! A mouse button has been press
        BUTTON_RELEASE  = (1 << 3),     //! A mouse button has been release
        MOTION          = (1 << 4),     //! The mouse cursor has moved
        RESIZE          = (1 << 5),     //! The Window has changed its size.
        QUIT            = (1 << 6)      //! A quit message have been send by software. It should the result of a click on the cross button
    };

    //! Enumeration of vsync option
    enum VSync
    {
        VSYNC_DEFAULT = -1, // wgl_swap_control say the default value is 1
        VSYNC_DISABLE = 0
    };

    enum Target
    {
        TARGET_FRAMEBUFFER,
        TARGET_PBUFFER0,
        TARGET_PBUFFER1,
        TARGET_PBUFFER2,
        TARGET_PBUFFER3
    };

    //! Window configuration class
    class Setting
    {
    public:
        Setting();

        const char* name() const;                   //!< Name of the program instance
        const char* title() const;                  //!< Title of the Window
        unsigned short width() const;               //!< Width of the Window
        unsigned short height() const;              //!< Height of the Window
        //short vsync() const;                        //!< Vertical synchronization frequency. If the value is 0 then VSync is disabled
        bool fullscreen() const;                    //!< Create a Window in fullscreen mode
        //bool doubleBuffer() const;                  //!< Use double buffering to real time rendering
        unsigned char colorBuffer() const;          //!< Size in bits to the color component of a framebuffer pixel
        unsigned char depthBuffer() const;          //!< Size in bits to the depth component of a framebuffer pixel
        unsigned char stencilBuffer() const;        //!< Size in bits to the stencil component of a framebuffer pixel
        //unsigned char sampleBuffer() const;         //!< Level of multisampling
        bool cursor() const;                        //!< Show the mouse cursor
        short icon() const;                         //!< Value of the icon resource identifier (Win32 only)

        void name(const char* value);               //!< Name of the program instance
        void title(const char* value);              //!< Title of the Window
        void width(unsigned short value);           //!< Width of the Window
        void height(unsigned short value);          //!< Height of the Window
        //void vsync(short value);                    //!< Vertical synchronization frequency. If the value is 0 then VSync is disabled
        void fullscreen(bool value);                //!< Create a Window in fullscreen mode
        //void doubleBuffer(bool value);              //!< Use double buffering to real time rendering
        void colorBuffer(unsigned char value);      //!< Size in bits to the color component of a framebuffer pixel
        void depthBuffer(unsigned char value);      //!< Size in bits to the depth component of a framebuffer pixel
        void stencilBuffer(unsigned char value);    //!< Size in bits to the stencil component of a framebuffer pixel
        //void sampleBuffer(unsigned char value);     //!< Level of multisampling
        void cursor(bool value);                    //!< Show the mouse cursor
        void icon(short value);                     //!< Value of the icon resource identifier (Win32 only)

    private:
        std::string m_Name;
        std::string m_Title;
        unsigned short m_Width;
        unsigned short m_Height;
        short m_VSync;
        bool m_Fullscreen;
        bool m_DoubleBuffer;
        unsigned char m_Color;
        unsigned char m_Depth;
        unsigned char m_Stencil;
        unsigned char m_Samples;
        bool m_Cursor;
        short m_Icon;
    };

    //! Window object, it is managed rendering, events and time
    class Window
    {
    public:
        Window(const Setting& Setting);             //!< Only one Window should be created
        ~Window();

        // PBuffers aren't available
        //void activate(target Target);
        //void enable(target Target);
        //void disable();
        void swap();                                //!< Swap framebuffer

        bool poll();                                //!< Inquire that a event has been invoke
        glw::Event event() const;                        //!< Give the type of the current event

        glw::Key key();                                  //!< Return the last key press or release
        glw::Button button();                            //!< Return the last mouse button press or release
        void resize(int& x, int& y);                //!< Return the new size of the Window after a resize event
        void motion(int& x, int& y);                //!< Return mouse position

        double time();                              //!< Return the current time

        unsigned int width() const;                 //!< Return the Window width
        unsigned int height() const;                //!< Return the Window height

    private:
        Window(const Window& Window);               //!< Copy constructions are not allow
        Window& operator=(const Window& Window);    //!< Copy constructions are not allow
    };
}

#endif//__GLW_WGL_H__
