/*
    GL Window: WGL Edition
    Copyright (C) 2006 G-Truc Creation (www.g-truc.net)

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the Free
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Christophe [Groove] Riccio
    contact@g-truc.net
*/

#include "../include/glw_wgl.h"
#include <malloc.h>
#include <shellapi.h>
#include <cstdio>

int glw_main(int argc, char* argv[]);

// From SDL (www.libsdl.org)
int ParseCommandLine(char *cmdline, char **argv)
{
	int argc = 0;
	for(char* bufp = cmdline; *bufp; )
    {
		while(isspace(*bufp))
			++bufp;

        if(*bufp == '"')
        {
			++bufp;
			if(*bufp)
            {
				if(argv)
					argv[argc] = bufp;
				++argc;
			}
			while(*bufp && (*bufp != '"'))
				++bufp;
		}
        else
        {
			if(*bufp)
            {
				if(argv)
					argv[argc] = bufp;
				++argc;
			}
			while(*bufp && ! isspace(*bufp))
				++bufp;
		}
		if(*bufp)
        {
			if(argv)
				*bufp = '\0';
			++bufp;
		}
	}

	if(argv)
		argv[argc] = NULL;
	return argc;
}

void Log()
{
    freopen("stdout.txt", "w", stdout);
    freopen("stderr.txt", "w", stderr);
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int iCmdShow)
{
    Log();

	char* bufp = GetCommandLine();
	char* cmdline = (char*)alloca(strlen(bufp) + 1);
	if(cmdline == NULL)
        return 1;
	strcpy(cmdline, bufp);

	int argc = ParseCommandLine(cmdline, NULL);
	char** argv = (char**)alloca((argc + 1)*(sizeof *argv));
	if(argv == NULL)
		return 1;
	ParseCommandLine(cmdline, argv);

    int iErrorCode = glw_main(argc, argv);

    fclose(stdout);
    fclose(stderr);

    return iErrorCode;
}
