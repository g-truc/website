/*
    GL Window: WGL Edition
    Copyright (C) 2006 G-Truc Creation (www.g-truc.net)

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the Free
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Christophe [Groove] Riccio
    contact@g-truc.net
*/

#include "poll.h"
#include <cassert>

using namespace glw;

pollWin32::pollWin32() : 
    m_pFirstEvent(NULL),
    m_bEmpty(true)
{
    memset(&m_uMsg, 0, sizeof(m_uMsg));
}

pollWin32::~pollWin32()
{
    _clear();
}

Event pollWin32::event() const
{
    return m_pFirstEvent ? m_pFirstEvent->type() : EVENT_NONE;
}

bool pollWin32::poll()
{
    if(m_bEmpty && !m_pFirstEvent)
    {
        _update();
        m_bEmpty = false;
        return true;
    }

    if(!m_bEmpty && !m_pFirstEvent)
    {
        m_bEmpty = true;
        return false;
    }

    eventInterface* pTmp = m_pFirstEvent->m_pNext;
    delete m_pFirstEvent;
    m_pFirstEvent = pTmp;

    return !m_bEmpty;
}

Key pollWin32::key() const
{
    if(m_pFirstEvent->type() & KEY_PRESS)
        return static_cast<eventKeyDown*>(m_pFirstEvent)->value();
    else if(m_pFirstEvent->type() & KEY_RELEASE)
        return static_cast<eventKeyUp*>(m_pFirstEvent)->value();
    else assert(0);
    return KEY_NONE;
}

Button pollWin32::button() const
{
    if(m_pFirstEvent->type() & BUTTON_PRESS)
        return static_cast<eventMouseButtonDown*>(m_pFirstEvent)->value();
    else if(m_pFirstEvent->type() & BUTTON_RELEASE)
        return static_cast<eventMouseButtonUp*>(m_pFirstEvent)->value();
    else assert(0);
    return BUTTON_NONE;
}

void pollWin32::resize(int& x, int& y) const
{
    if(m_pFirstEvent->type() & RESIZE)
        static_cast<eventResize*>(m_pFirstEvent)->value(x, y);
    else assert(0);

}

void pollWin32::motion(int& x, int& y) const
{
    if(m_pFirstEvent->type() & MOTION)
        static_cast<eventMousePosition*>(m_pFirstEvent)->value(x, y);
    else assert(0);
}

void pollWin32::push(eventInterface* pEvent)
{
    pEvent->m_pNext = m_pFirstEvent;
    m_pFirstEvent = pEvent;
}

void pollWin32::_update()
{
	if(PeekMessage(&m_uMsg, NULL, 0, 0, PM_REMOVE))
	{
		TranslateMessage(&m_uMsg);
		DispatchMessage(&m_uMsg);
	}
}

void pollWin32::_clear()
{
    while(m_pFirstEvent)
    {
        eventInterface* pTmp = m_pFirstEvent->m_pNext;
        delete m_pFirstEvent;
        m_pFirstEvent = pTmp;
    }
	m_bEmpty = true;
}

LRESULT CALLBACK WindowProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    pollWin32* pPoll = pollWin32::instance();
	switch(msg)
	{
		case WM_KEYDOWN:
            pPoll->push(new eventKeyDown(Key(wParam)));
            break;
		case WM_KEYUP:
            pPoll->push(new eventKeyUp(Key(wParam)));
            break;
        case WM_LBUTTONDOWN:
            pPoll->push(new eventMouseButtonDown(BUTTON_LEFT));
            break;
        case WM_LBUTTONUP:
            pPoll->push(new eventMouseButtonUp(BUTTON_LEFT));
            break;
        case WM_RBUTTONDOWN:
            pPoll->push(new eventMouseButtonDown(BUTTON_RIGHT));
            break;
        case WM_RBUTTONUP:
            pPoll->push(new eventMouseButtonUp(BUTTON_RIGHT));
            break;
        case WM_MBUTTONDOWN:
            pPoll->push(new eventMouseButtonDown(BUTTON_MIDDLE));
            break;
        case WM_MBUTTONUP:
            pPoll->push(new eventMouseButtonUp(BUTTON_MIDDLE));
            break;
		case WM_MOUSEMOVE:
            pPoll->push(new eventMousePosition(LOWORD(lParam), HIWORD(lParam)));
            break;
		case WM_MOUSEWHEEL:
            if(int(wParam) > 0)
                pPoll->push(new eventMouseButtonDown(BUTTON_ROLL_UP));
            else
                pPoll->push(new eventMouseButtonDown(BUTTON_ROLL_DOWN));
    		break;
		case WM_SIZE:
            pPoll->push(new eventResize(LOWORD(lParam), HIWORD(lParam)));
            break;
		case WM_CLOSE:
            pPoll->push(new eventQuit());
            break;
        case WM_DESTROY:
            PostQuitMessage(0);	
            break;
        case WM_QUIT:
            break;
		default:
			return DefWindowProc(hWnd, msg, wParam, lParam);
	}
	return 0;
}
