#ifndef __GLW_TIMER_H__
#define __GLW_TIMER_H__

#include "../include/glw_wgl.h"

namespace glw
{
	class timer
	{
	public:
		timer();
		double time();

	private:
		LARGE_INTEGER m_InitTime, m_TicksPerSecond;
	};
}

#endif//__GLW_TIMER_H__
