/*
    GL Window: WGL Edition
    Copyright (C) 2006 G-Truc Creation (www.g-truc.net)

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the Free
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Christophe [Groove] Riccio
    contact@g-truc.net
*/

#include "event.h"

using glw::Event;
using glw::Key;
using glw::Button;
using namespace glw;

// eventKeyDown
eventKeyDown::eventKeyDown(Key Key) : 
	m_Key(Key)
{}

Key eventKeyDown::value() const
{
	return m_Key;
}

Event eventKeyDown::type() const
{
	return KEY_PRESS;
}

// rventKeyUp
eventKeyUp::eventKeyUp(Key Key) : 
	m_Key(Key)
{}

Key eventKeyUp::value() const
{
	return m_Key;
}

Event eventKeyUp::type() const
{
	return KEY_RELEASE;
}

// eventMouseButtonDown
eventMouseButtonDown::eventMouseButtonDown(Button Button) : 
	m_Button(Button)
{}

Button eventMouseButtonDown::value() const 
{
	return m_Button;
}

Event eventMouseButtonDown::type() const 
{
	return BUTTON_PRESS;
}

// eventMouseButtonUp
eventMouseButtonUp::eventMouseButtonUp(Button Button) : 
	m_Button(Button)
{}

Button eventMouseButtonUp::value() const 
{
	return m_Button;
}

Event eventMouseButtonUp::type() const 
{
	return BUTTON_RELEASE;
}

// eventMousePosition
eventMousePosition::eventMousePosition(int x, int y) :
	x(x), y(y)
{}

void eventMousePosition::value(int& x, int& y) const
{
	x = this->x; 
	y = this->y;
}

Event eventMousePosition::type() const 
{
	return MOTION;
}

// eventResize
eventResize::eventResize(int x, int y) : 
	x(x), y(y)
{}

void eventResize::value(int& x, int& y) const
{
	x = this->x; 
	y = this->y;
}

Event eventResize::type() const
{
	return RESIZE;
}

// eventQuit
Event eventQuit::type() const
{
	return QUIT;
}
