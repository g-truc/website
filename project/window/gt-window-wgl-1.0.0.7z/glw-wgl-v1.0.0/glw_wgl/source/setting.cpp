/*
    GL Window: WGL Edition
    Copyright (C) 2006 G-Truc Creation (www.g-truc.net)

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the Free
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Christophe [Groove] Riccio
    contact@g-truc.net
*/

#include "../include/glw_wgl.h"

using glw::Setting;

Setting::Setting() : 
    m_Name("Window"),
    m_Width(640),
    m_Height(480),
    m_VSync(VSYNC_DEFAULT),
    m_Fullscreen(false),
    m_DoubleBuffer(true),
    m_Color(32),
    m_Depth(16),
    m_Stencil(0),
    m_Samples(0),
    m_Cursor(true),
    m_Icon(0)
{}

const char* Setting::name() const{return m_Name.c_str();}
const char* Setting::title() const{return m_Title.c_str();}
unsigned short Setting::width() const{return m_Width;}
unsigned short Setting::height() const{return m_Height;}
//short Setting::vsync() const{return m_VSync;}
bool Setting::fullscreen() const{return m_Fullscreen;}
//bool Setting::doubleBuffer() const{return m_DoubleBuffer;}
unsigned char Setting::colorBuffer() const{return m_Color;}
unsigned char Setting::depthBuffer() const{return m_Depth;}
unsigned char Setting::stencilBuffer() const{return m_Stencil;}
//unsigned char Setting::sampleBuffer() const{return m_Samples;}
bool Setting::cursor() const{return m_Cursor;}
short Setting::icon() const{return m_Icon;}

void Setting::name(const char* value){m_Name = value;}
void Setting::title(const char* value){m_Title = value;}
void Setting::width(unsigned short value){m_Width = value;}
void Setting::height(unsigned short value){m_Height = value;}
//void Setting::vsync(short value){m_VSync = value;}
void Setting::fullscreen(bool value){m_Fullscreen = value;}
//void Setting::doubleBuffer(bool value){m_DoubleBuffer = value;}
void Setting::colorBuffer(unsigned char value){m_Color = value;}
void Setting::depthBuffer(unsigned char value){m_Depth = value;}
void Setting::stencilBuffer(unsigned char value){m_Stencil = value;}
//void Setting::sampleBuffer(unsigned char value){m_Samples = value;}
void Setting::cursor(bool value){m_Cursor = value;}
void Setting::icon(short value){m_Icon = value;}
