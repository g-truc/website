/*
    GT Window: WGL Edition
    Copyright (C) 2006 G-Truc Creation (www.g-truc.net)

    Christophe [Groove] Riccio
    contact@g-truc.net
*/

#include "base.h"

namespace gtw
{
	Window::Window(const Setting& Setting)
	{
		base::instance()->create(Setting);
	}

	Window::~Window()
	{
		base::destroy();
	}

	void Window::swap()
	{
		base::instance()->swap();
	}

	bool Window::poll()
	{
		return base::instance()->poll();
	}

	Event Window::event() const
	{
		return base::instance()->event();
	}

	Key Window::key()
	{
		return base::instance()->key();
	}

	Button Window::button()
	{
		return base::instance()->button();
	}

	void Window::resize(int& x, int& y)
	{
		base::instance()->resize(x, y);
	}

	void Window::motion(int& x, int& y)
	{
		base::instance()->motion(x, y);
	}

	double Window::time()
	{
		return base::instance()->time();
	}

	unsigned int Window::width() const
	{
		return base::instance()->width();
	}

	unsigned int Window::height() const
	{
		return base::instance()->height();
	}
}
