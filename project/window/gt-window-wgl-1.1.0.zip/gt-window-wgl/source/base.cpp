/*
    GT Window: WGL Edition
    Copyright (C) 2006 G-Truc Creation (www.g-truc.net)

    Christophe [Groove] Riccio
    contact@g-truc.net
*/

#include "base.h"
#include "poll.h"

namespace gtw
{
	LRESULT CALLBACK WindowProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

	base::base() : 
		m_DeviceContext(NULL),
		m_RenderingContext(NULL),
		m_Window(NULL),
		m_Instance(NULL),
		m_Fullscreen(false),
		m_Width(640),
		m_Height(480),
		m_Cursor(true),
		m_Name("G-Truc Creation"),
		m_Title("G-Truc Creation"),
		m_pTimer(new timer())
	{}

	base::~base()
	{
		_destroy();
		pollWin32::destroy();
		delete m_pTimer;
	}

	void base::swap()
	{
		SwapBuffers(m_DeviceContext);
	}

	double base::time()
	{
		return m_pTimer->time();
	}

	int base::width() const
	{
		return m_Width;
	}

	int base::height() const
	{
		return m_Height;
	}

	bool base::poll()
	{
		return pollWin32::instance()->poll();
	}

	Event base::event() const
	{
		return pollWin32::instance()->event();
	}

	Key base::key()
	{
		if(pollWin32::instance()->event() & KEY_PRESS || 
		pollWin32::instance()->event() & KEY_RELEASE)
			m_Key = pollWin32::instance()->key();
		return m_Key;
	}

	Button base::button()
	{
		if(pollWin32::instance()->event() & BUTTON_PRESS ||
		pollWin32::instance()->event() & BUTTON_RELEASE)
			m_Button = pollWin32::instance()->button();
		return m_Button;
	}

	void base::resize(int& x, int& y)
	{
		if(pollWin32::instance()->event() & RESIZE)
			pollWin32::instance()->resize(m_Width, m_Height);
		x = m_Width;
		y = m_Height;
	}

	void base::motion(int& x, int& y)
	{
		if(pollWin32::instance()->event() & MOTION)
			pollWin32::instance()->motion(m_MotionX, m_MotionY);
		x = m_MotionX;
		y = m_Height - m_MotionY;
	}

	bool base::create(const Setting& Setting)
	{
		m_Width = Setting.width();
		m_Height = Setting.height();
		m_Name = Setting.name();
		m_Fullscreen = Setting.fullscreen();

		m_Instance = GetModuleHandle(NULL);

		WNDCLASSEX WindowClass;
		WindowClass.cbSize			= sizeof(WNDCLASSEX);
		WindowClass.style			= CS_HREDRAW | CS_VREDRAW;
		WindowClass.lpfnWndProc		= WindowProc;
		WindowClass.cbClsExtra		= 0;
		WindowClass.cbWndExtra		= 0;
		WindowClass.hInstance		= m_Instance;
		WindowClass.hIcon			= LoadIcon(m_Instance, Setting.icon() != 0 ? (LPCTSTR)Setting.icon() : IDI_WINLOGO);
		WindowClass.hCursor			= LoadCursor(NULL, IDC_ARROW);
		WindowClass.hbrBackground	= NULL;
		WindowClass.lpszMenuName	= m_Name.c_str();
		WindowClass.lpszClassName	= m_Name.c_str();
		WindowClass.hIconSm			= LoadIcon(m_Instance, Setting.icon() != 0 ? (LPCTSTR)Setting.icon() : IDI_WINLOGO);

		if(!RegisterClassEx(&WindowClass))
		{
			fprintf(stderr, "Failed To Register The Window Class.\n");
			return false;
		}

		m_Window = 0;

		if(m_Fullscreen)
		{
			DEVMODE dmScreenSettings;
			EnumDisplaySettings(NULL, ENUM_CURRENT_SETTINGS, &dmScreenSettings);
			//memset(&dmScreenSettings, 0, sizeof(dmScreenSettings));

			dmScreenSettings.dmPelsWidth = Setting.width();
			dmScreenSettings.dmPelsHeight = Setting.height();
			dmScreenSettings.dmBitsPerPel = Setting.colorBuffer();
			dmScreenSettings.dmFields = DM_BITSPERPEL | DM_PELSWIDTH | DM_PELSHEIGHT;
			//dmScreenSettings.dmDisplayFrequency = Setting.vsync();

			if(ChangeDisplaySettings(&dmScreenSettings, CDS_FULLSCREEN) != DISP_CHANGE_SUCCESSFUL)
				m_Fullscreen = false;
		}

		DWORD dwExStyle;
		DWORD dwStyle;
		if(m_Fullscreen)
		{
			dwExStyle = WS_EX_APPWINDOW;
			dwStyle = WS_POPUP | WS_VISIBLE;
		}
		else
		{
			dwExStyle = WS_EX_APPWINDOW | WS_EX_WINDOWEDGE;
			dwStyle = WS_OVERLAPPEDWINDOW | WS_VISIBLE;
		}

		static PIXELFORMATDESCRIPTOR PixelFormatDesc =
		{
			sizeof(PIXELFORMATDESCRIPTOR), 				// Size Of This Pixel Format Descriptor
			1, 											// Version Number
			PFD_DRAW_TO_WINDOW |						// Format Must Support Window
			PFD_SUPPORT_OPENGL |						// Format Must Support OpenGL
			PFD_DOUBLEBUFFER, 							// Must Support Double Buffering
			PFD_TYPE_RGBA, 								// Request An RGBA Format
			Setting.colorBuffer(), 										// Select Our Color Depth
			0, 0, 0, 0, 0, 0, 							// Color Bits Ignored
			0, 											// No Alpha Buffer
			0, 											// Shift Bit Ignored
			0, 											// No Accumulation Buffer
			0, 0, 0, 0, 								// Accumulation Bits Ignored
			Setting.depthBuffer(), 										// 16Bit Z-Buffer (Depth Buffer)  
			Setting.stencilBuffer(), 											// No Stencil Buffer
			0, 											// No Auxiliary Buffer
			PFD_MAIN_PLANE, 							// Main Drawing Layer
			0, 											// Reserved
			0, 0, 0 									// Layer Masks Ignored
		};

		GLint PixelFormat = 0;

		float fAttributes[32] = {0, 0};	

		int iAttributes[] =
		{
			WGL_SWAP_METHOD_ARB,        WGL_SWAP_EXCHANGE_ARB, //WGL_SWAP_COPY_ARB is nicest and WGL_SWAP_EXCHANGE_ARB is faster
			WGL_DOUBLE_BUFFER_ARB,      GL_TRUE,
			WGL_DRAW_TO_WINDOW_ARB,     GL_TRUE,
			WGL_ACCELERATION_ARB,       WGL_FULL_ACCELERATION_ARB,
			//WGL_COLOR_BITS_ARB,         Setting.colorBuffer(),
			WGL_RED_BITS_ARB,           Setting.colorBuffer() >> 2,
			WGL_GREEN_BITS_ARB,         Setting.colorBuffer() >> 2,
			WGL_BLUE_BITS_ARB,          Setting.colorBuffer() >> 2,
			WGL_DEPTH_BITS_ARB,         Setting.depthBuffer(),
			WGL_STENCIL_BITS_ARB,       Setting.stencilBuffer(),
			WGL_AUX_BUFFERS_ARB,        0,
	//        WGL_SAMPLE_BUFFERS_ARB,     Setting.sampleBuffer() > 0 ? GL_TRUE : GL_FALSE,
	//        WGL_SAMPLES_ARB,            Setting.sampleBuffer(),
			0, 0
		};

		// Create a temporary Window to get the pixel format ..
		HWND WindowTemp = CreateWindowEx(
			dwExStyle,
			WindowClass.lpszClassName,
			WindowClass.lpszClassName,
			WS_POPUP | WS_CLIPCHILDREN | WS_CLIPSIBLINGS,
			0, 0, 1, 1, 0, 0,
			m_Instance,
			NULL);

		if(!WindowTemp)
		{
			fprintf(stderr, "CreateWindowEx failed (1)\n");
			return false;
		}

		if(!_createContext(WindowTemp, PixelFormat, &PixelFormatDesc))
		{
  			fprintf(stderr, "Temporary context creation failed.\n");
			ReleaseDC(WindowTemp, m_DeviceContext);
			DestroyWindow(WindowTemp);
			return false;
		}

		// Select the frame buffer pixel format
		unsigned int NumFormats = 0;
		if(WGLEW_ARB_pixel_format)
		{
			bool Success = wglChoosePixelFormatARB(m_DeviceContext, iAttributes, fAttributes, 1, &PixelFormat, &NumFormats) == GL_TRUE;
			if(!Success)// || NumFormats < 1) Doesn't work on ATI card
			{
				fprintf(stderr, "wglChoosePixelFormatARB failed.\n");
				return false;
			}
		}
		else
		{
			PixelFormat = ChoosePixelFormat(m_DeviceContext, &PixelFormatDesc);
			if(!PixelFormat)
			{
				_destroy();
				fprintf(stderr, "Can't Find A Suitable PixelFormat.\n");
				return false;
			}
		}

		// Delete the temporary Window
		wglMakeCurrent(NULL, NULL);
		ReleaseDC(WindowTemp, m_DeviceContext);
		wglDeleteContext(m_RenderingContext);
		DestroyWindow(WindowTemp);

		RECT WindowRect;
		WindowRect.left = 0;
		WindowRect.right = Setting.width();
		WindowRect.top = 0;
		WindowRect.bottom = Setting.height();
		AdjustWindowRectEx(&WindowRect, dwStyle, FALSE, dwExStyle);

		// Create the final Window
		m_Window = CreateWindowEx(
			dwExStyle, 							            // Extended Style For The Window
			WindowClass.lpszClassName, 					    // Class Name
			Setting.title(),                                // Window Title
			dwStyle | WS_CLIPSIBLINGS | WS_CLIPCHILDREN,    // Required Window Style
			0, 0,                                           // Window Position
			WindowRect.right - WindowRect.left,             // Calculate Window Width
			WindowRect.bottom - WindowRect.top,             // Calculate Window Height
			NULL,                                           // No Parent Window
			NULL,                                           // No Menu
			m_Instance,                                     // Instance
			NULL);                                          // Dont Pass Anything To WM_CREATE

		if(!m_Window)                                         
		{
			_destroy();
			fprintf(stderr, "Window Creation Error.\n");
			return false;
		}

		if(!_createContext(m_Window, PixelFormat, &PixelFormatDesc))
		{
   			fprintf(stderr, "Context creation failed.\n");
			return false;
		}

	//    if(WGLEW_EXT_swap_control && Setting.vsync() == VSYNC_DISABLE)
	//        wglSwapIntervalEXT(0);

		// Show the final Window on foreground
		ShowWindow(m_Window, SW_SHOW);
		SetForegroundWindow(m_Window);
		SetFocus(m_Window);

		if(m_Cursor = Setting.cursor() == false)
			ShowCursor(FALSE);
		else
			ShowCursor(TRUE);

		return true;
	}

	void base::_destroy()
	{
		ShowCursor(TRUE);
	    
		if(m_Fullscreen)
			ChangeDisplaySettings(NULL, 0);

		_destroyContext();

		if(m_Window && !DestroyWindow(m_Window))
		{
			fprintf(stderr, "DestroyWindow failed.\n");
			m_Window = NULL;
		}

		if(!UnregisterClass(m_Name.c_str(), m_Instance))
		{
			fprintf(stderr, "UnregisterClass failed.\n");
			m_Instance = NULL;
		}
	}

	bool base::_createContext(HWND Window, int PixelFormat, PIXELFORMATDESCRIPTOR* pPixelFormatDesc)
	{
  		m_DeviceContext = GetDC(Window);

		if(!m_DeviceContext)
		{
			fprintf(stderr, "Can't Create A GL Device Context.\n");
			return false;
		}

		if(!PixelFormat)
      		PixelFormat = ChoosePixelFormat(m_DeviceContext, pPixelFormatDesc);

		if(!PixelFormat)
		{
  			fprintf(stderr, "ChoosePixelFormat failed. \n");
			return false;
		}

  		if(!SetPixelFormat(m_DeviceContext, PixelFormat, pPixelFormatDesc))
		{
  			fprintf(stderr, "SetPixelFormat failed.\n");
			return false;
		}

		if(!(m_RenderingContext = wglCreateContext(m_DeviceContext)))
		{
  			fprintf(stderr, "wglCreateContext failed.\n");
  			return false;
		}

		if(!wglMakeCurrent(m_DeviceContext, m_RenderingContext))
		{
 			fprintf(stderr, "Can't Activate The GL Rendering Context.\n");
			return false;
		}

		//! Load OpenGL extensions
		glewInit();

		return true;
	}

	void base::_destroyContext()
	{
		if(m_RenderingContext)
		{
			if(!wglMakeCurrent(NULL, NULL))
				fprintf(stderr, "wglMakeCurrent(0, 0) failed.\n");

			if(!wglDeleteContext(m_RenderingContext))
				fprintf(stderr, "wglDeleteContext failed.\n");

			m_RenderingContext = NULL;
		}

		if(m_DeviceContext && !ReleaseDC(m_Window, m_DeviceContext))
		{
			fprintf(stderr, "ReleaseDC failed.\n");
			m_DeviceContext = NULL;
		}
	}

	bool base::_checkExtensionSupport(const char* Name)
	{
		const char* Extensions = (const char*)glGetString(GL_EXTENSIONS);
		return strstr(Extensions, Name) != 0;
	}
}
