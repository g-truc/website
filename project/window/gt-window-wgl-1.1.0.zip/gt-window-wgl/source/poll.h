/*
    GT Window: WGL Edition
    Copyright (C) 2006 G-Truc Creation (www.g-truc.net)

    Christophe [Groove] Riccio
    contact@g-truc.net
*/

#ifndef __GLW_POLL_H__
#define __GLW_POLL_H__

#include "../include/window_wgl.h"
#include "singleton.h"
#include "event.h"

namespace gtw
{
    class pollWin32 : public gtw::singleton<pollWin32>
    {
        friend class gtw::singleton<pollWin32>;

    public:
        void push(eventInterface* pEvent);
        bool poll();
        Event event() const;

        Key key() const;
        Button button() const;
        void resize(int& x, int& y) const;
        void motion(int& x, int& y) const;
        
        int test;

    private:
        pollWin32();
        ~pollWin32();

        void _update();
        void _clear();

        eventInterface* m_pFirstEvent;
        bool m_bEmpty;
        MSG m_uMsg;
    };
}

#endif //__GLW_POLL_H__
