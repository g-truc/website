/*
    GT Window: WGL Edition
    Copyright (C) 2006 G-Truc Creation (www.g-truc.net)

    Christophe [Groove] Riccio
    contact@g-truc.net
*/

#ifndef __GLW_BASE_H__
#define __GLW_BASE_H__

#include "../include/window_wgl.h"
#include "timer.h"
#include "singleton.h"

namespace gtw
{
    class base : public singleton<base>
    {
        friend class singleton<base>;

    private:
        base();
        ~base();

    public:
        //! Create the Window
        bool create(const Setting& Setting);

        void swap();

        bool poll();
        Event event() const;

        Key key();
        Button button();
        void resize(int& x, int& y);
        void motion(int& x, int& y);

        double time();

        int width() const;
        int height() const;

    private:
        //! Initialize device and rendering contexts 
        bool _createContext(HWND hWindow, int PixelFormat, PIXELFORMATDESCRIPTOR* pPixelFormatDesc);
        //! Delete device and rendering contexts 
        void _destroyContext();
        //! Delete the Window
        void _destroy();
        //! Check whether graphic driver support an OpenGL extension
        bool _checkExtensionSupport(const char* Name);

        gtw::Key m_Key;
        gtw::Button m_Button;
        int m_MotionX;
        int m_MotionY;

        HDC m_DeviceContext;
        HGLRC m_RenderingContext;
        HWND m_Window;
        HINSTANCE m_Instance;
        bool m_Fullscreen;
        int m_Width;
        int m_Height;
        bool m_Cursor;
        std::string m_Name;
        std::string m_Title;
        timer* m_pTimer;

    private:
        //! Doesn't allow copy construction
        base(const base& Base);
        //! Doesn't allow copy construction
        base& operator=(const base& Base);
    };
}//namespace glw

#endif //__GLW_BASE_H__
