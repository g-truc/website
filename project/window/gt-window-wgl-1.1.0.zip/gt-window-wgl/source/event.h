/*
    GT Window: WGL Edition
    Copyright (C) 2006 G-Truc Creation (www.g-truc.net)

    Christophe [Groove] Riccio
    contact@g-truc.net
*/

#ifndef __GLW_EVENT_H__
#define __GLW_EVENT_H__

#include "../include/window_wgl.h"

namespace gtw
{
    // eventInterface
    struct eventInterface
    {
		eventInterface() : m_pNext(0){}
        virtual Event type() const = 0;
        eventInterface* m_pNext;
    };

    // eventKeyDown
    class eventKeyDown : public eventInterface
    {
    public:
        eventKeyDown(Key Key);
        Key value() const;
        virtual Event type() const;

    private:
        Key m_Key;
    };

    // eventKeyUp
    class eventKeyUp : public eventInterface
    {
    public:
        eventKeyUp(Key Key);
        Key value() const;
        virtual Event type() const;

    private:
        Key m_Key;
    };

    // eventMouseButtonDown
    class eventMouseButtonDown : public eventInterface
    {
    public:
        eventMouseButtonDown(Button Button);
        Button value() const;
        virtual Event type() const;

    private:
        Button m_Button;
    };

    // eventMouseButtonUp
    class eventMouseButtonUp : public eventInterface
    {
    public:
        eventMouseButtonUp(Button Button); 
        Button value() const;
        virtual Event type() const;

    private:
        Button m_Button;
    };

    // eventMousePosition
    class eventMousePosition : public eventInterface
    {
    public:
        eventMousePosition(int x, int y);
        void value(int& x, int& y) const;
        virtual Event type() const;

    private:
        int x, y;
    };

    // eventResize
    class eventResize : public eventInterface
    {
    public:
        eventResize(int x, int y);
        void value(int& x, int& y) const;
        virtual Event type() const;

    private:
        int x, y;
    };

    // eventQuit
    class eventQuit : public eventInterface
    {
    public:
        virtual Event type() const;
    };
}

#endif//__GLW_EVENT_H__
