#include <window_wgl.h>

#define IDI_ICON 102

int g_FPSCount = 0;
double g_Time = 0;

// GL_C3F_V3F
struct vertex
{
	float r, g, b;
	float x, y, z;
};

vertex g_Quad[] =
{
	{1.0f, 0.0f, 0.0f, -1.0f,-1.0f, 0.0f},
	{1.0f, 1.0f, 0.0f, -1.0f, 1.0f, 0.0f},
	{0.0f, 1.0f, 0.0f,  1.0f, 1.0f, 0.0f},
	{0.0f, 0.0f, 1.0f,  1.0f,-1.0f, 0.0f},
};

void begin()
{
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glShadeModel(GL_SMOOTH);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.0f, 640.0f / 480.0f, 0.1f, 100.0f);
}

void end()
{}

void render()
{
    glClear(GL_COLOR_BUFFER_BIT);

	glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glTranslatef(0.0f, 0.0f,-4.0f);

    glInterleavedArrays(GL_C3F_V3F, 0, g_Quad);
    glDrawArrays(GL_QUADS, 0, 4);
}

int main(int argc, char* argv[])
{
    // Check BoundsChecker working
    int* i = new int;

    // Window configuration
    gtw::Setting Setting;
    Setting.title("GLW-WGL Sample");
    Setting.fullscreen(false);
    Setting.width(640);
    Setting.height(480);
    Setting.icon(IDI_ICON);

    // Create the window object
    gtw::Window* Window = new gtw::Window(Setting);

    begin();

    bool Exit = false;
    while(!Exit)
	{
        // Get the time
        double Time = Window->time();

        // Is there an event?
        while(Window->poll())
        {
            // What is the type of the event?
            switch(Window->event())
            {
            case gtw::KEY_PRESS:
                switch(Window->key())
                {
                case gtw::KEY_ESC:
                    Exit = true;
                    break;
                default:
                    break;
                }
                printf("KEY_PRESS\n");
                break;
            case gtw::KEY_RELEASE:
                printf("KEY_RELEASE\n");
                break;
            case gtw::BUTTON_PRESS:
                printf("BUTTON_PRESS\n");
                break;
            case gtw::BUTTON_RELEASE:
                printf("BUTTON_RELEASE\n");
                break;
            case gtw::MOTION:
                printf("MOUSE_MOVE\n");
                break;
            case gtw::RESIZE:
                printf("RESIZE\n");
                break;
            case gtw::QUIT:
                Exit = true;
                printf("QUIT\n");
                break;
            default:
                //printf("DEFAULT\n");
                break;
            }
        }

        render();

        // Swap framebuffers
        Window->swap();

	    int Error;
	    if((Error = glGetError()) != GL_NO_ERROR)
	    {
		    const char* Message = (const char*)gluErrorString(Error);
            fprintf(stderr, "OpenGL Error : %s\n", Message);
	    }

        g_FPSCount++;
        if(Time - g_Time > 1.0)
        {
            printf("FPS: %d\n", g_FPSCount);
            g_FPSCount = 0;
            g_Time = Time;
        }
	}

    end();

    delete Window;

    return 0;
}

