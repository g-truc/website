#include <window_d3d9.h>

#define IDI_ICON 102

int g_FPSCount = 0;
double g_Time = 0;

LPDIRECT3DVERTEXBUFFER9 g_VertexBuffer = null;

struct vertex
{
	float x, y, z;
    DWORD color;
};

vertex g_Quad[] =
{
	{-1.0f,-1.0f, 0.0f, D3DCOLOR_COLORVALUE(1.0f, 0.0f, 0.0f, 1.0f)},
	{-1.0f, 1.0f, 0.0f, D3DCOLOR_COLORVALUE(1.0f, 1.0f, 0.0f, 1.0f)},
	{ 1.0f, 1.0f, 0.0f, D3DCOLOR_COLORVALUE(0.0f, 1.0f, 0.0f, 1.0f)},
	{ 1.0f,-1.0f, 0.0f, D3DCOLOR_COLORVALUE(0.0f, 0.0f, 1.0f, 1.0f)}
};

void begin()
{
    gtw::d3dDevice()->CreateVertexBuffer(
        sizeof(vertex) * 4, 
        D3DUSAGE_WRITEONLY,
        D3DFVF_XYZ | D3DFVF_DIFFUSE, 
        D3DPOOL_DEFAULT, 
        &g_VertexBuffer, null);

    void* Buffer = null;
    g_VertexBuffer->Lock(0, sizeof(vertex) * 4, (void**)&Buffer, 0);
    memcpy(Buffer, g_Quad, sizeof(vertex) * 4);
    g_VertexBuffer->Unlock();

    D3DXMATRIX matProj;
    D3DXMatrixPerspectiveFovLH(&matProj, D3DXToRadian(45.0f), 640.0f / 480.0f, 0.1f, 100.0f);
    gtw::d3dDevice()->SetTransform(D3DTS_PROJECTION, &matProj);

	gtw::d3dDevice()->SetRenderState(D3DRS_LIGHTING, FALSE);
    gtw::d3dDevice()->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
}

void end()
{
    if(g_VertexBuffer != null)
    {
        g_VertexBuffer->Release(); 
        g_VertexBuffer = null;
    }
}

void render()
{
    gtw::d3dDevice()->Clear(0, null, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, D3DCOLOR_COLORVALUE(0.0f, 0.0f, 0.0f, 1.0f), 1.0f, 0);

	D3DXMATRIX ModelView;
	D3DXMatrixTranslation(&ModelView, 0.0f, 0.0f, 4.0f);
    gtw::d3dDevice()->SetTransform(D3DTS_WORLD, &ModelView);

    gtw::d3dDevice()->BeginScene();

    gtw::d3dDevice()->SetStreamSource(0, g_VertexBuffer, 0, sizeof(vertex));
	gtw::d3dDevice()->SetFVF(D3DFVF_XYZ | D3DFVF_DIFFUSE);
	gtw::d3dDevice()->DrawPrimitive(D3DPT_TRIANGLEFAN, 0, 2);

    gtw::d3dDevice()->EndScene();
}

int main(int argc, char* argv[])
{
    gtw::Setting Setting;
    Setting.name("GLW-D3D9 sample");
    Setting.title("GLW-D3D9 sample");
    Setting.fullscreen(false);
    //Setting.sampleBuffer(0);
    Setting.width(640);
    Setting.height(480);
    //Setting.vsync(gtw::VSYNC_DISABLE);
    Setting.icon(IDI_ICON);

    gtw::Window* Window = new gtw::Window(Setting);

	begin();

    bool Exit = false;
    while(!Exit)
	{
        render();

        // Get the time
        double Time = Window->time();

        while(Window->poll())
        {
            switch(Window->event())
            {
            case gtw::KEY_PRESS:
                switch(Window->key())
                {
                case gtw::KEY_ESC:
                    Exit = true;
                    break;
                default:
                    break;
                }
                printf("KEY_PRESS\n");
                break;
            case gtw::KEY_RELEASE:
                printf("KEY_RELEASE\n");
                break;
            case gtw::BUTTON_PRESS:
                printf("BUTTON_PRESS\n");
                break;
            case gtw::BUTTON_RELEASE:
                printf("BUTTON_RELEASE\n");
                break;
            case gtw::MOTION:
                printf("MOUSE_MOVE\n");
                break;
            case gtw::RESIZE:
                printf("RESIZE\n");
                break;
            case gtw::QUIT:
                Exit = true;
                printf("QUIT\n");
                break;
            }
        }

        Window->swap();

        g_FPSCount++;
        if(Time - g_Time > 1.0)
        {
            printf("FPS: %d\n", g_FPSCount);
            g_FPSCount = 0;
            g_Time = Time;
        }
	}

    end();

    delete Window;

    return 0;
}
