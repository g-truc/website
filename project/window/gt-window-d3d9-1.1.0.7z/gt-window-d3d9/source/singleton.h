/*
    GT Window: Direct3D 9 Edition
    Copyright (C) 2006 G-Truc Creation (www.g-truc.net)

    Christophe [Groove] Riccio
    contact@g-truc.net
*/

#ifndef __GLW_SINGLETON_H__
#define __GLW_SINGLETON_H__

namespace gtw
{
    template <typename T> 
    class singleton
    {
    public:
        // 13/06/2005 - Get and/or create the singleton instance
        static T* instance();
        // 13/06/2005 - Delete singleton instance if it was created 
        static void destroy();
        // 13/06/2005 - Test if singleton instance was created
        static bool isCreated();

    private:
        static T* m_pInstance;
    };
} //namespace gtw

#include "singleton.inl"

#endif //__GLW_SINGLETON_H__
