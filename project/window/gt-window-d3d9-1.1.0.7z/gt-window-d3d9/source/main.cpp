/*
    GT Window: Direct3D 9 Edition
    Copyright (C) 2006 G-Truc Creation (www.g-truc.net)

    Christophe [Groove] Riccio
    contact@g-truc.net
*/

#include "window.h"
#include <windows.h>
#include <malloc.h>
#include <shellapi.h>
#include <cstdio>

#define null 0

int main(int argc, char* argv[]);

// From SDL (www.libsdl.org)
int ParseCommandLine(char *cmdline, char **argv)
{
	int argc = 0;
	for(char* bufp = cmdline; *bufp; )
    {
		while(isspace(*bufp))
			++bufp;

        if(*bufp == '"')
        {
			++bufp;
			if(*bufp)
            {
				if(argv)
					argv[argc] = bufp;
				++argc;
			}
			while(*bufp && (*bufp != '"'))
				++bufp;
		}
        else
        {
			if(*bufp)
            {
				if(argv)
					argv[argc] = bufp;
				++argc;
			}
			while(*bufp && ! isspace(*bufp))
				++bufp;
		}
		if(*bufp)
        {
			if(argv)
				*bufp = '\0';
			++bufp;
		}
	}

	if(argv)
		argv[argc] = null;
	return argc;
}

void Log()
{
    freopen("stdout.txt", "w", stdout);
    freopen("stderr.txt", "w", stderr);
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int iCmdShow)
{
    Log();

	char* bufp = GetCommandLine();
	char* cmdline = (char*)alloca(strlen(bufp) + 1);
	if(cmdline == null)
        return 1;
	strcpy(cmdline, bufp);

	int argc = ParseCommandLine(cmdline, null);
	char** argv = (char**)alloca((argc + 1)*(sizeof *argv));
	if(argv == null)
		return 1;
	ParseCommandLine(cmdline, argv);

    int iErrorCode = main(argc, argv);

    fclose(stdout);
    fclose(stderr);

    return iErrorCode;
}
