/*
    GT Window: Direct3D 9 Edition
    Copyright (C) 2006 G-Truc Creation (www.g-truc.net)

    Christophe [Groove] Riccio
    contact@g-truc.net
*/

#include "timer.h"

using gtw::timer;

timer::timer()
{
	QueryPerformanceFrequency(&m_TicksPerSecond);
	QueryPerformanceCounter(&m_InitTime);
}

double timer::time()
{
    LARGE_INTEGER UpdatedTime;
	QueryPerformanceCounter(&UpdatedTime);
	return double(UpdatedTime.QuadPart - m_InitTime.QuadPart) / double(m_TicksPerSecond.QuadPart);
}
