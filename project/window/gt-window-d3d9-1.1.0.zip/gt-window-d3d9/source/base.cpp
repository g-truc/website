/*
    GT Window: Direct3D 9 Edition
    Copyright (C) 2006 G-Truc Creation (www.g-truc.net)

    Christophe [Groove] Riccio
    contact@g-truc.net
*/

#include "base.h"

#define null 0

namespace gtw
{
	LRESULT CALLBACK WindowProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

	CWindowD3D::CWindowD3D() :
		m_pD3dDevice(null),
		m_pD3d(null)
	{}

	CWindowD3D::~CWindowD3D()
	{
		if(m_pD3dDevice != null)
			m_pD3dDevice->Release();

		if(m_pD3d != null)
			m_pD3d->Release();
	}

	void CWindowD3D::init(const Setting& Setting, HWND Window)
	{
		m_pD3d = Direct3DCreate9(D3D_SDK_VERSION);
		if(m_pD3d == NULL)
			return;

		D3DDISPLAYMODE d3ddm;
		if(FAILED(m_pD3d->GetAdapterDisplayMode(D3DADAPTER_DEFAULT, &d3ddm)))
			return;

		HRESULT hr;
		if(FAILED(hr = m_pD3d->CheckDeviceFormat(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, d3ddm.Format, D3DUSAGE_DEPTHSTENCIL, D3DRTYPE_SURFACE, D3DFMT_D16)))
			if(hr == D3DERR_NOTAVAILABLE)
				return;

		D3DCAPS9 d3dCaps;
		if(FAILED(m_pD3d->GetDeviceCaps(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, &d3dCaps)))
			return;

		DWORD dwBehaviorFlags = 0;

		if(d3dCaps.VertexProcessingCaps != 0)
			dwBehaviorFlags |= D3DCREATE_HARDWARE_VERTEXPROCESSING;
		else
			dwBehaviorFlags |= D3DCREATE_SOFTWARE_VERTEXPROCESSING;

		D3DPRESENT_PARAMETERS d3dpp;
		memset(&d3dpp, 0, sizeof(d3dpp));

		d3dpp.BackBufferWidth        = Setting.width();
		d3dpp.BackBufferHeight       = Setting.height();
		d3dpp.BackBufferFormat       = Setting.colorBuffer() == 16 ? D3DFMT_X1R5G5B5 : D3DFMT_X8R8G8B8;
		//d3dpp.BackBufferFormat       = d3ddm.Format;
		d3dpp.SwapEffect             = D3DSWAPEFFECT_DISCARD;
		d3dpp.Windowed               = Setting.fullscreen() ? FALSE : TRUE;
		d3dpp.EnableAutoDepthStencil = TRUE;
		d3dpp.AutoDepthStencilFormat = _getDepthSentil(Setting); 
	//    d3dpp.MultiSampleType = D3DMULTISAMPLE_TYPE(Setting.sampleBuffer());
		//d3dpp.MultiSampleQuality = ;
		d3dpp.PresentationInterval = D3DPRESENT_INTERVAL_DEFAULT;
	/*
		switch(Setting.vsync())
		{
		case gtw::VSYNC_DISABLE:
			d3dpp.PresentationInterval = D3DPRESENT_INTERVAL_IMMEDIATE;
			break;
		case gtw::VSYNC_DEFAULT:
			d3dpp.PresentationInterval = D3DPRESENT_INTERVAL_DEFAULT;
			break;
		default:
			d3dpp.PresentationInterval = D3DPRESENT_DONOTWAIT;
			d3dpp.FullScreen_RefreshRateInHz = Setting.vsync();
			break;
		}
	*/
		//d3dpp.PresentationInterval   = Setting.Frequency() > 0 ? D3DPRESENT_INTERVAL_DEFAULT : D3DPRESENT_INTERVAL_IMMEDIATE; // D3DPRESENT_DONOTWAIT
		//d3dpp.PresentationInterval   = D3DPRESENT_DONOTWAIT; // D3DPRESENT_DONOTWAIT
		//d3dpp.FullScreen_RefreshRateInHz = Setting.Frequency();

		if(FAILED(m_pD3d->CreateDevice(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, Window, dwBehaviorFlags, &d3dpp, &m_pD3dDevice)))
			return;
	}

	void CWindowD3D::swap()
	{
		m_pD3dDevice->Present(null, null, null, null);
	}

	LPDIRECT3DDEVICE9 CWindowD3D::device() const
	{
		return m_pD3dDevice;
	}

	D3DFORMAT CWindowD3D::_getDepthSentil(const Setting& Setting)
	{
		if(Setting.stencilBuffer() > 0)
			return D3DFMT_D24S8;

		switch(Setting.depthBuffer())
		{
		case 16: return D3DFMT_D16;
		case 24: return D3DFMT_D24X8;
		default: return D3DFMT_D24X8;
		}
	}

	LPDIRECT3DDEVICE9 gtw::d3dDevice()
	{
		return CWindowD3D::instance()->device();
	}




	base::base() :
		m_Timer(new gtw::timer())
	{}

	base::~base()
	{
		delete m_Timer;
		UnregisterClass(m_Name.c_str(), m_WinClass.hInstance);
		gtw::CWindowD3D::destroy();
	}

	void base::create(const Setting& Setting)
	{
		m_Name = Setting.name();
		m_Instance = GetModuleHandle(NULL);

		_createWindow(Setting);
		_initScreen(Setting);
		gtw::CWindowD3D::instance()->init(Setting, m_Window);
	}

	double base::time()
	{
		return m_Timer->time();
	}

	void base::_createWindow(const Setting& Setting)
	{
		m_WinClass.cbSize        = sizeof(WNDCLASSEX);
		m_WinClass.style         = CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
		m_WinClass.lpfnWndProc   = WindowProc;
		m_WinClass.hInstance     = m_Instance;
		m_WinClass.hIcon	     = LoadIcon(m_Instance, (LPCTSTR)Setting.icon());
		m_WinClass.hIconSm	     = LoadIcon(m_Instance, (LPCTSTR)Setting.icon());
		m_WinClass.hCursor       = LoadCursor(null, IDC_ARROW);
		m_WinClass.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
		m_WinClass.lpszMenuName	 = Setting.name();
		m_WinClass.lpszClassName = Setting.name();
		m_WinClass.cbClsExtra    = 0;
		m_WinClass.cbWndExtra    = 0;
		
		if(!RegisterClassEx(&m_WinClass))
			//return E_FAIL;
			return;

		DWORD dwExStyle;
		DWORD dwStyle;
		if(Setting.fullscreen())
		{
			dwExStyle = WS_EX_APPWINDOW;
			dwStyle = WS_POPUP | WS_VISIBLE;
		}
		else
		{
			dwExStyle = WS_EX_APPWINDOW | WS_EX_WINDOWEDGE;
			dwStyle = WS_OVERLAPPEDWINDOW | WS_VISIBLE;
		}

		RECT WindowRect;
		WindowRect.left = 0;
		WindowRect.right = Setting.width();
		WindowRect.top = 0;
		WindowRect.bottom = Setting.height();
		AdjustWindowRectEx(&WindowRect, dwStyle, FALSE, dwExStyle);

		if(Setting.fullscreen())
		{
			m_Window = CreateWindowEx(null, Setting.name(), 
				Setting.title(),
				WS_POPUP | WS_VISIBLE,
				0, 0, 
				WindowRect.right - WindowRect.left, 
				WindowRect.bottom - WindowRect.top,  
				null, null, m_Instance, null);
		}
		else
		{
			m_Window = CreateWindowEx(null, Setting.name(), 
				Setting.title(),
				WS_OVERLAPPEDWINDOW | WS_VISIBLE,
				0, 0, 
				WindowRect.right - WindowRect.left, 
				WindowRect.bottom - WindowRect.top, 
				null, null, m_Instance, null);
		}

		// Show the final window on foreground
		ShowWindow(m_Window, SW_SHOW);
		SetForegroundWindow(m_Window);
		SetFocus(m_Window);
	}

	void base::_initScreen(const Setting& Setting)
	{
		//EnumDisplaySettings(null, ENUM_CURRENT_SETTINGS, &g_oldDevMode);

		int nMode = 0;
		DEVMODE DevMode;
		bool bDesiredDevModeFound = false;

		while(EnumDisplaySettings(null, nMode++, &DevMode))
		{
			if(DevMode.dmPelsWidth != Setting.width() || DevMode.dmPelsHeight != Setting.height())
				continue;
			if(DevMode.dmBitsPerPel != Setting.colorBuffer())
				continue;
			//if(DevMode.dmDisplayFrequency != Setting.vsync())
			//	continue;
			if(ChangeDisplaySettings(&DevMode, CDS_TEST) == DISP_CHANGE_SUCCESSFUL)
			{
				bDesiredDevModeFound = true;
				break;
			}
		}

		if(bDesiredDevModeFound == false)
			return;

		if(Setting.fullscreen())
			if(ChangeDisplaySettings(&DevMode, CDS_FULLSCREEN) != DISP_CHANGE_SUCCESSFUL)
				return;
	}
}
