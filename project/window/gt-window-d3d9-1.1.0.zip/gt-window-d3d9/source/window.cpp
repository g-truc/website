/*
    GT Window: Direct3D 9 Edition
    Copyright (C) 2006 G-Truc Creation (www.g-truc.net)

    Christophe [Groove] Riccio
    contact@g-truc.net
*/

#include "window.h"
#include "base.h"
#include "event.h"
#include "poll.h"
#include "resource.h"
#include <cstdlib>

namespace gtw
{
	LRESULT CALLBACK WindowProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

	Window::Window(const Setting& Setting)
	{
		gtw::base::instance()->create(Setting);
		gtw::pollWin32::instance();
	}

	Window::~Window()
	{
		gtw::pollWin32::destroy();
		gtw::base::destroy();
	}

	void Window::swap()
	{
		gtw::CWindowD3D::instance()->swap();
	}

	bool Window::poll()
	{
		return gtw::pollWin32::instance()->poll();
	}

	gtw::Event Window::event() const
	{
		return gtw::pollWin32::instance()->event();
	}

	gtw::Key Window::key()
	{
		return gtw::pollWin32::instance()->key();
	}

	gtw::Button Window::button()
	{
		return gtw::pollWin32::instance()->button();
	}

	void Window::resize(int& x, int& y)
	{
		gtw::pollWin32::instance()->resize(x, y);
	}

	void Window::motion(int& x, int& y)
	{
		gtw::pollWin32::instance()->motion(x, y);
	}

	double Window::time()
	{
		return gtw::base::instance()->time();
	}

	unsigned int Window::width() const
	{
		return gtw::base::instance()->width();
	}

	unsigned int Window::height() const
	{
		return gtw::base::instance()->height();
	}
}
