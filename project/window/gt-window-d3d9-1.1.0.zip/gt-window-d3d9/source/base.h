/*
    GT Window: Direct3D 9 Edition
    Copyright (C) 2006 G-Truc Creation (www.g-truc.net)

    Christophe [Groove] Riccio
    contact@g-truc.net
*/

#ifndef __GTW_BASE_H__
#define __GTW_BASE_H__

#include "../include/window_d3d9.h"
#include "timer.h"
#include "singleton.h"

namespace gtw
{
    class CWindowD3D : public singleton<CWindowD3D>
    {
        friend class singleton<CWindowD3D>;

    public:
        virtual void init(const Setting& Setting, HWND Window);
        virtual void swap();
        LPDIRECT3DDEVICE9 device() const;

    private:
        CWindowD3D();
        //CWindowD3D(const Setting& Setting);
        virtual ~CWindowD3D();

        D3DFORMAT _getDepthSentil(const Setting& Setting);

        LPDIRECT3D9 m_pD3d;
        LPDIRECT3DDEVICE9 m_pD3dDevice;
    };

    class base : public singleton<base>
    {
        friend class singleton<base>;

    public:
        base();
        ~base();

        void create(const Setting& Setting);
        double time();
        int width() const {return m_Width;}
        int height() const {return m_Height;}

    private:
        void _createWindow(const Setting& Setting);
        void _initScreen(const Setting& Setting);

        gtw::timer* m_Timer;
        HINSTANCE m_Instance;
        std::string m_Name;
        WNDCLASSEX m_WinClass;
        HWND m_Window;
        int m_Width;
        int m_Height;

    private:
        base(const base& Window);
        base& operator=(const base& Window);
    };
}

#endif
