/*
    GT Window: Direct3D 9 Edition
    Copyright (C) 2006 G-Truc Creation (www.g-truc.net)

    Christophe [Groove] Riccio
    contact@g-truc.net
*/

#include "../include/window_d3d9.h"

namespace gtw
{
	Setting::Setting() : 
		m_Name("Window"),
		m_Width(640),
		m_Height(480),
		m_VSync(VSYNC_DEFAULT),
		m_Fullscreen(false),
		m_DoubleBuffer(true),
		m_Color(32),
		m_Depth(16),
		m_Stencil(0),
		m_Samples(0),
		m_Cursor(true),
		m_Icon(0)
	{}

	const char* Setting::name() const{return m_Name.c_str();}
	const char* Setting::title() const{return m_Title.c_str();}
	unsigned short Setting::width() const{return m_Width;}
	unsigned short Setting::height() const{return m_Height;}
	//short Setting::vsync() const{return m_VSync;}
	bool Setting::fullscreen() const{return m_Fullscreen;}
	//bool Setting::doubleBuffer() const{return m_DoubleBuffer;}
	unsigned char Setting::colorBuffer() const{return m_Color;}
	unsigned char Setting::depthBuffer() const{return m_Depth;}
	unsigned char Setting::stencilBuffer() const{return m_Stencil;}
	//unsigned char Setting::sampleBuffer() const{return m_Samples;}
	bool Setting::cursor() const{return m_Cursor;}
	short Setting::icon() const{return m_Icon;}

	void Setting::name(const char* value){m_Name = value;}
	void Setting::title(const char* value){m_Title = value;}
	void Setting::width(unsigned short value){m_Width = value;}
	void Setting::height(unsigned short value){m_Height = value;}
	//void Setting::vsync(short value){m_VSync = value;}
	void Setting::fullscreen(bool value){m_Fullscreen = value;}
	//void Setting::doubleBuffer(bool value){m_DoubleBuffer = value;}
	void Setting::colorBuffer(unsigned char value){m_Color = value;}
	void Setting::depthBuffer(unsigned char value){m_Depth = value;}
	void Setting::stencilBuffer(unsigned char value){m_Stencil = value;}
	//void Setting::sampleBuffer(unsigned char value){m_Samples = value;}
	void Setting::cursor(bool value){m_Cursor = value;}
	void Setting::icon(short value){m_Icon = value;}
}
