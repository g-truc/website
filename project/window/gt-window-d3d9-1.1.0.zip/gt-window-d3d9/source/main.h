/*
    GT Window: Direct3D 9 Edition
    Copyright (C) 2006 G-Truc Creation (www.g-truc.net)

    Christophe [Groove] Riccio
    contact@g-truc.net
*/

#ifndef __MAIN_H__
#define __MAIN_H__

#endif //__MAIN_H__
