/*
    GT Window: Direct3D 9 Edition
    Copyright (C) 2006 G-Truc Creation (www.g-truc.net)

    Christophe [Groove] Riccio
    contact@g-truc.net
*/

#ifndef __GTW_TIMER_H__
#define __GTW_TIMER_H__

#include "../include/window_d3d9.h"

namespace gtw
{
	class timer
	{
	public:
		timer();
		double time();

	private:
		LARGE_INTEGER m_InitTime, m_TicksPerSecond;
	};
}

#endif//__GTW_TIMER_H__
