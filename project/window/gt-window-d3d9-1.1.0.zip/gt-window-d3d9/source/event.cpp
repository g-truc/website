/*
    GT Window: Direct3D 9 Edition
    Copyright (C) 2006 G-Truc Creation (www.g-truc.net)

    Christophe [Groove] Riccio
    contact@g-truc.net
*/

#include "event.h"

namespace gtw
{
	// eventKeyDown
	eventKeyDown::eventKeyDown(Key Key) : 
		m_Key(Key)
	{}

	Key eventKeyDown::value() const
	{
		return m_Key;
	}

	Event eventKeyDown::type() const
	{
		return KEY_PRESS;
	}

	// rventKeyUp
	eventKeyUp::eventKeyUp(Key Key) : 
		m_Key(Key)
	{}

	Key eventKeyUp::value() const
	{
		return m_Key;
	}

	Event eventKeyUp::type() const
	{
		return KEY_RELEASE;
	}

	// eventMouseButtonDown
	eventMouseButtonDown::eventMouseButtonDown(Button Button) : 
		m_Button(Button)
	{}

	Button eventMouseButtonDown::value() const 
	{
		return m_Button;
	}

	Event eventMouseButtonDown::type() const 
	{
		return BUTTON_PRESS;
	}

	// eventMouseButtonUp
	eventMouseButtonUp::eventMouseButtonUp(Button Button) : 
		m_Button(Button)
	{}

	Button eventMouseButtonUp::value() const 
	{
		return m_Button;
	}

	Event eventMouseButtonUp::type() const 
	{
		return BUTTON_RELEASE;
	}

	// eventMousePosition
	eventMousePosition::eventMousePosition(int x, int y) :
		x(x), y(y)
	{}

	void eventMousePosition::value(int& x, int& y) const
	{
		x = this->x; 
		y = this->y;
	}

	Event eventMousePosition::type() const 
	{
		return MOTION;
	}

	// eventResize
	eventResize::eventResize(int x, int y) : 
		x(x), y(y)
	{}

	void eventResize::value(int& x, int& y) const
	{
		x = this->x; 
		y = this->y;
	}

	Event eventResize::type() const
	{
		return RESIZE;
	}

	// eventQuit
	Event eventQuit::type() const
	{
		return QUIT;
	}
}
