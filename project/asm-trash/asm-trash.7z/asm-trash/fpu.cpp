#include "glm/glm.h"

using namespace glm;

namespace fpu
{
	float _float_add_ps(float x, float y)
	{
		__asm
		{
			fld		x
			fld		y
			fmul	st(0), st(1)
		}
	}

	double _double_add_ps(double x, double y)
	{
		__asm
		{
			fld		x
			fld		y
			fadd	st(0), st(1)
		}
	}

	double _double_sub_ps(double x, double y)
	{
		__asm
		{
			fld		x
			fld		y
			fsub	st(0), st(1)
		}
	}

	float _float_mad_ps(float x, float y, float z)
	{
		__asm
		{
			fld		x
			fld		y
			fld		z
			fmul	st(0), st(1)
			fadd	st(0), st(2)
		}
	}

	void sincos(float a, float &s, float &c) 
	{
		_asm 
		{
			fld		a
			fsincos
			mov		ecx, c
			mov		edx, s
			fstp	dword ptr [ecx]
			fstp	dword ptr [edx]
		}
	}

	void sincos(double a, double& s, double& c) 
	{
		_asm 
		{
			fld		a
			fsincos
			mov		ecx, c
			mov		edx, s
			fstp	qword ptr [ecx]
			fstp	qword ptr [edx]
		}
	}

	float sin(float s) 
	{
		float result = 0.0f;
		float* p = &result;
		_asm 
		{
			fld		s
			fsin	
			mov		ecx, p
			fstp	dword ptr [ecx]
		}
		return result;
	}

	float abs(float s) 
	{
		float result = 0.0f;
		float* p = &result;
		_asm 
		{
			fld		s
			fabs	
			mov		ecx, p
			fstp	dword ptr [ecx]
		}
		return result;

		//float result = 0.0f;
		//_asm 
		//{
		//	fld		s
		//	fsin	
		//	mov		ecx, result
		//	fstp	dword ptr [ecx]
		//}
		//return result;
	}

	float add(float s1, float s2)
	{
		float result = 0.0f;
		float* p = &result;
		_asm 
		{
			fld		s1
			fld		s2
			fadd	
			mov		ecx, p
			fstp	dword ptr [ecx]
		}
		return result;
	}

	float sub(float s1, float s2)
	{
		float result = 0.0f;
		float* p = &result;
		_asm 
		{
			fld		s1
			fld		s2
			fsub	
			mov		ecx, p
			fstp	dword ptr [ecx]
		}
		return result;
	}

	float mul(float s1, float s2)
	{
		float result = 0.0f;
		float* p = &result;
		_asm 
		{
			fld		s1
			fld		s2
			fmul	
			mov		ecx, p
			fstp	dword ptr [ecx]
		}
		return result;
	}

	float div(float s1, float s2)
	{
		float result = 0.0f;
		float* p = &result;
		_asm 
		{
			fld		s1
			fld		s2
			fdiv	
			mov		ecx, p
			fstp	dword ptr [ecx]
		}
		return result;
	}

	float __declspec(naked) __cdecl _naked_mad_ps(float x, float y, float z)
	{
		__asm
		{
			fmul	st(0), st(1)
			fadd	st(0), st(2)
			ret
		}
	}

	float _fpu_lerp(float x, float y, float a)
	{
		__asm
		{
			fld1					// 1
			fld		a				// a, 1
			fsubp	st(1), st(0)	// 1 - a
			fld		x				// x, 1 - a
			fmulp	st(1), st(0)	// x * (1 - a)
			fld		a				// a, x * (1 - a)
			fld		y				// y, a, x * (1 - a)
			fmulp	st(1), st(0)	// y * a, x * (1 - a)
			faddp	st(1), st(0)	// (y * a) + x * (1 - a)
		}
	}

	float _fpu_dot2(const vec4& x, const vec4& y)
	{
		__asm
		{
			mov			eax, dword ptr[x]
			mov			ebx, dword ptr[y]
			xor			ecx, ecx
			mov			edx, 4 // step and size
			fld			dword ptr[eax]
			fld			dword ptr[ebx]
			fmulp		st(1), st(0)

		while_loop:
			cmp			ecx, edx
			jnl			while_end
			inc			ecx
			add			eax, edx		
			add			ebx, edx
			fld			dword ptr[eax]
			fld			dword ptr[ebx]
			fmulp		st(1), st(0)
			faddp		st(1), st(0)
			jmp			while_loop
		while_end:
		}
	}

	float _fpu_dot(const vec4& x, const vec4& y)
	{
		__asm
		{
			mov			eax, dword ptr[x]
			mov			ebx, dword ptr[y]
			fld			dword ptr[eax+0]	// x.x
			fld			dword ptr[ebx+0]	// y.x, x.x
			fmulp		st(1), st(0)		// x.x * y.x
			fld			dword ptr[eax+4]	// x.y, x.x * y.x
			fld			dword ptr[ebx+4]	// y.y, x.y, x.x * y.x
			fmulp		st(1), st(0)		// x.y * y.y, x.x * y.x
			faddp		st(1), st(0)		// x.y * y.y + x.x * y.x
			fld			dword ptr[eax+8]	// x.z, x.y * y.y + x.x * y.x
			fld			dword ptr[ebx+8]	// y.z, x.z, x.y * y.y + x.x * y.x
			fmulp		st(1), st(0)		// x.z * y.z, x.y * y.y + x.x * y.x
			faddp		st(1), st(0)		// x.z * y.z + x.y * y.y + x.x * y.x
			fld			dword ptr[eax+12]	// x.w, x.z * y.z + x.y * y.y + x.x * y.x
			fld			dword ptr[ebx+12]	// y.w, x.w, x.z * y.z + x.y * y.y + x.x * y.x
			fmulp		st(1), st(0)		// y.w * x.w, x.z * y.z + x.y * y.y + x.x * y.x
			faddp		st(1), st(0)		// y.w * x.w + x.z * y.z + x.y * y.y + x.x * y.x
		}
	}
}
