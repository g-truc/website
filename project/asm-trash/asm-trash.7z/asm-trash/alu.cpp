#include "glm/glm.h"

using namespace glm;

int _inl_add_ps(int x, int y)
{
	__asm
	{
		mov		eax, x
		mov		ebx, y
		add		eax, ebx
	}
}

int _alu_dot2(const ivec4& x, const ivec4& y)
{
    __asm
	{
		mov			esi, dword ptr[x]
		mov			edi, dword ptr[y]
		xor			eax, eax
		mov			eax, [esi+0]
		imul		eax, [edi+0]
		mov			ebx, [esi+4]
		imul		ebx, [edi+4]
		add			eax, ebx
		mov			ebx, [esi+8]
		imul		ebx, [edi+8]
		add			eax, ebx
		mov			ebx, [esi+12]
		imul		ebx, [edi+12]
		add			eax, ebx
	}
}
