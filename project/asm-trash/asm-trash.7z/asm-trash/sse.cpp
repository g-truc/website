#include <xmmintrin.h>
#include <emmintrin.h>

__m128 __declspec(naked) __cdecl _asm_dot_ps(__m128, __m128)
{
	__asm
	{
		mulps	xmm0, xmm1
		movaps	xmm1, xmm0
		shufps	xmm0, xmm0, _MM_SHUFFLE(2, 3, 0, 1)
		addps	xmm0, xmm1
		movaps	xmm1, xmm0
		shufps	xmm0, xmm0, _MM_SHUFFLE(0, 1, 2, 3)
		addps	xmm0, xmm1
		ret
	}
}

__m128 __declspec(naked) __cdecl c_asm_dot_ps(__m128, __m128)
{
	__asm
	{
		call _asm_dot_ps
		ret
	}
}

__m128 __declspec(naked) __cdecl g_mm_add_ps(__m128, __m128)
{
	__asm
	{
		addps     xmm0, xmm1
		ret
	}
}

const __m128 _ps_1 = _mm_set_ps1(1.0f);

__m128 c_mm_lerp_ps(__m128 v1, __m128 v2, __m128 a)
{
	__m128 sub0 = _mm_sub_ps(_ps_1, a);
	__m128 mul0 = _mm_mul_ps(v1, sub0);
	__m128 mul1 = _mm_mul_ps(v2, a);
	__m128 add0 = _mm_add_ps(mul0, mul1);
	return add0;
}

__m128 _mm_dot_ps(__m128 v1, __m128 v2)
{
	__m128 mul0 = _mm_mul_ps(v1, v2);
	__m128 swp0 = _mm_shuffle_ps(mul0, mul0, _MM_SHUFFLE(2, 3, 0, 1));
	__m128 add0 = _mm_add_ps(mul0, swp0);
	__m128 swp1 = _mm_shuffle_ps(add0, add0, _MM_SHUFFLE(0, 1, 2, 3));
	__m128 add1 = _mm_add_ps(add0, swp1);
	return add1;
}
