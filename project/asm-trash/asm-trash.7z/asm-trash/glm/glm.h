///////////////////////////////////////////////////////////////////////////////////////////////////
// OpenGL Mathematics Copyright (c) 2005 - 2007 G-Truc Creation (www.g-truc.net)
///////////////////////////////////////////////////////////////////////////////////////////////////
// Created : 2005-01-14
// Updated : 2007-11-01
// Licence : This source is under GNU LGPL licence
// File    : glm/glm.h
///////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef __glm_glm__
#define __glm_glm__

#undef max
#undef min

#define GLMvalType typename genType::value_type
#define GLMcolType typename genType::col_type
#define GLMrowType typename genType::row_type

#define GLMsizeType typename genType::size_type
#define GLMrowSize typename genType::row_size
#define GLMcolSize typename genType::col_size

#define GLMvalSize typename genType::value_size

#include "./glmsetup.h"

#include "./core/_bvec2.inl"
#include "./core/_bvec3.inl"
#include "./core/_bvec4.inl"
#include "./core/_xvec2.inl"
#include "./core/_xvec3.inl"
#include "./core/_xvec4.inl"
#include "./core/_xmat2.inl"
#include "./core/_xmat3.inl"
#include "./core/_xmat4.inl"
#include "./core/_xmat2x3.inl"
#include "./core/_xmat2x4.inl"
#include "./core/_xmat3x2.inl"
#include "./core/_xmat3x4.inl"
#include "./core/_xmat4x2.inl"
#include "./core/_xmat4x3.inl"
#include "./core/_func.inl"
#include "./core/_swizzle.h"
#include "./core/_xref2.inl"
#include "./core/_xref3.inl"
#include "./core/_xref4.inl"

//! \brief OpenGL Mathematics namespace
namespace glm
{
    typedef _xvec2<float>   vec2;		//!< \brief Vector of 2 floating-point numbers. (From GLSL 1.10.59 specification)
    typedef _xvec2<int>     ivec2;		//!< \brief Vector of 2 integers. (From GLSL 1.10.59 specification)
    typedef _bvec2          bvec2;		//!< \brief Vector of 2 booleans. (From GLSL 1.10.59 specification)
    typedef _xvec3<float>   vec3;		//!< \brief Vector of 3 floating-point numbers. (From GLSL 1.10.59 specification)
    typedef _xvec3<int>     ivec3;		//!< \brief Vector of 3 integers. (From GLSL 1.10.59 specification)
    typedef _bvec3          bvec3;		//!< \brief Vector of 3 booleans. (From GLSL 1.10.59 specification)
    typedef _xvec4<float>   vec4;		//!< \brief Vector of 4 floating-point numbers. (From GLSL 1.10.59 specification)
    typedef _xvec4<int>     ivec4;		//!< \brief Vector of 4 integers. (From GLSL 1.10.59 specification)
    typedef _bvec4          bvec4;		//!< \brief Vector of 4 booleans. (From GLSL 1.10.59 specification)
    typedef _xmat2<float>   mat2;		//!< \brief 2 * 2 matrix of floating-point numbers. (From GLSL 1.10.59 specification)
    typedef _xmat3<float>   mat3;		//!< \brief 3 * 3 matrix of floating-point numbers. (From GLSL 1.10.59 specification)
    typedef _xmat4<float>   mat4;		//!< \brief 4 * 4 matrix of floating-point numbers. (From GLSL 1.10.59 specification)
    typedef _xmat2x3<float> mat2x3;		//!< \brief 2 * 3 matrix of floating-point numbers. (From GLSL 1.20.6 specification)
    typedef _xmat3x2<float> mat3x2;		//!< \brief 3 * 2 matrix of floating-point numbers. (From GLSL 1.20.6 specification)
    typedef _xmat2x4<float> mat2x4;		//!< \brief 2 * 4 matrix of floating-point numbers. (From GLSL 1.20.6 specification)
	typedef _xmat4x2<float> mat4x2;		//!< \brief 4 * 2 matrix of floating-point numbers. (From GLSL 1.20.6 specification)
	typedef _xmat3x4<float> mat3x4;		//!< \brief 3 * 4 matrix of floating-point numbers. (From GLSL 1.20.6 specification)
	typedef _xmat4x3<float> mat4x3;		//!< \brief 4 * 3 matrix of floating-point numbers. (From GLSL 1.20.6 specification)

	typedef const vec2& param_vec2;
	typedef const vec3& param_vec3;
	typedef const vec4& param_vec4;
	typedef const ivec2& param_ivec2;
	typedef const ivec3& param_ivec3;
	typedef const ivec4& param_ivec4;
	typedef const bvec2& param_bvec2;
	typedef const bvec3& param_bvec3;
	typedef const bvec4& param_bvec4;
	typedef const mat2& param_mat2;
	typedef const mat3& param_mat3;
	typedef const mat4& param_mat4;
	typedef const mat2x3& param_mat2x3;
	typedef const mat3x2& param_mat3x2;
	typedef const mat2x4& param_mat2x4;
	typedef const mat4x2& param_mat4x2;
	typedef const mat3x4& param_mat3x4;
	typedef const mat4x3& param_mat4x3;
} //namespace glm

#ifdef GLM_COMPILER_VC
#define GLM_DEPRECATED __declspec(deprecated)
#else
#define GLM_DEPRECATED
#endif//GLM_COMPILER_VC

#ifdef GLM_COMPILER_VC
#define GLM_RESTRICT __restrict
#else
#define GLM_RESTRICT
#endif//GLM_COMPILER_VC

#ifdef GLM_COMPILER_VC
#define GLM_ALIGN(x) __declspec(align(x))
#else
#define GLM_ALIGN(x)
#endif//GLM_COMPILER_VC

#endif //__glm_glm__
