///////////////////////////////////////////////////////////////////////////////////////////////////
// OpenGL Mathematics Copyright (c) 2005 - 2007 G-Truc Creation (www.g-truc.net)
///////////////////////////////////////////////////////////////////////////////////////////////////
// Created : 2007-02-21
// Updated : 2007-02-21
// Licence : This source is under GNU LGPL licence
// File    : glm/gtx/vecx.h
///////////////////////////////////////////////////////////////////////////////////////////////////
// Dependency:
// - GLM core
///////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef __glm_gtx_vecx__
#define __glm_gtx_vecx__

namespace glm
{
	template <int N>
    class _bvecxGTX
    {
	private:
		bool data[N];

	public:
		typedef bool value_type;
		typedef int size_type;
		static const size_type value_size;
		static const size_type col_size;
		static const size_type row_size;

        // Common constructors
	    _bvecxGTX();
        _bvecxGTX(const _bvecxGTX& v);

		// Accesses
        bool& operator[](int i);
        const bool operator[](int i) const;
        operator bool*();
	    operator const bool*() const;

        // Bool constructors
        explicit _bvecxGTX(const bool a);

        // Operators
        _bvecxGTX<N>& operator=(const _bvecxGTX<N>& v);
	    _bvecxGTX<N> operator! () const;
    };

    template <int N, typename T = float>
    class _xvecxGTX
    {
	private:
		T data[N];

	public:
		typedef T value_type;
		typedef int size_type;
		static const size_type value_size;

        // Common constructors
	    _xvecxGTX();
        _xvecxGTX(const _xvecxGTX<N, T>& v);

		// Accesses
        T& operator[](int i);
        const T operator[](int i) const;
        operator T*();
	    operator const T*() const;

        // T constructors
        explicit _xvecxGTX(const T x);

        // Unary updatable operators
        _xvecxGTX<N, T>& operator= (const _xvecxGTX<N, T>& v);
	    _xvecxGTX<N, T>& operator+=(const T s);
	    _xvecxGTX<N, T>& operator+=(const _xvecxGTX<N, T>& v);
	    _xvecxGTX<N, T>& operator-=(const T s);
	    _xvecxGTX<N, T>& operator-=(const _xvecxGTX<N, T>& v);
	    _xvecxGTX<N, T>& operator*=(const T s);
	    _xvecxGTX<N, T>& operator*=(const _xvecxGTX<N, T>& v);
	    _xvecxGTX<N, T>& operator/=(const T s);
	    _xvecxGTX<N, T>& operator/=(const _xvecxGTX<N, T>& v);
	    _xvecxGTX<N, T>& operator++();
        _xvecxGTX<N, T>& operator--();
    };

    // Binary operators
    template <int N, typename T>
	_xvecxGTX<N, T> operator+ (const _xvecxGTX<N, T>& v, const T s);

    template <int N, typename T>
    _xvecxGTX<N, T> operator+ (const T s, const _xvecxGTX<N, T>& v);

    template <int N, typename T>
    _xvecxGTX<N, T> operator+ (const _xvecxGTX<N, T>& v1, const _xvecxGTX<N, T>& v2);
    
    template <int N, typename T>
	_xvecxGTX<N, T> operator- (const _xvecxGTX<N, T>& v, const T s);

    template <int N, typename T>
    _xvecxGTX<N, T> operator- (const T s, const _xvecxGTX<N, T>& v);

    template <int N, typename T>
    _xvecxGTX<N, T> operator- (const _xvecxGTX<N, T>& v1, const _xvecxGTX<N, T>& v2);

    template <int N, typename T>
    _xvecxGTX<N, T> operator* (const _xvecxGTX<N, T>& v, const T s);

    template <int N, typename T>
    _xvecxGTX<N, T> operator* (const T s, const _xvecxGTX<N, T>& v);

    template <int N, typename T>
    _xvecxGTX<N, T> operator* (const _xvecxGTX<N, T>& v1, const _xvecxGTX<N, T>& v2);

    template <int N, typename T>
    _xvecxGTX<N, T> operator/ (const _xvecxGTX<N, T>& v, const T s);

    template <int N, typename T>
    _xvecxGTX<N, T> operator/ (const T s, const _xvecxGTX<N, T>& v);

    template <int N, typename T>
    _xvecxGTX<N, T> operator/ (const _xvecxGTX<N, T>& v1, const _xvecxGTX<N, T>& v2);

    // Unary constant operators
    template <int N, typename T>
    const _xvecxGTX<N, T> operator- (const _xvecxGTX<N, T>& v);

    template <int N, typename T>
    const _xvecxGTX<N, T> operator-- (const _xvecxGTX<N, T>& v, int);

    template <int N, typename T>
    const _xvecxGTX<N, T> operator++ (const _xvecxGTX<N, T>& v, int);

	// Trigonometric Functions
	template <int N, typename T> const _xvecxGTX<N, T> radians(const _xvecxGTX<N, T>& degrees);
	template <int N, typename T> const _xvecxGTX<N, T> degrees(const _xvecxGTX<N, T>& radians);
	template <int N, typename T> const _xvecxGTX<N, T> sin(const _xvecxGTX<N, T>& angle);
	template <int N, typename T> const _xvecxGTX<N, T> cos(const _xvecxGTX<N, T>& angle);
	template <int N, typename T> const _xvecxGTX<N, T> tan(const _xvecxGTX<N, T>& angle);
	template <int N, typename T> const _xvecxGTX<N, T> asin(const _xvecxGTX<N, T>& x);
	template <int N, typename T> const _xvecxGTX<N, T> acos(const _xvecxGTX<N, T>& x);
	template <int N, typename T> const _xvecxGTX<N, T> atan(const _xvecxGTX<N, T>& y, const _xvecxGTX<N, T>& x);
	template <int N, typename T> const _xvecxGTX<N, T> atan(const _xvecxGTX<N, T>& y_over_x); 

	// Exponential Functions
	template <int N, typename T> const _xvecxGTX<N, T> pow(const _xvecxGTX<N, T>& x, const _xvecxGTX<N, T>& y);
	template <int N, typename T> const _xvecxGTX<N, T> exp(const _xvecxGTX<N, T>& x);
	template <int N, typename T> const _xvecxGTX<N, T> log(const _xvecxGTX<N, T>& x);
	template <int N, typename T> const _xvecxGTX<N, T> exp2(const _xvecxGTX<N, T>& x);
	template <int N, typename T> const _xvecxGTX<N, T> log2(const _xvecxGTX<N, T>& x);
	template <int N, typename T> const _xvecxGTX<N, T> sqrt(const _xvecxGTX<N, T>& x);
	template <int N, typename T> const _xvecxGTX<N, T> inversesqrt(const _xvecxGTX<N, T>& x);

	// Common Functions
	template <int N, typename T> const _xvecxGTX<N, T> abs(const _xvecxGTX<N, T>& x);
	template <int N, typename T> const _xvecxGTX<N, T> sign(const _xvecxGTX<N, T>& x);
	template <int N, typename T> const _xvecxGTX<N, T> floor(const _xvecxGTX<N, T>& x);
	template <int N, typename T> const _xvecxGTX<N, T> ceil(const _xvecxGTX<N, T>& x);
	template <int N, typename T> const _xvecxGTX<N, T> fract(const _xvecxGTX<N, T>& x);
	template <int N, typename T> const _xvecxGTX<N, T> mod(const _xvecxGTX<N, T>& x, T y);
	template <int N, typename T> const _xvecxGTX<N, T> mod(const _xvecxGTX<N, T>& x, const _xvecxGTX<N, T>& y);
	template <int N, typename T> const _xvecxGTX<N, T> min(const _xvecxGTX<N, T>& x, T y);
	template <int N, typename T> const _xvecxGTX<N, T> min(const _xvecxGTX<N, T>& x, const _xvecxGTX<N, T>& y);
	template <int N, typename T> const _xvecxGTX<N, T> max(const _xvecxGTX<N, T>& x, T y);
	template <int N, typename T> const _xvecxGTX<N, T> max(const _xvecxGTX<N, T>& x, const _xvecxGTX<N, T>& y);
	template <int N, typename T> const _xvecxGTX<N, T> clamp(const _xvecxGTX<N, T>& x, T minVal, T maxVal);
	template <int N, typename T> const _xvecxGTX<N, T> clamp(const _xvecxGTX<N, T>& x, const _xvecxGTX<N, T>& minVal, const _xvecxGTX<N, T>& maxVal);
	template <int N, typename T> const _xvecxGTX<N, T> step(T edge, const _xvecxGTX<N, T>& x);
	template <int N, typename T> const _xvecxGTX<N, T> step(const _xvecxGTX<N, T>& edge, const _xvecxGTX<N, T>& x);
	template <int N, typename T> const _xvecxGTX<N, T> smoothstep(T edge0, T edge1, const _xvecxGTX<N, T>& x);
	template <int N, typename T> const _xvecxGTX<N, T> smoothstep(const _xvecxGTX<N, T>& edge0, const _xvecxGTX<N, T>& edge1, const _xvecxGTX<N, T>& x);

	// Geometric Functions
	template <int N, typename T> const T length(const _xvecxGTX<N, T>& x);
	template <int N, typename T> const T distance(const _xvecxGTX<N, T>& p0, const _xvecxGTX<N, T>& p1);
	template <int N, typename T> const T dot(const _xvecxGTX<N, T>& x, const _xvecxGTX<N, T>& y);
	template <int N, typename T> const _xvecxGTX<N, T> normalize(const _xvecxGTX<N, T>& x); 
	template <int N, typename T> const _xvecxGTX<N, T> faceforward(const _xvecxGTX<N, T>& Norm, const _xvecxGTX<N, T>& I, const _xvecxGTX<N, T>& Nref);
	template <int N, typename T> const _xvecxGTX<N, T> reflect(const _xvecxGTX<N, T>& I, const _xvecxGTX<N, T>& N);
	template <int N, typename T> const _xvecxGTX<N, T> refract(const _xvecxGTX<N, T>& I, const _xvecxGTX<N, T>& N, T eta);

	// Vector Relational Functions
	template <int N, typename T> const _bvecxGTX<N> lessThan(const _xvecxGTX<N, T>& x, const _xvecxGTX<N, T>& y);
	template <int N, typename T> const _bvecxGTX<N> lessThanEqual(const _xvecxGTX<N, T>& x, const _xvecxGTX<N, T>& y);
	template <int N, typename T> const _bvecxGTX<N> greaterThan(const _xvecxGTX<N, T>& x, const _xvecxGTX<N, T>& y);
	template <int N, typename T> const _bvecxGTX<N> greaterThanEqual(const _xvecxGTX<N, T>& x, const _xvecxGTX<N, T>& y);
	template <int N> const _bvecxGTX<N> equal(const _bvecxGTX<N>& x, const _bvecxGTX<N>& y);
	template <int N, typename T> const _bvecxGTX<N> equal(const _xvecxGTX<N, T>& x, const _xvecxGTX<N, T>& y);
	template <int N> const _bvecxGTX<N> notEqual(const _bvecxGTX<N>& x, const _bvecxGTX<N>& y);
	template <int N, typename T> const _bvecxGTX<N> notEqual(const _xvecxGTX<N, T>& x, const _xvecxGTX<N, T>& y);
	template <int N> const bool any(const _bvecxGTX<N>& x);
	template <int N> const bool all(const _bvecxGTX<N>& x);
#ifdef _MSC_VER // VC compiler doesn't support the C++ key word 'not'
    template <int N> const _bvecxGTX<N> not(const _bvecxGTX<N>& v); //!< \brief Returns the component-wise logical complement of x. (From GLSL 1.10.59 specification)
#endif
#ifdef __GNUC__ // GCC
    template <int N> const _bvecxGTX<N> operator not(const _bvecxGTX<N>& v); //!< \brief Returns the component-wise logical complement of x. (From GLSL 1.10.59 specification)
#endif

    namespace gtx
    {
        namespace vecx
        {

        }
    }
}

#define GLM_GTX_vecx namespace gtx::vecx

#include "vecx.inl"

#ifdef GLM_GTX_INCLUDED
namespace glm{using GLM_GTX_vecx;}
#endif//GLM_GTX_INCLUDED

#endif//__glm_gtx_vecx__
