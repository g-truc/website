///////////////////////////////////////////////////////////////////////////////////////////////////
// OpenGL Mathematics Copyright (c) 2005 - 2007 G-Truc Creation (www.g-truc.net)
///////////////////////////////////////////////////////////////////////////////////////////////////
// Created : 2005-12-30
// Updated : 2006-11-13
// Licence : This source is under GNU LGPL licence
// File    : glm/gtx/closest_point.h
///////////////////////////////////////////////////////////////////////////////////////////////////
// Dependency:
// - GLM core
///////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef __glm_gtx_closest_point__
#define __glm_gtx_closest_point__

// Dependency:
#include "../../glm.h"

namespace glm
{
	//! Finds the position on straight line (A, B) witch is the closest of point. (from GLM_GTX_closest_point extension) 
    template <typename T> 
	_xvec3<T> closestPointOnLineGTX(
		const _xvec3<T>& point, 
		const _xvec3<T>& a, 
		const _xvec3<T>& b); 

	namespace gtx
	{
		namespace closest_point
		{
			//! Finds the position on straight line (A, B) witch is the closest of point. (from GLM_GTX_closest_point extension) 		
			template <typename T> 
			inline _xvec3<T> closestPointOnLine(
				const _xvec3<T>& point, 
				const _xvec3<T>& a, 
				const _xvec3<T>& b)
			{
				return closestPointOnLineGTX(point, a, b);
			}
		}
	}
}

#define GLM_GTX_closest_point namespace gtx::closest_point

#include "closest_point.inl"

#ifdef GLM_GTX_INCLUDED
namespace glm{using GLM_GTX_closest_point;}
#endif//GLM_GTX_INCLUDED

#endif//__glm_gtx_closest_point__
