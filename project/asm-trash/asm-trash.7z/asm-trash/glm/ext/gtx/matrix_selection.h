///////////////////////////////////////////////////////////////////////////////////////////////////
// OpenGL Mathematics Copyright (c) 2005 - 2007 G-Truc Creation (www.g-truc.net)
///////////////////////////////////////////////////////////////////////////////////////////////////
// Created : 2005-12-21
// Updated : 2006-11-13
// Licence : This source is under GNU LGPL licence
// File    : glm/gtx/matrix_selection.h
///////////////////////////////////////////////////////////////////////////////////////////////////
// Dependency:
// - GLM core
///////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef __glm_gtx_matrix_selection__
#define __glm_gtx_matrix_selection__

// Dependency:
#include "../../glm.h"

namespace glm
{
	template <typename genType> GLMrowType rowGTX(const genType& m, int index);        //!< \brief Returns a vector that contains the row of the matrix m witch values is the ones of the row index (from GLM_GTX_matrix_selection extension)
	template <typename genType> GLMcolType columnGTX(const genType& m, int index);     //!< \brief Returns a vector that contains the column of the matrix m witch values is the ones of the column index (from GLM_GTX_matrix_selection extension)
/*
    template <typename T> _xvec2<T> rowGTX(const _xmat2<T>& m, int index); //!< \brief Returns a 2 components vector that contains the row of the matrix m witch values is the ones of the row index (from GLM_GTX_matrix_selection extension)
    template <typename T> _xvec3<T> rowGTX(const _xmat3<T>& m, int index); //!< \brief Returns a 3 components vector that contains the row of the matrix m witch values is the ones of the row index (from GLM_GTX_matrix_selection extension)
    template <typename T> _xvec4<T> rowGTX(const _xmat4<T>& m, int index); //!< \brief Returns a 4 components vector that contains the row of the matrix m witch values is the ones of the row index (from GLM_GTX_matrix_selection extension)
    template <typename T> _xvec2<T> columnGTX(const _xmat2<T>& m, int index); //!< \brief Returns a 2 components vector that contains the row of the matrix m witch values is the ones of the column index (from GLM_GTX_matrix_selection extension)
    template <typename T> _xvec3<T> columnGTX(const _xmat3<T>& m, int index); //!< \brief Returns a 3 components vector that contains the row of the matrix m witch values is the ones of the column index (from GLM_GTX_matrix_selection extension)
    template <typename T> _xvec4<T> columnGTX(const _xmat4<T>& m, int index); //!< \brief Returns a 4 components vector that contains the row of the matrix m witch values is the ones of the column index (from GLM_GTX_matrix_selection extension)
*/
    namespace gtx
    {
        namespace matrix_selection
        {
	        template <typename genType> inline GLMrowType row(const genType& m, int index){return rowGTX(m, index);}           //!< \brief Returns a vector that contains the row of the matrix m witch values is the ones of the row index (from GLM_GTX_matrix_selection extension)
	        template <typename genType> inline GLMcolType column(const genType& m, int index){return columnGTX(m, index);}     //!< \brief Returns a vector that contains the column of the matrix m witch values is the ones of the column index (from GLM_GTX_matrix_selection extension)
        /*
            template <typename T> _xvec2<T> row(const _xmat2<T>& m, int index){return rowGTX(m, index);}
            template <typename T> _xvec3<T> row(const _xmat3<T>& m, int index){return rowGTX(m, index);}
            template <typename T> _xvec4<T> row(const _xmat4<T>& m, int index){return rowGTX(m, index);}
            template <typename T> _xvec2<T> column(const _xmat2<T>& m, int index){return columnGTX(m, index);}
            template <typename T> _xvec3<T> column(const _xmat3<T>& m, int index){return columnGTX(m, index);}
            template <typename T> _xvec4<T> column(const _xmat4<T>& m, int index){return columnGTX(m, index);}
        */
        }
    }
}

#define GLM_GTX_matrix_selection namespace gtx::matrix_selection

#include "matrix_selection.inl"

#ifdef GLM_GTX_INCLUDED
namespace glm{using GLM_GTX_matrix_selection;}
#endif//GLM_GTX_INCLUDED

#endif//__glm_gtx_matrix_selection__
