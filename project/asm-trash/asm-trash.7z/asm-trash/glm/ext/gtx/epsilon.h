///////////////////////////////////////////////////////////////////////////////////////////////////
// OpenGL Mathematics Copyright (c) 2005 - 2007 G-Truc Creation (www.g-truc.net)
///////////////////////////////////////////////////////////////////////////////////////////////////
// Created : 2005-12-21
// Updated : 2006-11-13
// Licence : This source is under GNU LGPL licence
// File    : glm/gtx/epsilon.h
///////////////////////////////////////////////////////////////////////////////////////////////////
// Dependency:
// - GLM core
// - GLM_GTX_double
// - GLM_GTX_half
///////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef __glm_gtx_epsilon__
#define __glm_gtx_epsilon__

// Dependency:
#include "../../glm.h"
#include "../gtx/double.h"
#include "../gtx/half.h"

namespace glm
{
    template <typename T> bool equalEpsilonGTX(const T x, const T y, const T epsilon); //!< \brief Returns the component-wise compare of |x - y| < epsilon (from GLM_GTX_epsilon extension)
    template <typename T> bool notEqualEpsilonGTX(const T x, const T y, const T epsilon); //!< \brief Returns the component-wise compare of |x - y| >= epsilon (from GLM_GTX_epsilon extension)

    template <typename T> _bvec2 equalEpsilonGTX(const _xvec2<T>& x, const _xvec2<T>& y, const T epsilon); //!< \brief Returns the component-wise compare of |x - y| < epsilon (from GLM_GTX_epsilon extension)
    template <typename T> _bvec3 equalEpsilonGTX(const _xvec3<T>& x, const _xvec3<T>& y, const T epsilon); //!< \brief Returns the component-wise compare of |x - y| < epsilon (from GLM_GTX_epsilon extension)
    template <typename T> _bvec4 equalEpsilonGTX(const _xvec4<T>& x, const _xvec4<T>& y, const T epsilon); //!< \brief Returns the component-wise compare of |x - y| < epsilon (from GLM_GTX_epsilon extension)
    template <typename T> _bvec2 notEqualEpsilonGTX(const _xvec2<T>& x, const _xvec2<T>& y, const T epsilon); //!< \brief Returns the component-wise compare of |x - y| >= epsilon (from GLM_GTX_epsilon extension)
    template <typename T> _bvec3 notEqualEpsilonGTX(const _xvec3<T>& x, const _xvec3<T>& y, const T epsilon); //!< \brief Returns the component-wise compare of |x - y| >= epsilon (from GLM_GTX_epsilon extension)
    template <typename T> _bvec4 notEqualEpsilonGTX(const _xvec4<T>& x, const _xvec4<T>& y, const T epsilon); //!< \brief Returns the component-wise compare of |x - y| >= epsilon (from GLM_GTX_epsilon extension)

    template <typename T> _bvec2 equalEpsilonGTX(const _xvec2<T>& x, const _xvec2<T>& y, const _xvec2<T>& epsilon); //!< \brief Returns the component-wise compare of |x - y| < epsilon (from GLM_GTX_epsilon extension)
    template <typename T> _bvec3 equalEpsilonGTX(const _xvec3<T>& x, const _xvec3<T>& y, const _xvec3<T>& epsilon); //!< \brief Returns the component-wise compare of |x - y| < epsilon (from GLM_GTX_epsilon extension)
    template <typename T> _bvec4 equalEpsilonGTX(const _xvec4<T>& x, const _xvec4<T>& y, const _xvec4<T>& epsilon); //!< \brief Returns the component-wise compare of |x - y| < epsilon (from GLM_GTX_epsilon extension)
    template <typename T> _bvec2 notEqualEpsilonGTX(const _xvec2<T>& x, const _xvec2<T>& y, const _xvec2<T>& epsilon); //!< \brief Returns the component-wise compare of |x - y| >= epsilon (from GLM_GTX_epsilon extension)
    template <typename T> _bvec3 notEqualEpsilonGTX(const _xvec3<T>& x, const _xvec3<T>& y, const _xvec3<T>& epsilon); //!< \brief Returns the component-wise compare of |x - y| >= epsilon (from GLM_GTX_epsilon extension)
    template <typename T> _bvec4 notEqualEpsilonGTX(const _xvec4<T>& x, const _xvec4<T>& y, const _xvec4<T>& epsilon); //!< \brief Returns the component-wise compare of |x - y| >= epsilon (from GLM_GTX_epsilon extension)
/*
	template <typename T>
	class epsilonGTX
	{
	public:
		epsilonGTX() : value(std::EPSILON){}
		epsilonGTX(const T& value) : value(value){}

	private:
		T value;
	};
*/
	namespace gtx
	{
		namespace epsilon
		{
			template <typename T> inline bool equalEpsilon(const T x, const T y, const T epsilon){return equalEpsilonGTX(x, y, epsilon);}
			template <typename T> inline bool notEqualEpsilon(const T x, const T y, const T epsilon){return notEqualEpsilonGTX(x, y, epsilon);}

			template <typename T> inline _bvec2 equalEpsilon(const _xvec2<T>& x, const _xvec2<T>& y, const T epsilon){return equalEpsilonGTX(x, y, epsilon);}
			template <typename T> inline _bvec3 equalEpsilon(const _xvec3<T>& x, const _xvec3<T>& y, const T epsilon){return equalEpsilonGTX(x, y, epsilon);}
			template <typename T> inline _bvec4 equalEpsilon(const _xvec4<T>& x, const _xvec4<T>& y, const T epsilon){return equalEpsilonGTX(x, y, epsilon);}
			template <typename T> inline _bvec2 notEqualEpsilon(const _xvec2<T>& x, const _xvec2<T>& y, const T epsilon){return notEqualEpsilonGTX(x, y, epsilon);}
			template <typename T> inline _bvec3 notEqualEpsilon(const _xvec3<T>& x, const _xvec3<T>& y, const T epsilon){return notEqualEpsilonGTX(x, y, epsilon);}
			template <typename T> inline _bvec4 notEqualEpsilon(const _xvec4<T>& x, const _xvec4<T>& y, const T epsilon){return notEqualEpsilonGTX(x, y, epsilon);}

			template <typename T> inline _bvec2 equalEpsilon(const _xvec2<T>& x, const _xvec2<T>& y, const _xvec2<T>& epsilon){return equalEpsilonGTX(x, y, epsilon);}
			template <typename T> inline _bvec3 equalEpsilon(const _xvec3<T>& x, const _xvec3<T>& y, const _xvec3<T>& epsilon){return equalEpsilonGTX(x, y, epsilon);}
			template <typename T> inline _bvec4 equalEpsilon(const _xvec4<T>& x, const _xvec4<T>& y, const _xvec4<T>& epsilon){return equalEpsilonGTX(x, y, epsilon);}
			template <typename T> inline _bvec2 notEqualEpsilon(const _xvec2<T>& x, const _xvec2<T>& y, const _xvec2<T>& epsilon){return notEqualEpsilonGTX(x, y, epsilon);}
			template <typename T> inline _bvec3 notEqualEpsilon(const _xvec3<T>& x, const _xvec3<T>& y, const _xvec3<T>& epsilon){return notEqualEpsilonGTX(x, y, epsilon);}
			template <typename T> inline _bvec4 notEqualEpsilon(const _xvec4<T>& x, const _xvec4<T>& y, const _xvec4<T>& epsilon){return notEqualEpsilonGTX(x, y, epsilon);}
		}
	}
}

#define GLM_GTX_epsilon namespace gtx::epsilon

#include "epsilon.inl"

#ifdef GLM_GTX_INCLUDED
namespace glm{using GLM_GTX_epsilon;}
#endif//GLM_GTX_INCLUDED

#endif//__glm_gtx_epsilon__
