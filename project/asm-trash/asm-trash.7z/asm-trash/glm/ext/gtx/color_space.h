///////////////////////////////////////////////////////////////////////////////////////////////////
// OpenGL Mathematics Copyright (c) 2005 - 2007 G-Truc Creation (www.g-truc.net)
///////////////////////////////////////////////////////////////////////////////////////////////////
// Created : 2005-12-21
// Updated : 2007-02-22
// Licence : This source is under GNU LGPL licence
// File    : glm/gtx/color_space.h
///////////////////////////////////////////////////////////////////////////////////////////////////
// Dependency:
// - GLM core
///////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef __glm_gtx_color_space__
#define __glm_gtx_color_space__

// Dependency:
#include "../../glm.h"

namespace glm
{
    template <typename T> _xvec3<T> rgbGTX(const _xvec3<T>& hsv); //!< \brief Converts a color from HSV color space to its color in RGB color space (from GLM_GTX_color_space extension)
    template <typename T> _xvec3<T> hsvGTX(const _xvec3<T>& rgb); //!< \brief Converts a color from RGB color space to its color in HSV color space (from GLM_GTX_color_space extension)
	template <typename T> _xmat4<T> saturationGTX(const T s); //!< Build a saturation matrix (from GLM_GTX_color_space extension)
	template <typename T> _xvec3<T> saturationGTX(const T s, const _xvec3<T>& color); //!< Modify the saturation of a color (from GLM_GTX_color_space extension)
	template <typename T> _xvec4<T> saturationGTX(const T s, const _xvec4<T>& color); //!< Modify the saturation of a color (from GLM_GTX_color_space extension)
	template <typename T> T luminosityGTX(const _xvec3<T>& cColor);

    namespace gtx
    {
        namespace color_space
        {
            template <typename T> inline _xvec3<T> rgb(const _xvec3<T>& hsv){return rgbGTX(hsv);} //!< \brief Converts a color from HSV color space to its color in RGB color space (from GLM_GTX_color_space extension)
            template <typename T> inline _xvec3<T> hsv(const _xvec3<T>& rgb){return hsvGTX(rgb);} //!< \brief Converts a color from RGB color space to its color in HSV color space (from GLM_GTX_color_space extension)
	        template <typename T> inline _xmat4<T> saturation(const T s){return saturationGTX(s);} //!< Build a saturation matrix (from GLM_GTX_color_space extension)
	        template <typename T> inline _xvec3<T> saturation(const T s, const _xvec3<T>& color){return saturationGTX(s, color);} //!< Modify the saturation of a color (from GLM_GTX_color_space extension)
	        template <typename T> inline _xvec4<T> saturation(const T s, const _xvec4<T>& color){return saturationGTX(s, color);} //!< Modify the saturation of a color (from GLM_GTX_color_space extension)
			template <typename T> inline T luminosity(const _xvec3<T>& color){return luminosityGTX(color);}
        }
    }
}

#define GLM_GTX_color_space namespace gtx::color_space

#include "color_space.inl"

#ifdef GLM_GTX_INCLUDED
namespace glm{using GLM_GTX_color_space;}
#endif//GLM_GTX_INCLUDED

#endif//__glm_gtx_color_space__
