///////////////////////////////////////////////////////////////////////////////////////////////////
// OpenGL Mathematics Copyright (c) 2005 - 2007 G-Truc Creation (www.g-truc.net)
///////////////////////////////////////////////////////////////////////////////////////////////////
// Created : 2005-12-27
// Updated : 2006-12-06
// Licence : This source is under GNU LGPL licence
// File    : glm/gtx/matrix_access.h
///////////////////////////////////////////////////////////////////////////////////////////////////
// Dependency:
// - GLM core
///////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef __glm_gtx_matrix_access__
#define __glm_gtx_matrix_access__

// Dependency:
#include "../../glm.h"

namespace glm
{
	template <typename genType> genType rowGTX(const genType& m, int index, const GLMrowType& x); //!< Set a specific row to a matrix (From GLM_GTX_matrix_access extension)
	template <typename genType> genType columnGTX(const genType& m, int index, const GLMcolType& x); //!< Set a specific column to a matrix (From GLM_GTX_matrix_access extension)
/*
    template <typename T> _xmat2<T> rowGTX(const _xmat2<T> & m, int index, const _xvec2<T>& x);
    template <typename T> _xmat3<T> rowGTX(const _xmat3<T> & m, int index, const _xvec3<T>& x);
    template <typename T> _xmat4<T> rowGTX(const _xmat4<T> & m, int index, const _xvec4<T>& x);
    template <typename T> _xmat2<T> columnGTX(const _xmat2<T> & m, int index, const _xvec2<T>& x);
    template <typename T> _xmat3<T> columnGTX(const _xmat3<T> & m, int index, const _xvec3<T>& x);
    template <typename T> _xmat4<T> columnGTX(const _xmat4<T> & m, int index, const _xvec4<T>& x);
*/

    namespace gtx
    {
        namespace matrix_access
        {
	        template <typename genType> inline genType row(const genType& m, int index, const GLMrowType& x){return rowGTX(m, index, x);} //!< Set a specific row to a matrix (From GLM_GTX_matrix_access extension)
	        template <typename genType> inline genType column(const genType& m, int index, const GLMcolType& x){return columnGTX(m, index, x);} //!< Set a specific column to a matrix (From GLM_GTX_matrix_access extension)
        /*
            template <typename T> _xmat2<T> row(const _xmat2<T> & m, int index, const _xvec2<T>& x){return rowGTX(m, index, x);}
            template <typename T> _xmat3<T> row(const _xmat3<T> & m, int index, const _xvec3<T>& x){return rowGTX(m, index, x);}
            template <typename T> _xmat4<T> row(const _xmat4<T> & m, int index, const _xvec4<T>& x){return rowGTX(m, index, x);}
            template <typename T> _xmat2<T> column(const _xmat2<T> & m, int index, const _xvec2<T>& x){return columnGTX(m, index, x);}
            template <typename T> _xmat3<T> column(const _xmat3<T> & m, int index, const _xvec3<T>& x){return columnGTX(m, index, x);}
            template <typename T> _xmat4<T> column(const _xmat4<T> & m, int index, const _xvec4<T>& x){return columnGTX(m, index, x);}
        */
        }
    }    
}

#define GLM_GTX_matrix_access namespace gtx::matrix_access

#include "matrix_access.inl"

#ifdef GLM_GTX_INCLUDED
namespace glm{using GLM_GTX_matrix_access;}
#endif//GLM_GTX_INCLUDED

#endif//__glm_gtx_matrix_access__
