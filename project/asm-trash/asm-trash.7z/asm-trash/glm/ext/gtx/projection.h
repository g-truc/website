///////////////////////////////////////////////////////////////////////////////////////////////////
// OpenGL Mathematics Copyright (c) 2005 - 2007 G-Truc Creation (www.g-truc.net)
///////////////////////////////////////////////////////////////////////////////////////////////////
// Created : 2005-12-21
// Updated : 2006-11-13
// Licence : This source is under GNU LGPL licence
// File    : glm/gtx/projection.h
///////////////////////////////////////////////////////////////////////////////////////////////////
// Dependency:
// - GLM core
///////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef __glm_gtx_projection__
#define __glm_gtx_projection__

// Dependency:
#include "../../glm.h"

namespace glm
{
    template <typename T> _xvec2<T> projGTX(const _xvec2<T>& x, const _xvec2<T>& Normal); //!< \brief Projects x on Normal (from GLM_GTX_projection extension)
    template <typename T> _xvec3<T> projGTX(const _xvec3<T>& x, const _xvec3<T>& Normal); //!< \brief Projects x on Normal (from GLM_GTX_projection extension)
    template <typename T> _xvec4<T> projGTX(const _xvec4<T>& x, const _xvec4<T>& Normal); //!< \brief Projects x on Normal (from GLM_GTX_projection extension)

    namespace gtx
    {
        namespace projection
        {
            template <typename T> inline _xvec2<T> proj(const _xvec2<T>& x, const _xvec2<T>& Normal){return projGTX(x, Normal);} //!< \brief Projects x on Normal (from GLM_GTX_projection extension)
            template <typename T> inline _xvec3<T> proj(const _xvec3<T>& x, const _xvec3<T>& Normal){return projGTX(x, Normal);} //!< \brief Projects x on Normal (from GLM_GTX_projection extension)
            template <typename T> inline _xvec4<T> proj(const _xvec4<T>& x, const _xvec4<T>& Normal){return projGTX(x, Normal);} //!< \brief Projects x on Normal (from GLM_GTX_projection extension)
        }
    }
}

#define GLM_GTX_projection namespace gtx::projection

#include "projection.inl"

#ifdef GLM_GTX_INCLUDED
namespace glm{using GLM_GTX_projection;}
#endif//GLM_GTX_INCLUDED

#endif//__glm_gtx_projection__
