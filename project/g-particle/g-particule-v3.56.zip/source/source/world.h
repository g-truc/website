/***********************************************\
	G-Particule : v3.56
	Copyright (c) 2003, G-Truc Creation.		
*************************************************
	G-Truc Creation, www.g-truc.net				
	par Groove, groove@g-truc.net				
*************************************************
	world.h, 15/02/2003
\***********************************************/

#ifndef __WORLD_H__
#define __WORLD_H__

#include "meca.h"
#include "gl_rendu.h"

class CWorld
{
private:
	CMeca Meca;
	CRenduGL Rendu;
public:
	CWorld (int argc, char **argv);
};

#endif //__WORLD_H__