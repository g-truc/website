/***********************************************\
	G-Particule : v3.56
	Copyright (c) 2003, G-Truc Creation.		
*************************************************
	G-Truc Creation, www.g-truc.net				
	par Groove, groove@g-truc.net				
*************************************************
	gl_option.cpp, 15/02/2003
\***********************************************/

#include "gl_option.h"
#include <GL/glut.h>
#include <stdio.h>

#define RESO_WIDTH			1024
#define RESO_HEIGHT			768
#define RESO_COLOR			32
#define RESO_FREG			75

COptionGL::COptionGL ()
{
	Load ();
}

COptionGL::~COptionGL ()
{
	Save ();
}

reso_t COptionGL::GetReso () const
{
	return Reso;
}

void COptionGL::Save ()
{

}

void COptionGL::Load ()
{
	Reso.size.height = RESO_HEIGHT;
	Reso.size.width = RESO_WIDTH;
	Reso.color = RESO_COLOR;
	Reso.freq = RESO_FREG;

	LoadHQ ();
}

void COptionGL::LoadHQ ()
{
	iResoMode = 1;
	iGraphOpt = GRAPH_FOG | GRAPH_LISSAGE | GRAPH_SMOOTH | GRAPH_BLENDING | GRAPH_LIGHT | GRAPH_MATERIAL | GRAPH_TEXTURE;

	iBlendingMode = 1;
	glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	iFogMode = 0;
	glHint (GL_FOG_HINT, GL_NICEST);
	glEnable (GL_FOG);

	iLissageMode = 0;
	glHint (GL_POINT_SMOOTH_HINT, GL_NICEST);
	glHint (GL_LINE_SMOOTH_HINT, GL_NICEST);
	glHint (GL_POLYGON_SMOOTH_HINT, GL_NICEST);
	glEnable (GL_LINE_SMOOTH);
//	glEnable (GL_POLYGON_SMOOTH);

	iSmoothMode = 0;
	glShadeModel (GL_SMOOTH);

	iTraceMode = TRACE_LIGNE;

	iPolygonMode = 0;
	glPolygonMode (GL_FRONT_AND_BACK, GL_FILL);

	glEnable (GL_LIGHTING);
}

void COptionGL::LoadLQ ()
{
	iResoMode = 0;
	iGraphOpt = 0;
	
	iBlendingMode = 0;
	glBlendFunc (GL_SRC_ALPHA, GL_DST_ALPHA);

	iFogMode = 1;
	glHint (GL_FOG_HINT, GL_FASTEST);
	glDisable (GL_FOG);

	iLissageMode = 0;
	glHint (GL_POINT_SMOOTH_HINT, GL_FASTEST);
	glHint (GL_LINE_SMOOTH_HINT, GL_FASTEST);
	glHint (GL_POLYGON_SMOOTH_HINT, GL_FASTEST);
	glDisable (GL_LINE_SMOOTH);

	iSmoothMode = 1;
	glShadeModel (GL_FLAT);

	iTraceMode = TRACE_POINT;

	iPolygonMode = 2;
	glPolygonMode (GL_FRONT_AND_BACK, GL_POINT);

	glDisable (GL_LIGHTING);
}

bool COptionGL::IsActivate (graph_option_t mode) const
{
	return (iGraphOpt & mode? true : false);
}

bool COptionGL::IsActivate (graph_option_t Mode, int iOption) const
{
	if (Mode == GRAPH_BLENDING)
		return (iBlendingMode == iOption);
	else if (Mode == GRAPH_CURLING)
		return (iBlendingMode == iOption);
	else if (Mode == GRAPH_FOG)
		return (iFogMode == iOption);
	else if (Mode == GRAPH_LISSAGE)
		return (iLissageMode == iOption);
	else if (Mode == GRAPH_SMOOTH)
		return (iSmoothMode == iOption);
	else if (Mode == GRAPH_TRACE)
		return (iTraceMode == iOption);
	else
		return false;
}

void COptionGL::FenetrageMode (int argc, char **argv, const fenetre_t _Fenetre, reso_choix_t _Reso)
{
	Fenetre = _Fenetre;
	if (Fenetre == FENETRE_SIZE)
	{
		switch (_Reso)
		{
		default:
		case _640_480:
			Reso.size.width = 640;
			Reso.size.height = 480;
			break;
		case _800_600:
			Reso.size.width = 800;
			Reso.size.height = 600;
			break;
		case _1024_768:
			Reso.size.width = 1024;
			Reso.size.height = 768;
			break;
		case _1280_1024:
			Reso.size.width = 1280;
			Reso.size.height = 1024;
			break;
		case _1600_1200:
			Reso.size.width = 1600;
			Reso.size.height = 1200;
			break;
		}
		glutInitWindowPosition (0, 0);
		glutInitWindowSize (Reso.size.width, Reso.size.height);
		glutCreateWindow ("G-Particule");
	}
	else if (Fenetre == FENETRE_FULLSCREEN_DESKTOP)
	{
		glutCreateWindow ("G-Particule");
		glutFullScreen ();
	}
	else //if (Fenetre == FENETRE_FULLSCREEN_CHANGE)
	{
		char cResolutionBuffer[32];
		switch (_Reso)
		{
		default:
		case _640_480:
			sprintf (cResolutionBuffer,"%dx%d:%d@%d", 640, 480, 32, RESO_FREG);
			break;
		case _800_600:
			sprintf (cResolutionBuffer,"%dx%d:%d@%d", 800, 600, 32, RESO_FREG);
			break;
		case _1024_768:
			sprintf (cResolutionBuffer,"%dx%d:%d@%d", 1024, 768, 32, RESO_FREG);
			break;
		case _1280_1024:
			sprintf (cResolutionBuffer,"%dx%d:%d@%d", 1280, 1024, 32, RESO_FREG);
			break;
		case _1600_1200:
			sprintf (cResolutionBuffer,"%dx%d:%d@%d", 1600, 1200, 32, RESO_FREG);
			break;
		}
		glutGameModeString (cResolutionBuffer);
		glutEnterGameMode ();
	}

	fSizeMode = Reso.size.width / 640.;
	glPointSize (fSizeMode);
	glLineWidth (fSizeMode);
}

void COptionGL::BlendingActivate ()
{
	if (iGraphOpt & GRAPH_BLENDING)
	{
		iGraphOpt &= ~GRAPH_BLENDING;
	}
	else
	{
		iGraphOpt |= GRAPH_BLENDING;
	}
}

void COptionGL::BlendingMode ()
{
	iBlendingMode++;
	if (iBlendingMode > 1)
		iBlendingMode = 0;

	switch (iBlendingMode)
	{
	default:
	case 0:
		glBlendFunc (GL_SRC_ALPHA, GL_DST_ALPHA);
		break;
	case 1:
		glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		break;
	}
}

void COptionGL::FogActivate ()
{
	if (iGraphOpt & GRAPH_FOG)
	{
		iGraphOpt &= ~GRAPH_FOG;
		glEnable (GL_FOG);
	}
	else //if (~(GraphOpt & GRAPH_FOG))
	{
		iGraphOpt |= GRAPH_FOG;
		glDisable (GL_FOG);
	}
}

void COptionGL::FogMode ()
{
	iFogMode++;
	if (iFogMode > 1)
		iFogMode = 0;

	switch (iFogMode)
	{
	default:
	case 0:
		glHint (GL_FOG_HINT, GL_NICEST);
		break;
	case 1:
		glHint (GL_FOG_HINT, GL_FASTEST);
		break;
	}
}

void COptionGL::LissageActivate ()
{
	if (iGraphOpt & GRAPH_LISSAGE)
	{
		iGraphOpt &= ~GRAPH_LISSAGE;
		glEnable (GL_LINE_SMOOTH);
	}
	else
	{
		iGraphOpt |= GRAPH_LISSAGE;
		glDisable (GL_LINE_SMOOTH);
	}
}

void COptionGL::LissageMode ()
{
	iLissageMode++;
	if (iLissageMode > 1)
		iLissageMode = 0;

	switch (iLissageMode)
	{
	default:
	case 0:
		glHint (GL_POINT_SMOOTH_HINT, GL_NICEST);
		glHint (GL_LINE_SMOOTH_HINT, GL_NICEST);
		glHint (GL_POLYGON_SMOOTH_HINT, GL_NICEST);
		break;
	case 1:
		glHint (GL_POINT_SMOOTH_HINT, GL_FASTEST);
		glHint (GL_LINE_SMOOTH_HINT, GL_FASTEST);
		glHint (GL_POLYGON_SMOOTH_HINT, GL_FASTEST);
		break;
	}
}

void COptionGL::PolygonMode ()
{
	iPolygonMode++;
	if (iPolygonMode > 2)
		iPolygonMode = 0;

	switch (iPolygonMode)
	{
	default:
	case 0:
		glPolygonMode (GL_FRONT_AND_BACK, GL_FILL);
		break;
	case 1:
		glPolygonMode (GL_FRONT_AND_BACK, GL_LINE);
		break;
	case 2:
		glPolygonMode (GL_FRONT_AND_BACK, GL_POINT);
		break;
	}
}
/*
void COptionGL::SmoothActivate (void)
{
	if (iGraphOpt & GRAPH_SMOOTH)
	{
		iGraphOpt &= ~GRAPH_SMOOTH;
	}
	else
	{
		iGraphOpt |= GRAPH_SMOOTH;
	}
}*/

void COptionGL::SmoothMode ()
{
	iSmoothMode++;
	if (iSmoothMode > 1)
		iSmoothMode = 0;

	switch (iSmoothMode)
	{
	default:
	case 0:
		glShadeModel (GL_SMOOTH);
		break;
	case 1:
		glShadeModel (GL_FLAT);
		break;
	}
}

void COptionGL::SizeModePlus ()
{
	fSizeMode++;
	if (fSizeMode > 10)
		fSizeMode = 10;

	glPointSize (fSizeMode);
	glLineWidth (fSizeMode);
}

void COptionGL::SizeModeMoins ()
{
	fSizeMode--;
	if (fSizeMode < 1)
		fSizeMode = 0;

	glPointSize (fSizeMode);
	glLineWidth (fSizeMode);
}

void COptionGL::TraceMode ()
{
	if (iTraceMode == TRACE_LIGNE)
		iTraceMode = TRACE_POINT;
	else //if (g_Meca.Cine.Jet == JET4)
		iTraceMode = TRACE_LIGNE;
}

void COptionGL::LightActivate ()
{
	if (iGraphOpt & GRAPH_LIGHT)
	{
		glDisable (GL_LIGHTING);
		iGraphOpt &= ~GRAPH_LIGHT;
	}
	else
	{
		glEnable (GL_LIGHTING);
		iGraphOpt |= GRAPH_LIGHT;
	}
}

void COptionGL::TextureActivate ()
{
	if (iGraphOpt & GRAPH_TEXTURE)
	{
		iGraphOpt &= ~GRAPH_TEXTURE;
	}
	else
	{
		iGraphOpt |= GRAPH_TEXTURE;
	}
}

void COptionGL::MaterialActivate ()
{
	if (iGraphOpt & GRAPH_MATERIAL)
	{
		iGraphOpt &= ~GRAPH_MATERIAL;
	}
	else
	{
		iGraphOpt |= GRAPH_MATERIAL;
	}
}

void COptionGL::CullingActivate ()
{
	if (iGraphOpt & GRAPH_CULLING)
	{
		glDisable (GL_CULL_FACE);
		iGraphOpt &= ~GRAPH_CULLING;
	}
	else
	{
		glEnable (GL_CULL_FACE);
		iGraphOpt |= GRAPH_CULLING;
	}
}


