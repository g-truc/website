/***********************************************\
	G-Particule : v3.56
	Copyright (c) 2003, G-Truc Creation.		
*************************************************
	G-Truc Creation, www.g-truc.net				
	par Groove, groove@g-truc.net				
*************************************************
	gl_rendu.cpp, 22/09/2003
\***********************************************/

#include "gl_rendu.h"
#include "meca.h"
#include <GL/glut.h>
#include <string>

using namespace std;

#define TAILLE_SURFACE	5.0f

CRenduGL *g_Rendu = NULL;

const float fColorBlack[] =			{0.0f, 0.0f, 0.0f};
const float fColorRed[] =			{1.0f, 0.0f, 0.0f};
const float fColorPurpleRed[] =		{1.0f, 0.0f, 0.5f};
const float fColorPurple[] =		{1.0f, 0.0f, 1.0f};
const float fColorBluePurple[] =	{0.5f, 0.0f, 1.0f};
const float fColorBlue[] =			{0.0f, 0.0f, 1.0f};
const float fColorSkyBlueBlue[] =	{0.0f, 0.5f, 1.0f};
const float fColorSkyBlue[] =		{0.0f, 1.0f, 1.0f};
const float fColorGreenSkyBlue[] =	{0.0f, 1.0f, 0.5f};
const float fColorGreen[] =			{0.0f, 1.0f, 0.0f};
const float fColorYellowGreen[] =	{0.5f, 1.0f, 0.0f};
const float fColorYellow[] =		{1.0f, 1.0f, 0.0f};
const float fColorOrange[] =		{1.0f, 0.5f, 0.0f};

void WD_Rendu ()
{
	if (g_Meca != NULL)
		g_Meca->ExeCine ();
}

void WM_Reshape (int w, int h)
{
	if (g_Rendu != NULL)
		g_Rendu->Reshape (w, h);
}

void WM_Clavier (unsigned char touche, int x, int y)
{
	if (g_Rendu != NULL)
		g_Rendu->Clavier (touche, x, y);
}

void WM_ClavierSP (int key,int x,int y)
{
	if (g_Rendu != NULL)
		g_Rendu->ClavierSP (key);
}

void WM_ClavierSP_UP (int key,int x,int y)
{
	if (g_Rendu != NULL)
		g_Rendu->ClavierSP_UP (key);
}

void WM_Idle ()
{
	if (g_Meca != NULL)
		g_Meca->ExeCine ();
}

/*
void DrawTriangle (Vector & v1, Vector & v2, Vector & v3)
{
	glBegin (GL_TRIANGLES);
		glNormal3fv (v1);
		glVertex3fv (v1);
		glNormal3fv (v2);
		glVertex3fv (v2);
		glNormal3fv (v3);
		glVertex3fv (v3);
	glEnd ();
}

void SubDivide (Vector & v1, Vector & v2, Vector & v3, int iNbSubDivide)
{
	if (iNbSubDivide <= 0)
	{
		DrawTriangle (v1, v2, v3);
		return;
	}

	Vector v12, v23, v31;
	v12 = (v1+v2)/2;
	v23 = (v2+v3)/2;
	v31 = (v3+v1)/2;

	SubDivide (v1, v12, v31, iNbSubDivide - 1);
	SubDivide (v2, v23, v12, iNbSubDivide - 1);
	SubDivide (v3, v31, v23, iNbSubDivide - 1);
	SubDivide (v12, v23, v31, iNbSubDivide -1);
}*/

///////////////////////////////////////////////////////////
// Groove - 05/11/2002 - Les particules sont repr�sent�es par des lignes
void CRenduGL::TraceLigne (CParticule *Part, int iPartNb)
{	
	if (OptionGL.IsActivate (GRAPH_BLENDING))
		glEnable (GL_BLEND);

		for (int i=0; i<iPartNb; i++)
		{
			glBegin (GL_LINE_STRIP);
			for (int j=0; j<POINT_NB; j++)
			{
				glColor4f (RandFloat (0.5, 1.0), RandFloat (0.9, 1.0), 1.0, 1.0 - (RandFloat (1.0, 1.1) * j / POINT_NB));
				glVertex3fv (Part[i].PosAct[j]);
			}
			glEnd ();
		}
	
	if (OptionGL.IsActivate (GRAPH_BLENDING))
		glDisable (GL_BLEND);
}

// Groove - 05/11/2002 - Les particules sont repr�sent�s entant que point
void CRenduGL::TracePoint (CParticule *Part, int iPartNb)
{
	if (OptionGL.IsActivate (GRAPH_BLENDING))
		glEnable (GL_BLEND);

		glBegin (GL_POINTS);
		for (int i=0; i<iPartNb; i++)
		{
			glColor4f (RandFloat (0.9, 1.0), RandFloat (0.95, 1.0), RandFloat (1.0, 1.0), RandFloat (0.5, 0.75));
			glVertex3fv (Part[i].PosAct[0]);
		}
		glEnd ();

	if (OptionGL.IsActivate (GRAPH_BLENDING))
		glDisable (GL_BLEND);
}

void CRenduGL::RenduScene (CParticule *Part, int iPartNb)
{
	glLoadIdentity ();

	glPushMatrix ();
		glTranslatef (fHorizon, fVertical, fTranslation);
	
		glRotatef (Rotation(X) - 75, 1.0, 0.0, 0.0);
		glRotatef (Rotation(Y),		 0.0, 1.0, 0.0);
		glRotatef (Rotation(Z),		 0.0, 0.0, 1.0);

		Rotation(Z) += 0.1;

		if (OptionGL.IsActivate (GRAPH_MATERIAL))
		{
			GLfloat fDiffuseSurface[] = {1.0, 0.0, 0.0, 1.0};
			GLfloat fSpecularSurface[] = {0.4, 0.4, 0.4, 0.4};
			GLfloat fAmbientSurface[] = {0.8, 0.8, 0.8, 0.8};
			GLfloat fEmissionSurface[] = {1.0, 0.7, 0.7, 0.0};
			glMaterialfv (GL_FRONT, GL_DIFFUSE, fDiffuseSurface);
			glMaterialfv (GL_FRONT, GL_SPECULAR, fSpecularSurface); 
			glMaterialfv (GL_FRONT, GL_AMBIENT, fAmbientSurface);
			glMaterialf (GL_FRONT, GL_SHININESS, 100.0);
			glMaterialfv (GL_FRONT, GL_AMBIENT, fEmissionSurface);
			glColorMaterial (GL_FRONT_AND_BACK, GL_AMBIENT);
		}

		if (OptionGL.IsActivate (GRAPH_TEXTURE))
		{
			glEnable (GL_TEXTURE_2D);				//Activate the texture_2D
				glTexEnvf (GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
				glBindTexture (GL_TEXTURE_2D, iTextureId);
				glCallList (iSurfaceId);
			glDisable (GL_TEXTURE_2D);				//Unactivate the texture
		}
		else
		{
			glCallList (iSurfaceId);
		}

		glCallList (iRepereId);

		if (OptionGL.IsActivate (GRAPH_MATERIAL))
		{
			GLfloat fDiffuseParticule[] = {0.8, 1.0, 0.8, 0.5};
			GLfloat fSpecularParticule[] = {0.8, 0.8, 1.0, 0.2};
			GLfloat fAmbientParticule[] = {0.7, 0.9, 1.0, 1.0};
			GLfloat fEmissionParticule[] = {0.6, 0.9, 1.0, 0.0};
			glMaterialfv (GL_FRONT, GL_DIFFUSE, fDiffuseParticule);
			glMaterialfv (GL_FRONT, GL_SPECULAR, fSpecularParticule); 
			glMaterialfv (GL_FRONT, GL_AMBIENT, fAmbientParticule); 
			glMaterialf (GL_FRONT, GL_SHININESS, 100.0);
			glMaterialfv (GL_FRONT, GL_AMBIENT, fEmissionParticule);
			glColorMaterial (GL_FRONT_AND_BACK, GL_AMBIENT);
		}

		if (OptionGL.IsActivate (GRAPH_TRACE, TRACE_LIGNE))
			TraceLigne (Part, iPartNb);
		else
			TracePoint (Part, iPartNb);
		
//		SubDivide (Vector (0,0,2), Vector (0,0,0), Vector (2,0,0), 2);
//		SubDivide (Vector (0,2,0), Vector (0,0,0), Vector (0,0,2), 2);
//		SubDivide (Vector (2,0,0), Vector (0,0,0), Vector (0,2,0), 2);
		
	glPopMatrix ();

	glutSwapBuffers ();
}

void CRenduGL::RenduHUD ()
{
	glClearColor (0,0,0,0);
	glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	
	iFpsNb++;
	if ((clock() - FpsTimeStart) >= 1000)
	{
		iFps = iFpsNb;
		std::cout << iFps << " fps" << std::endl;
		FpsTimeStart = clock ();
		iFpsNb = 0;
	}

	reso_t Resolution = OptionGL.GetReso ();
	// Groove - 14/01/2003 - Print the player 1 score.
	short iPositionX = Resolution.size.width - 2*FONT_SIZE;
	short iPositionY = Resolution.size.height - 2*FONT_SIZE;
	short iFpsBuffer = iFps;

	m_Text.Begin (Resolution.size.width, Resolution.size.height);
	m_Text.Print (64, 64,"%d fps", iFps);
	m_Text.End ();
}

void CRenduGL::Afficher (CParticule *Part, int iPartNb)
{
 	reso_t Resolution = OptionGL.GetReso ();

	glMatrixMode (GL_PROJECTION);
   	glLoadIdentity ();
	gluOrtho2D (0, (GLfloat)Resolution.size.width, 0, (GLfloat)Resolution.size.height);
   	glMatrixMode (GL_MODELVIEW);
   	glLoadIdentity ();

	RenduHUD ();

	glMatrixMode (GL_PROJECTION);
	glLoadIdentity ();
	gluPerspective (45.0, (GLfloat)Resolution.size.width/(GLfloat)Resolution.size.height, 0.1 ,200.0);
	glMatrixMode (GL_MODELVIEW);
	glLoadIdentity ();

	RenduScene (Part, iPartNb);
}

void CRenduGL::InitGL ()
{
	glClearColor (0.0, 0.0, 0.0, 0.0);
	glShadeModel (GL_SMOOTH);

	glDepthFunc (GL_LEQUAL);
	glDisable (GL_BLEND);
	glEnable (GL_DEPTH_TEST);
	glEnable (GL_NORMALIZE);

	// Groove - 12/12/2002 - Fog initialisation
	GLfloat fog_color[3] = {0.3, 0.4, 0.4};
	glFogi (GL_FOG_MODE, GL_EXP2);
	glFogfv (GL_FOG_COLOR, fog_color);
	glFogf (GL_FOG_DENSITY, 0.05);

	CImageTGA Texture ((string (REP_IMAGE) + string (FILE_TEXTURE)).c_str ());
	glGenTextures (1, &iTextureId);
	glBindTexture (GL_TEXTURE_2D, iTextureId),
	glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexImage2D (GL_TEXTURE_2D,0, GL_RGB, Texture.GetWidth (), Texture.GetHeight (), 0, GL_RGB, GL_UNSIGNED_BYTE, Texture.GetData ());

	glFrontFace (GL_CCW);
	glCullFace (GL_BACK);
	glEnable (GL_CULL_FACE);

	glEnable(GL_LIGHT0);
	GLfloat fDiffuse0[] =  {0.8, 0.8, 0.8, 1.};
	GLfloat fSpecular0[] = {0.9, 0.9, 0.9, 1.};
	GLfloat fAmbient0[] =  {1.0, 1.0, 1.0, 1.};
	GLfloat fPosition0[] = {0., 0., 10., 1};
	glLightfv (GL_LIGHT0, GL_DIFFUSE, fDiffuse0);
	glLightfv (GL_LIGHT0, GL_SPECULAR, fSpecular0); 
	glLightfv (GL_LIGHT0, GL_AMBIENT, fAmbient0); 
	glLightfv (GL_LIGHT0, GL_POSITION, fPosition0);
}

//#define POINT_VUE_COEF		2.0
void CRenduGL::Reshape (int w, int h)
{
	glViewport (0, 0, w, h);

	glMatrixMode (GL_PROJECTION);
	glLoadIdentity ();
	if (w <= h)
		gluOrtho2D (-3.0, 3.0, -3.0*h/w, 3.0*h/w);
	else
		gluOrtho2D (-3.0*h/w, 3.0*h/w, -3.0, 3.0);
	glMatrixMode (GL_MODELVIEW);
	glLoadIdentity ();
	
   	glMatrixMode (GL_PROJECTION);
   	glLoadIdentity ();
 	gluPerspective(45.0,(GLfloat)w/(GLfloat)h,0.1,200.0);
//	glFrustum (-4.0/POINT_VUE_COEF, 4.0/POINT_VUE_COEF, -3.0/POINT_VUE_COEF, 3.0/POINT_VUE_COEF, 8, 64);
   	glMatrixMode (GL_MODELVIEW);
   	glLoadIdentity ();
}

// Groove - 05/11/2002 - Trace un rep�re X,Y,Z
void CRenduGL::LoadRepere ()
{
	iRepereId = glGenLists(1);
	glNewList (iRepereId, GL_COMPILE);
//		glLineWidth (3.0);
		glBegin (GL_LINES);
			glColor3f (1.0f, 0.0f, 0.0f);
			glVertex3i (0,0,0);
			glVertex3i (5,0,0);
			glColor3f (0.0f, 1.0f, 0.0f);
			glVertex3i (0,0,0);
			glVertex3i (0,5,0);
			glColor3f (0.0f, 0.0f, 1.0f);
			glVertex3i (0,0,0);
			glVertex3i (0,0,5);
		glEnd ();
//		glLineWidth (1.0);
	glEndList(); 
}

// Groove - 05/11/2002 - Trace la surface qui a le role de sol.
void CRenduGL::LoadSurface ()
{
	iSurfaceId = glGenLists(1);
	glNewList (iSurfaceId, GL_COMPILE);
		// Grand cercle
		glFrontFace( GL_CW );
		glBegin( GL_TRIANGLE_FAN );
			glColor3fv(  fColorBlack );
			glVertex3f(  0.00,  0.00,  0.00 );
			glTexCoord2f (1,1);

			glColor3fv(  fColorRed );
			glVertex3f(  1.00 * TAILLE_SURFACE,  0.00,  0.00 );

			glColor3fv(  fColorPurpleRed );
			glVertex3f(  (GLfloat)ROOT_OF_3_OVER_2 * TAILLE_SURFACE, -0.50 * TAILLE_SURFACE,  0.00 );

			glColor3fv(  fColorPurple );
			glVertex3f(  0.50 * TAILLE_SURFACE, -(GLfloat)ROOT_OF_3_OVER_2 * TAILLE_SURFACE,  0.00 );

			glColor3fv(  fColorBluePurple );
			glVertex3f(  0.00, -1.00 * TAILLE_SURFACE,  0.00 );

			glColor3fv(  fColorBlue );
			glVertex3f( -0.50 * TAILLE_SURFACE, -(GLfloat)ROOT_OF_3_OVER_2 * TAILLE_SURFACE,  0.00 );

			glColor3fv(  fColorSkyBlueBlue );
			glVertex3f( -(GLfloat)ROOT_OF_3_OVER_2 * TAILLE_SURFACE, -0.50 * TAILLE_SURFACE,  0.00 );

			glColor3fv(  fColorSkyBlue );
			glVertex3f( -1.00 * TAILLE_SURFACE,  0.00,  0.00 );

			glColor3fv(  fColorGreenSkyBlue );
			glVertex3f( -(GLfloat)ROOT_OF_3_OVER_2 * TAILLE_SURFACE,  0.50 * TAILLE_SURFACE,  0.00 );

			glColor3fv(  fColorGreen );
			glVertex3f( -0.50 * TAILLE_SURFACE,  (GLfloat)ROOT_OF_3_OVER_2 * TAILLE_SURFACE,  0.00 );

			glColor3fv(  fColorYellowGreen );
			glVertex3f(  0.00,  1.00 * TAILLE_SURFACE,  0.00 );

			glColor3fv(  fColorYellow );
			glVertex3f(  0.50 * TAILLE_SURFACE,  (GLfloat)ROOT_OF_3_OVER_2 * TAILLE_SURFACE,  0.00 );

			glColor3fv(  fColorOrange );
			glVertex3f(  (GLfloat)ROOT_OF_3_OVER_2 * TAILLE_SURFACE,  0.50 * TAILLE_SURFACE,  0.00 );

			glColor3fv(  fColorRed );
			glVertex3f(  1.00 * TAILLE_SURFACE,  0.00,  0.00 );
			glTexCoord2f (0,0);
		glEnd( );
	glEndList(); 
}

void CRenduGL::Clavier (unsigned char touche, int x, int y)
{
	switch (touche)
    {
	case '4':
		fHorizon -= 0.1;
		break;
	case '6':
		fHorizon += 0.1;
		break;
	case '2':
		fVertical -= 0.1;
		break;
	case '8':
		fVertical += 0.1;
		break;
	case '+' : 
		fTranslation +=0.1; 
		break;
	case '-' : 
		fTranslation -=0.1; 
		break;
	case 'q':
		OptionGL.LoadLQ ();
		break;
	case 'Q':
		OptionGL.LoadHQ ();
		break;
	case 'x':
		GestionRotation (X, SENS_POS);
		break;
	case 'X':
		GestionRotation (X, SENS_NEG);
		break;
	case 'y':
		GestionRotation (Y, SENS_POS);
		break;
	case 'Y':
		GestionRotation (Y, SENS_NEG);
		break;
	case 'z':
		GestionRotation (Z, SENS_POS);
		break;
	case 'Z':
		GestionRotation (Z, SENS_NEG);
		break;
	case 'j':
	case 'J':
		g_Meca->JetChoix ();
		break;
	case 'i':
	case 'I':
		g_Meca->CineIni ();
		break;
	case 27 :
		exit (0);
		break;
	}
}

void CRenduGL::ClavierSP_UP (int key)
{
	//Touches speciales
	switch (key)
	{
	case GLUT_KEY_F1:
		OptionGL.BlendingActivate ();
		break;
	case GLUT_KEY_F2:
		OptionGL.BlendingMode ();
		break;
	case GLUT_KEY_F3:
		OptionGL.FogActivate ();
		break;
	case GLUT_KEY_F4:
		//OptionGL.FogMode ();
		OptionGL.TextureActivate ();
		break;
	case GLUT_KEY_F5:
		OptionGL.LissageActivate ();
		break;
	case GLUT_KEY_F6:
		//OptionGL.LissageMode ();
		OptionGL.CullingActivate ();
		OptionGL.SmoothMode ();
		break;
	case GLUT_KEY_F7:
		OptionGL.PolygonMode ();
		break;
	case GLUT_KEY_F8:
		OptionGL.TraceMode ();
		break;
	case GLUT_KEY_F9:
		OptionGL.LightActivate ();
		break;
	case GLUT_KEY_F10:
		OptionGL.MaterialActivate ();
		break;
	case GLUT_KEY_F11:
		OptionGL.SizeModePlus ();
		break;
	case GLUT_KEY_F12:
		OptionGL.SizeModeMoins ();
		break;
	case GLUT_KEY_INSERT:
		fTranslation = -16;
		fHorizon = 0;
		fVertical = -0.2;
		break;
	}
}

void CRenduGL::ClavierSP (int key)
{
	//Touches speciales
	switch (key)
	{
	case GLUT_KEY_UP:
		fVertical += 0.1;
		break;
	case GLUT_KEY_DOWN:
		fVertical -= 0.1;
		break;
	case GLUT_KEY_RIGHT : 
		fHorizon +=0.1; 
		break;
	case GLUT_KEY_LEFT : 
		fHorizon -=0.1; 
		break;
	case GLUT_KEY_PAGE_UP:
		GestionRotation (X, SENS_POS);
		break;
	case GLUT_KEY_PAGE_DOWN:
		GestionRotation (X, SENS_NEG);
		break;
	case GLUT_KEY_HOME:
		GestionRotation (Y, SENS_POS);
		break;
	case GLUT_KEY_END:
		GestionRotation (Y, SENS_NEG);
		break;
	}
}

void CRenduGL::Init (int argc, char **argv)
{
	bool bFullscreen = false;

	glutInit (&argc, argv);
	glutInitDisplayMode (GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH);

	if (argc > 1)
		if (strcmp (argv[1], "-f") == 0)
			bFullscreen = true;

	if (bFullscreen)
		OptionGL.FenetrageMode (argc, argv, FENETRE_FULLSCREEN_CHANGE, _640_480);
	else
		OptionGL.FenetrageMode (argc, argv, FENETRE_SIZE, _640_480);
	OptionGL.LoadHQ ();

	iFps = iFpsNb = 0;
	FpsTimeStart = 0;

	iParticuleNb = 0;

	fTranslation = -16;
	fHorizon = 0;
	fVertical = -0.2;
	
	LoadSurface ();
	LoadRepere ();
//	LoadFont ();
	InitGL ();

	glutReshapeFunc (WM_Reshape);
	glutDisplayFunc (WD_Rendu);
	glutKeyboardFunc (WM_Clavier);
	glutSpecialFunc (WM_ClavierSP);
	glutSpecialUpFunc (WM_ClavierSP_UP);
	glutIdleFunc (WM_Idle);

	glutSetCursor (GLUT_CURSOR_NONE);
}
