/***********************************************\
	G-Particule : v3.56
	Copyright (c) 2003, G-Truc Creation.		
*************************************************
	G-Truc Creation, www.g-truc.net				
	par Groove, groove@g-truc.net				
*************************************************
	world.cpp, 15/02/2003
\***********************************************/

#include "world.h"

CWorld::CWorld (int argc, char **argv)
{
	g_Meca = &Meca;
	g_Rendu = &Rendu;

	Rendu.Init (argc, argv);
}