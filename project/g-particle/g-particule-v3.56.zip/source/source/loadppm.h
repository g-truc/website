#ifndef _LOAD_PPM_H_
#define _LOAD_PPM_H_

#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include "./g_lib/glut.h"

typedef struct {
    int sizeX, sizeY;
    GLubyte *data;
} PPMImage;


PPMImage *LoadPPM(const char *filename)
{
    char buff[16];
    PPMImage *result;
    FILE *fp;
    int maxval,lig_comm=0;

    fp = fopen(filename, "rb");
    if (!fp)
    {
	fprintf(stderr, "Unable to open file `%s'\n", filename);
	exit(1);
    }

    if (fread(buff, 1, 3, fp)!=3)
    {
	perror(filename);
	exit(1);
    }

    if (buff[0] != 'P' || buff[1] != '6')
    {
	fprintf(stderr, "Invalid image format (must be `P6')\n");
	exit(1);
    }

    if (buff[2] != 0x0a)
      fseek(fp,-1,SEEK_CUR);

    while (fgetc(fp) == '#'){
      lig_comm++;
      while (fgetc(fp) != '\n')
	;
      }

    fseek(fp,-1,SEEK_CUR);

    result = (PPMImage *)malloc(sizeof(PPMImage));
    if (!result)
    {
	fprintf(stderr, "Unable to allocate memory\n");
	exit(1);
    }

    if (fscanf(fp, "%d %d", &result->sizeX, &result->sizeY) != 2)
    {
	fprintf(stderr, "Error loading image `%s'\n", filename);
	exit(1);
    }

    if (fscanf(fp, "%d", &maxval) != 1)
    {
	fprintf(stderr, "Error loading image `%s'\n", filename);
	exit(1);
    }

    while (fgetc(fp) != '\n')
	;

    result->data = (GLubyte *)malloc(3 * result->sizeX * result->sizeY);
    if (!result)
    {
	fprintf(stderr, "Unable to allocate memory\n");
	exit(1);
    }

    if (GLubyte(fread(result->data, 3 * result->sizeX, result->sizeY, fp)) != result->sizeY)
    {
	fprintf(stderr, "Error loading image `%s'\n", filename);
	exit(1);
    }

    fclose(fp);

    return result;
}





#endif // _LOAD_PPM_C_

