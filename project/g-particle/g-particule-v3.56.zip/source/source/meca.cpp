/***********************************************\
	G-Particule : v3.56
	Copyright (c) 2003, G-Truc Creation.		
*************************************************
	G-Truc Creation, www.g-truc.net				
	par Groove, groove@g-truc.net				
*************************************************
	world.cpp, 22/09/2003
\***********************************************/

#include "gl_rendu.h"
#include "meca.h"
#include <gtl.h>

using namespace gtl;

CMeca *g_Meca = NULL;

CMeca::CMeca ()
{
	pParticule = new CParticule[PARTICULE_NB];
	SetTime (0.0);
	Gravite = Vector (0,0,M_G);
	CineIni ();
}

void CMeca::JetChoix ()
{
	if (Jet == JET1)
		Jet = JET4;
	else //if (g_Meca.Cine.Jet == JET4)
		Jet = JET1;
}

void CMeca::SetTime (float fTempsDebut)
{
	TempsDebut = clock ();
}

float CMeca::GetTime ()
{
	TempsDuree = clock () - TempsDebut;
	return (static_cast<float>(TempsDuree)/1000);
}

void CMeca::ExeCine ()
{
//	if (GetTime () > 0.01)
	{
		SetTime (0.0);		
		CineVit (pParticule, PARTICULE_NB);
		CinePos (pParticule, PARTICULE_NB);
	}

	g_Rendu->Afficher (pParticule, PARTICULE_NB);
}

void CMeca::CineIni ()
{
	CineIni (pParticule, PARTICULE_NB, GOUTE_PRECI, Gravite, Vector (0,0,JET_VITESSE));
}

void CMeca::CineIni (CParticule *Part, int iPartNb, float _fPreci, Vector Acceleration, Vector Vitesse, Vector Position)
{
	Jet = JET1;
	fPreci = _fPreci;

	for (int i = 0; i < iPartNb; i++)
		Part[i].Ini (CinePes (fPreci), RandFloat (0.0f, 1.0f), Acceleration + Gravite, Vitesse, Position);
}

Vector CMeca::CinePes (float fPreci)
{
	Vector VectorRetour;

	if (Jet == JET1)
	{
		do
		{
			VectorRetour = Vector  (RandFloat (-fPreci, fPreci),
									RandFloat (-fPreci, fPreci),
									RandFloat (0, fPreci/2));
		} while ((SQR (VectorRetour (X)) + SQR (VectorRetour (Y))) > SQR (fPreci));
	}
	else
	{
		do
		{
			VectorRetour = Vector  (RandFloat (-fPreci, fPreci),
									RandFloat (-fPreci, fPreci),
									RandFloat (0, fPreci/2));
		} while ((SQR (VectorRetour (X)) + SQR (VectorRetour (Y))) < SQR (fPreci));
	}

	return VectorRetour;
}

void CMeca::CinePos (CParticule *Part, int iPartNb)
{
	for (int i = 0; i < iPartNb; i++)
	{
		if (Part[i].GetTime () < 0)
		{
			for (int j = 0; j < POINT_NB; j++)
				Part[i].PosAct[j] = Part[i].PosIni;
		}
		else
		{
			for (int k = 0; k < POINT_NB; k++)
			{
				Part[i].PosAct[k] = 1.0f/2.0f * Part[i].AccAct * SQR ((Part[i].GetTime () - GOUTE_DECAL * k)) + Part[i].VitAct[k] * (Part[i].GetTime () - GOUTE_DECAL * k) + Part[i].PosIni;
				if (k == 0 && Part[i].PosAct[0] (Z) < Part[i].PosIni (Z))
					Part[i].Ini (CinePes (fPreci), RandFloat (0.0f, 1.0f));
				else if (Part[i].PosAct[k] (Z) < Part[i].PosIni (Z))
					Part[i].PosAct[k] = Part[i].PosIni;
			}
		}
	}
}

void CMeca::CineVit (CParticule *Part, int iPartNb)
{
	for (int i = 0; i < iPartNb; i++)
		for (int j = 0; j < POINT_NB; j++)
			Part[i].VitAct[j] = Part[i].AccAct * (Part[i].GetTime () - GOUTE_DECAL * j) + Part[i].VitIni;
}
