/***********************************************\
	G-Particule : v3.56
	Copyright (c) 2003, G-Truc Creation.		
*************************************************
	G-Truc Creation, www.g-truc.net				
	par Groove, groove@g-truc.net				
*************************************************
	gl_rendu.h, 22/09/2003
\***********************************************/

#ifndef __RENDU_H__
#define __RENDU_H__

#include "particule.h"
#include "gl_option.h"
#include <gtl.h>

using namespace gtl;

typedef enum {SENS_POS, SENS_NEG} sens_t;

#define FONT_SIZE	16

#define FILE_TEXTURE		"texture.tga"
#define REP_IMAGE			"./image/"

class CRenduGL
{
private:
	COptionGL OptionGL;
	CText m_Text;

	unsigned int iTextureId;

	int	iFpsNb, iFps;

	clock_t	FpsTimeStart;
	int iParticuleNb;

	Vector Rotation;
	float fTranslation;
	float fHorizon;
	float fVertical;

	int iRepereId;
	int iSurfaceId;

	void LoadRepere ();
	void LoadSurface ();

	void InitGL ();

	void TraceLigne (CParticule *Part, int iPartNb);
	void TracePoint (CParticule *Part, int iPartNb);

	void GestionRotation (TCoord Element, sens_t Sens) {Sens == SENS_POS ? Rotation(Element)++ : Rotation(Element)--;}

	void RenduHUD ();
	void RenduScene (CParticule *Part, int iPartNb);

public:
	void Afficher (CParticule *Part, int iPartNb);
	void Clavier (unsigned char touche, int x, int y);
	void ClavierSP (int key);
	void ClavierSP_UP (int key);
	void Init (int argc, char **argv);
	void Reshape (int w, int h);
};

extern CRenduGL *g_Rendu;

#endif //__RENDU_H__
