/***********************************************\
	G-Particule : v3.56
	Copyright (c) 2003, G-Truc Creation.		
*************************************************
	G-Truc Creation, www.g-truc.net				
	par Groove, groove@g-truc.net				
*************************************************
	meca.h, 15/02/2003
\***********************************************/

#ifndef __MECA_H__
#define __MECA_H__

#include "gl_rendu.h"

#define PARTICULE_NB		2048
#define M_G					-9.81f
#define JET_VITESSE			20

typedef enum {JET1, JET4} jet_t;

class CMeca
{
private:
	jet_t		Jet;
	float		fPreci;

	clock_t		TempsDebut, TempsDuree;

	void	SetTime (float fTempsDebut);
	float	GetTime ();

	Vector	CinePes (float fPreci);
	void	CinePos (CParticule *pPart, int iPartNb);
	void	CineVit (CParticule *pPart, int iPartNb);

	void CineIni (CParticule *Part, int iPartNb, float _fPreci = 1.0, Vector Acceleration = Vector (0,0,0), Vector Vitesse = Vector (0,0,0), Vector Position = Vector (0,0,0));

public:
	CParticule		*pParticule;
	Vector			Gravite;

	CMeca ();
	void CineIni ();
	void ExeCine ();
	void JetChoix ();
};

extern CMeca *g_Meca;

#endif //__MECA_H__