/***********************************************\
	G-Particule : v3.56
	Copyright (c) 2003, G-Truc Creation.		
*************************************************
	G-Truc Creation, www.g-truc.net				
	par Groove, groove@g-truc.net				
*************************************************
	world.cpp, 15/02/2003
\***********************************************/

#include "world.h"
#include <GL/glut.h>

void main (int argc, char **argv)
{
	CWorld World (argc, argv);

	glutMainLoop ();
}

