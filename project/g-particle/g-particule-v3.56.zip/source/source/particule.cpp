/***********************************************\
	G-Particule : v3.56
	Copyright (c) 2003, G-Truc Creation.		
*************************************************
	G-Truc Creation, www.g-truc.net				
	par Groove, groove@g-truc.net				
*************************************************
	particule.cpp, 15/02/2003
\***********************************************/

#include "particule.h"

CParticule::CParticule ()
{
	fMasse = GOUTE_MASSE;
}

void CParticule::SetTime (float fTempsDebut)
{
	TempsDebut = static_cast<clock_t>(clock () + fTempsDebut * 1000);
}

float CParticule::GetTime ()
{
	TempsDuree = clock () - TempsDebut;
	return (static_cast<float>(TempsDuree)/1000);
}

void CParticule::Ini (Vector& _Preci, float fIniTime)
{
	SetTime (fIniTime);
	for (int i=0; i<POINT_NB; i++)
	{
		PosAct[i] = PosIni;
		VitAct[i] = VitIni;
	}
	AccAct = AccIni + _Preci;
}

void CParticule::Ini (Vector& _Preci, float fIniTime, Vector& _AccIni, Vector& _VitIni, Vector& _PosIni)
{
	SetTime (fIniTime);
	for (int i=0; i<POINT_NB; i++)
	{
		PosAct[i] = PosIni = _PosIni;
		VitAct[i] = VitIni = _VitIni;
	}
	AccAct = AccIni = _AccIni;
	AccAct += _Preci;
}