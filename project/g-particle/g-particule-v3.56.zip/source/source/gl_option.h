/***********************************************\
	G-Particule : v3.56
	Copyright (c) 2003, G-Truc Creation.		
*************************************************
	G-Truc Creation, www.g-truc.net				
	par Groove, groove@g-truc.net				
*************************************************
	gl_option.h, 15/02/2003
\***********************************************/

#ifndef __GL_OPTION_H__
#define __GL_OPTION_H__

typedef enum {TRACE_LIGNE, TRACE_POINT} trace_t;

typedef struct
{
	struct
	{
		int height;
		int width;
	} size;
	float color;
	float freq;
}reso_t;

typedef enum
{
	_640_480 = 0,
	_800_600,
	_1024_768,
	_1280_1024,
	_1600_1200
}reso_choix_t;

typedef enum
{
	GRAPH_BLENDING =	(1<<1),
	GRAPH_CURLING =		(1<<2),
	GRAPH_FOG =			(1<<3),
	GRAPH_LISSAGE =		(1<<4),
	GRAPH_SMOOTH =		(1<<5),
	GRAPH_TRACE =		(1<<6),
	GRAPH_MATERIAL =	(1<<7),
	GRAPH_LIGHT =		(1<<8),
	GRAPH_TEXTURE =		(1<<9),
	GRAPH_CULLING =		(1<<10),
} graph_option_t;

typedef enum
{
	FENETRE_SIZE = 0,
	FENETRE_FULLSCREEN_DESKTOP = 1,
	FENETRE_FULLSCREEN_CHANGE = 2
} fenetre_t;

class COptionGL
{
private:
	reso_t Reso;
	fenetre_t Fenetre;

	int iResoMode;

	int iGraphOpt;
	float fSizeMode;
	int iBlendingMode;
	int iFogMode;
	int iLissageMode;
	int iSmoothMode;
	int iTraceMode;
	int iPolygonMode;

public:
	COptionGL ();
	~COptionGL ();

	void Load ();
	void Save ();

	void LoadLQ ();
	void LoadHQ ();

	void BlendingActivate ();
	void BlendingMode ();
	void FogActivate ();
	void FogMode ();
	void LissageActivate ();
	void LissageMode ();
	void PolygonMode ();
//	void SmoothActivate ();
	void SmoothMode ();
	void SizeModePlus ();
	void SizeModeMoins ();
	void TraceMode ();
	void MaterialActivate ();
	void LightActivate ();
	void TextureActivate ();
	void CullingActivate ();
	
	bool IsActivate (graph_option_t Mode) const;
	bool IsActivate (graph_option_t Mode, int iOption) const;

	void FenetrageMode (int argc, char **argv, const fenetre_t _Fenetre, reso_choix_t _Reso = _640_480);
	reso_t GetReso () const;
};

#endif // __GL_OPTION_H__
