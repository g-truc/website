/***********************************************\
	G-Particule : v3.56
	Copyright (c) 2003, G-Truc Creation.		
*************************************************
	G-Truc Creation, www.g-truc.net				
	par Groove, groove@g-truc.net				
*************************************************
	particule.h, 22/09/2003
\***********************************************/

#ifndef __PARTICULE_H__
#define __PARTICULE_H__

#include <time.h>
#include <gtl.h>

using namespace gtl;

typedef CVector3 <float> Vector;

#define POINT_NB			4
#define GOUTE_DECAL			(0.1f / POINT_NB) // Groove - 23/12/2002 - Decalage en seconde entre 2 points repr�sentant un goute d'eau.
#define GOUTE_MASSE			2.0f
#define GOUTE_PRECI			5.0f

class CParticule
{
private:
	clock_t	TempsDebut, TempsDuree;

public:
	float	fMasse;

	Vector	PosAct[POINT_NB], PosIni;
	Vector	VitAct[POINT_NB], VitIni;
	Vector	AccAct, AccIni;

	CParticule ();
	
	void SetTime (float fTempsDebut);
	float GetTime ();
	void Ini (Vector& _Preci, float fIniTime, Vector& _AccIni, Vector& _VitIni, Vector& _PosIni);
	void Ini (Vector& _Preci, float fIniTime);
};

#endif // __PARTICULE_H__