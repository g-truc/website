/***********************************************\
	GTL (G-Truc Library) : Alpha 4.0
	Copyright (c) 2003, G-Truc Creation.		
*************************************************
	G-Truc Creation, www.g-truc.net				
	par Groove, groove@g-truc.net				
*************************************************
	gtl_vector4.h, 11/07/2003
\***********************************************/

// v : Name of the vector variable (CVector4<T>)
// a : Name of the array variable (T*)
// s : Name of the scalar variable (T)

#ifndef __GTL_VECTOR_4_H__
#define __GTL_VECTOR_4_H__

#include "gtl_vector.h"

namespace gtl {

#define GTL_VECTOR_4_RANG 4

template <typename T> class CVector4
{
private:
	// Member variable
	T m_Value[GTL_VECTOR_4_RANG];

public:
	// Constructors
	CVector4 ()
	{
		for (unsigned char i=0; i<GTL_VECTOR_4_RANG; i++) 
			m_Value[i]=0;
	}

	CVector4 (const T x, const T y, const T z, const T w)
	{
		m_Value[0] = x;
		m_Value[1] = y;
		m_Value[2] = z;
		m_Value[3] = w;
	}

	CVector4 (const CVector4& v)
	{
		m_Value[0] = v.m_Value[0];
		m_Value[1] = v.m_Value[1];
		m_Value[2] = v.m_Value[2];
		m_Value[3] = v.m_Value[3];
	} 

	CVector4 (const T a[GTL_VECTOR_4_RANG])
	{
		m_Value[0] = a[0];
		m_Value[1] = a[1];
		m_Value[2] = a[2];
		m_Value[3] = a[3];
	}

	// Comparison overload operators
	inline const bool operator== (const CVector4& v) const
	{
		return (m_Value[0] == v.m_Value[0] 
			&&	m_Value[1] == v.m_Value[1] 
			&&	m_Value[2] == v.m_Value[2] 
			&&	m_Value[3] == v.m_Value[3]);
	}

	inline const bool operator== (const T a[GTL_VECTOR_4_RANG]) const
	{
		return (m_Value[0] == a[0] 
			&& m_Value[1] == a[1] 
			&& m_Value[2] == a[2] 
			&& m_Value[3] == a[3]);
	}

	inline const bool operator!= (const CVector4& v) const
	{
		return !(*this==v);
	}

	inline const bool operator!= (const T a[GTL_VECTOR_4_RANG]) const
	{
		return (m_Value[0] != a[0] 
			|| m_Value[1] != a[1] 
			|| m_Value[2] != a[2] 
			|| m_Value[3] != a[3]);
	}

	inline const bool operator> (const CVector4& v) const
	{
		return (Length () > v.Length ());
	}

	inline const bool operator< (const CVector4& v) const
	{
		return (Length () < v.Length ());
	}

	inline const bool operator>= (const CVector4& v) const
	{
		return (Length () >= v.Length ());
	}

	inline const bool operator<= (const CVector4& v) const
	{
		return (Length () <= v.Length ());
	}

	// Affectation overload operators
	inline CVector4 operator- () const
	{
		return CVector4<T> (
            -m_Value[0],
			-m_Value[1],
			-m_Value[2],
			-m_Value[3]);
	}

	inline CVector4 operator= (const CVector4& v)
	{
		return CVector4<T> (m_Value[0] = v.m_Value[0],
			m_Value[1] = v.m_Value[1],
			m_Value[2] = v.m_Value[2],
			m_Value[3] = v.m_Value[3]);
	}

	inline CVector4 operator= (const T a[GTL_VECTOR_4_RANG])
	{
		return CVector4<T> (m_Value[0] = a[0],
			m_Value[1] = a[1],
			m_Value[2] = a[2],
			m_Value[3] = a[3]);
	}

	inline CVector4 operator+ (const CVector4& v) const
	{
		return CVector4<T> (m_Value[0] + v.m_Value[0],
			m_Value[1] + v.m_Value[1],
			m_Value[2] + v.m_Value[2],
			m_Value[3] + v.m_Value[3]);
	}

	inline CVector4 operator+= (const CVector4& v)
	{
		m_Value[0] += v.m_Value[0];
		m_Value[1] += v.m_Value[1];
		m_Value[2] += v.m_Value[2];
		m_Value[3] += v.m_Value[3];
	}

	inline CVector4 operator+ (const T a[GTL_VECTOR_4_RANG]) const
	{
		return CVector4<T> (m_Value[0] + a[0],
			m_Value[1] + a[1],
			m_Value[2] + a[2],
			m_Value[3] + a[3]);
	}

	inline CVector4 operator+= (const T a[GTL_VECTOR_4_RANG])
	{
		m_Value[0] += a[0];
		m_Value[1] += a[1];
		m_Value[2] += a[2];
		m_Value[3] += a[3];
	}

	inline CVector4 operator- (const CVector4& v) const
	{
		return CVector4<T> (m_Value[0] - v.m_Value[0],
			m_Value[1] - v.m_Value[1],
			m_Value[2] - v.m_Value[2],
			m_Value[3] - v.m_Value[3]);
	}

	inline CVector4 operator-= (const CVector4& v)
	{
		m_Value[0] -= v.m_Value[0];
		m_Value[1] -= v.m_Value[1];
		m_Value[2] -= v.m_Value[2];
		m_Value[3] -= v.m_Value[3];
	}

	inline CVector4 operator- (const T a[GTL_VECTOR_4_RANG]) const
	{
		return CVector4<T> (m_Value[0] - a[0],
			m_Value[1] - a[1],
			m_Value[2] - a[2],
			m_Value[3] - a[3]);
	}

	inline CVector4 operator-= (const T a[GTL_VECTOR_4_RANG])
	{
		m_Value[0] -= a[0];
		m_Value[1] -= a[1];
		m_Value[2] -= a[2];
		m_Value[3] -= a[3];
	}

	inline CVector4 operator* (const T s) const
	{
		return CVector4<T> (m_Value[0] * s,
			m_Value[1] * s,
			m_Value[2] * s,
			m_Value[3] * s);
	}

	inline CVector4 operator*= (const T s)
	{
		m_Value[0] *= s;
		m_Value[1] *= s;
		m_Value[2] *= s;
		m_Value[3] *= s;
	}

	inline CVector4 operator/ (const T s) const
	{
		return CVector4<T> (m_Value[0] / s,
			m_Value[1] / s,
			m_Value[2] / s,
			m_Value[3] / s);
	}

	inline CVector4 operator/= (const T s)
	{
		m_Value[0] /= s;
		m_Value[1] /= s;
		m_Value[2] /= s;
		m_Value[3] /= s;
	}

	// Vectorial operators
	inline CVector4 operator^ (const CVector4& v) const
	{
		return CVector4<T> (m_Value[1] * v.m_Value[2] - m_Value[2]*v.m_Value[1],
			m_Value[2] * v.m_Value[0] - m_Value[0] * v.m_Value[2],
			m_Value[0] * v.m_Value[1] - m_Value[1] * v.m_Value[0],
			1);
	}

	inline CVector4 operator^= (const CVector4& v)
	{
		m_Value[0] = m_Value[1] * v.m_Value[2] - m_Value[2] * v.m_Value[1];
		m_Value[1] = m_Value[2] * v.m_Value[0] - m_Value[0] * v.m_Value[2];
		m_Value[2] = m_Value[0] * v.m_Value[1] - m_Value[1] * v.m_Value[0];
		m_Value[3] = 1; 
		return *this;
	}

	// Redirection operators
	inline T* operator>> (T a[GTL_VECTOR_4_RANG]) const
	{
		a[0] = m_Value[0];
		a[1] = m_Value[1];
		a[2] = m_Value[2];
		a[3] = m_Value[3];
		return a;
	}

	inline T* operator<< (const T a[GTL_VECTOR_4_RANG])
	{
		m_Value[0] = a[0];
		m_Value[1] = a[1];
		m_Value[2] = a[2];
		m_Value[3] = a[3];
		return a;
	}

	inline T& operator() (const TCoord & Coord)
	{
		return m_Value[Coord];
	}

	inline T operator* (const CVector4& v) const
	{
		return (m_Value[0] * v.m_Value[0] 
			+ m_Value[1] * v.m_Value[1] 
			+ m_Value[2] * v.m_Value[2]
			+ m_Value[3] * v.m_Value[3]);
	}

	inline T operator* (const T a[GTL_VECTOR_4_RANG]) const
	{
		return (m_Value[0] * a[0] 
			+ m_Value[1] * a[1] 
			+ m_Value[2] * a[2]
			+ m_Value[3] * a[3]);
	}

	inline operator T* ()
	{
		return m_Value;
	}

	inline operator const T* ()
	{
		return m_Value;
	}
	
	// Methodes
	inline double Length () const												
	{
		T m_Value0 = m_Value[0] / m_Value[3];
		T m_Value1 = m_Value[1] / m_Value[3];
		T m_Value2 = m_Value[2] / m_Value[3];
		return (sqrt (static_cast<double> (m_Value0 * m_Value0 + m_Value1 * m_Value1 + m_Value2 * m_Value2)));
	}

	inline CVector4<T> Normalize () const
	{
		if (m_Value[4] == 0) 
			return CVector4<T> (0,0,0,1);
		return CVector4<T> (m_Value[0] / m_Value[4], m_Value[1] / m_Value[4], m_Value[2] / m_Value[4]);
	}
/*	
#ifdef _DEBUG	
	friend std::ostream& operator<< (std::ostream & out, CVector4<T>& v)
	{
		return (out << v.m_Value[0] << ' ' << v.m_Value[1] << ' ' << v.m_Value[2] << ' ' << v.m_Value[3] << ' ');
	}
	
	friend std::istream& operator>> (std::istream & in, CVector4<T>& v)
	{
		in >> v.m_Value[0];
		in >> v.m_Value[1];
		in >> v.m_Value[2];
		in >> v.m_Value[3];
		return in;
	}
#endif // _DEBUG
*/
};

template <typename T> CVector4<T> operator* (const T s, const CVector4<T>& v)	{return v * nb;}

}; // namespace gtl

#endif //__GTL_VECTOR_4_H__
