/***********************************************\
	GTL (G-Truc Library) : Alpha 4.0
	Copyright (c) 2003, G-Truc Creation.		
*************************************************
	G-Truc Creation, www.g-truc.net				
	par Groove, groove@g-truc.net				
*************************************************
	gtl_frustum.h, 25/09/2003
\***********************************************/

#ifndef __GTL_FRUSTUM_H__
#define __GTL_FRUSTUM_H__

namespace gtl {

class CFrustum
{
private:
	float m_fPlanes[6][4];
	void CalculatePlanes ();

public:
	bool isInFrustum (float *fCoord, float fRadius);
	bool isInFrustum (float x, float y, float z, float fRadius);
	inline void Update () {CalculatePlanes ();}
};

}; //namespace gtl

#endif //__GTL_FRUSTUM_H__