/***********************************************\
*	GTL (G-Truc Library) : Alpha 4.0			*
*	Copyright (c) 2003, G-Truc Creation.		*
*************************************************
*	G-Truc Creation, www.g-truc.net				*
*	par Groove, groove@g-truc.net				*
*************************************************
*	gtl_matrix4.h, 17/09/2003					*
\***********************************************/

// m : Name of the matrix variable (CMatrix4<T>)
// v : Name of the vector variable (CVector4<T>)
// a : Name of the array variable (T*)
// s : Name of the scalar variable (T)

#ifndef __GTL_MATRIX_4_H__
#define __GTL_MATRIX_4_H__

#include "gtl_vector3.h"
#include "gtl_vector4.h"

namespace gtl {

#define GTL_MATRIX_4_RANG 4

template <typename T> class CMatrix4
{
private:
	// Member variable
	T m_Value[GTL_MATRIX_4_RANG * GTL_MATRIX_4_RANG];

public:
	// Constructor
	CMatrix4 () {}
	CMatrix4 (const T s00, const T s01, const T s02, const T s03,
			  const T s04, const T s05, const T s06, const T s07,
			  const T s08, const T s09, const T s10, const T s11,
			  const T s12, const T s13, const T s14, const T s15)
	{
		m_Value[ 0] = s00; m_Value[ 1] = s01; m_Value[ 2] = s02; m_Value[ 3] = s03;
		m_Value[ 4] = s04; m_Value[ 5] = s05; m_Value[ 6] = s06; m_Value[ 7] = s07;
		m_Value[ 8] = s08; m_Value[ 9] = s09; m_Value[10] = s10; m_Value[11] = s11;
		m_Value[12] = s12; m_Value[13] = s13; m_Value[14] = s14; m_Value[15] = s15;
	}
    
	CMatrix4 (const T Array[GTL_MATRIX_4_RANG*GTL_MATRIX_4_RANG])
	{
		for (unsigned char i=0; i<(GTL_MATRIX_4_RANG * GTL_MATRIX_4_RANG); i++)
			m_Value[i] = Array[i];
	}

	CMatrix4 (const T a1[GTL_MATRIX_4_RANG], const T a2[GTL_MATRIX_4_RANG], const T a3[GTL_MATRIX_4_RANG], const T a4[GTL_MATRIX_4_RANG])
	{
		int i=0;
		for (i=0; i<4; i++)
			m_Value[i] = a1[i%4];
		for (i=4; i<8; i++)
			m_Value[i] = a2[i%4];
		for (i=8; i<12; i++)
			m_Value[i] = a3[i%4];
		for (i=12; i<16; i++)
			m_Value[i] = a4[i%4];
	}

	CMatrix4 (const CVector4 v1[GTL_MATRIX_4_RANG], const CVector4 v2[GTL_MATRIX_4_RANG], const CVector4 v3[GTL_MATRIX_4_RANG], const CVector4 v4[GTL_MATRIX_4_RANG])
	{
		m_Value[ 0] = v1 (X); m_Value[ 1] = v1 (Y); m_Value[ 2] = v1 (Z); m_Value[ 3] = v1 (W);
		m_Value[ 4] = v2 (X); m_Value[ 5] = v2 (Y); m_Value[ 6] = v2 (Z); m_Value[ 7] = v2 (W);
		m_Value[ 8] = v3 (X); m_Value[ 9] = v3 (Y); m_Value[10] = v3 (Z); m_Value[11] = v3 (W);
		m_Value[12] = v4 (X); m_Value[13] = v4 (Y); m_Value[14] = v4 (Z); m_Value[15] = v4 (W);
	}

	CMatrix4 (const CMatrix4 & m)
	{
		for (unsigned char i=0; i<GTL_MATRIX_4_RANG; i++)
			m_Value[i] = m.m_Value[i];
	}

	// Comparison operators
	bool operator== (const CMatrix4 & m) const
	{
		for (unsigned char i=0; i<(GTL_MATRIX_4_RANG * GTL_MATRIX_4_RANG); i++)
			if (m_Value[i] != m.m_Value[i])
				return false;
		return true;
	}

	bool operator!= (const CMatrix4 & m) const
	{
		for (unsigned char i=0; i<(GTL_MATRIX_4_RANG * GTL_MATRIX_4_RANG); i++)
			if (m_Value[i] != m.m_Value[i])
				return true;
		return false;
	}

	// Operation operators
	CMatrix4 operator- () const
	{
		CMatrix4<T> Matrix;
		for (unsigned char i=0; i<(GTL_MATRIX_4_RANG * GTL_MATRIX_4_RANG); i++)
			Matrix.m_Value[i] = -m_Value[i];
		return Matrix;
	}

	CMatrix4 operator+ (const CMatrix4 & m) const
	{
		return CMatrix4<T> (
			m_Value[ 0]+m.m_Value[ 0], m_Value[ 1]+m.m_Value[ 1], m_Value[ 2]+m.m_Value[ 2], m_Value[ 3]+m.m_Value[ 3],
			m_Value[ 4]+m.m_Value[ 4], m_Value[ 5]+m.m_Value[ 5], m_Value[ 6]+m.m_Value[ 6], m_Value[ 7]+m.m_Value[ 7],
			m_Value[ 8]+m.m_Value[ 8], m_Value[ 9]+m.m_Value[ 9], m_Value[10]+m.m_Value[10], m_Value[11]+m.m_Value[11],
			m_Value[12]+m.m_Value[12], m_Value[13]+m.m_Value[13], m_Value[14]+m.m_Value[14], m_Value[15]+m.m_Value[15]
		);
	}

	CMatrix4 operator+= (const CMatrix4 & m)
	{
		for (unsigned char i=0; i<(GTL_MATRIX_4_RANG * GTL_MATRIX_4_RANG); i++)
			m_Value[i] += m.m_Value[i];
	}
		
	CMatrix4 operator- (const CMatrix4 & m) const
	{
		return CMatrix4<T> (
			m_Value[ 0]-m.m_Value[ 0], m_Value[ 1]-m.m_Value[ 1], m_Value[ 2]-m.m_Value[ 2], m_Value[ 3]-m.m_Value[ 3],
			m_Value[ 4]-m.m_Value[ 4], m_Value[ 5]-m.m_Value[ 5], m_Value[ 6]-m.m_Value[ 6], m_Value[ 7]-m.m_Value[ 7],
			m_Value[ 8]-m.m_Value[ 8], m_Value[ 9]-m.m_Value[ 9], m_Value[10]-m.m_Value[10], m_Value[11]-m.m_Value[11],
			m_Value[12]-m.m_Value[12], m_Value[13]-m.m_Value[13], m_Value[14]-m.m_Value[14], m_Value[15]-m.m_Value[15]
		);
	}

	CMatrix4 operator-= (const CMatrix4 & m)
	{
		for (unsigned char i=0; i<(GTL_MATRIX_4_RANG * GTL_MATRIX_4_RANG); i++)
			m_Value[i] -= m.m_Value[i];
	}

	CMatrix4 operator* (const T s) const
	{
		return CMatrix4<T> (
			m_Value[ 0]*s, m_Value[ 1]*s, m_Value[ 2]*s, m_Value[ 3]*s,
			m_Value[ 4]*s, m_Value[ 5]*s, m_Value[ 6]*s, m_Value[ 7]*s,
			m_Value[ 8]*s, m_Value[ 9]*s, m_Value[10]*s, m_Value[11]*s,
			m_Value[12]*s, m_Value[13]*s, m_Value[14]*s, m_Value[15]*s
		);
	}

	CMatrix4 operator*= (const T s)
	{
		for (unsigned char i=0; i<(GTL_MATRIX_4_RANG * GTL_MATRIX_4_RANG); i++)
			m_Value[i] *= s;
	}

	CVector4<T> operator* (CVector4<T> & v) const
	{
		CVector4<T> Vector;

		Vector (X) = v(X) * m_Value[ 0] + v(Y) * m_Value[ 1] + v(Z) * m_Value[ 2] + v(W) * m_Value[ 3];
		Vector (Y) = v(X) * m_Value[ 4] + v(Y) * m_Value[ 5] + v(Z) * m_Value[ 6] + v(W) * m_Value[ 7];
		Vector (Z) = v(X) * m_Value[ 8] + v(Y) * m_Value[ 9] + v(Z) * m_Value[10] + v(W) * m_Value[11];
		Vector (W) = v(X) * m_Value[12] + v(Y) * m_Value[13] + v(Z) * m_Value[14] + v(W) * m_Value[15];

		return Vector;
	}

	CMatrix4 operator* (const CMatrix4 & m) const
	{
		CMatrix4<T> Matrix;

		Matrix.m_Value[ 0] = m_Value[ 0]*m.m_Value[ 0] + m_Value[ 1]*m.m_Value[ 4] + m_Value[ 2]*m.m_Value[ 8] + m_Value[ 3]*m.m_Value[12];
		Matrix.m_Value[ 1] = m_Value[ 0]*m.m_Value[ 1] + m_Value[ 1]*m.m_Value[ 5] + m_Value[ 2]*m.m_Value[ 9] + m_Value[ 3]*m.m_Value[13];
		Matrix.m_Value[ 2] = m_Value[ 0]*m.m_Value[ 2] + m_Value[ 1]*m.m_Value[ 6] + m_Value[ 2]*m.m_Value[10] + m_Value[ 3]*m.m_Value[14];
		Matrix.m_Value[ 3] = m_Value[ 0]*m.m_Value[ 3] + m_Value[ 1]*m.m_Value[ 7] + m_Value[ 2]*m.m_Value[11] + m_Value[ 3]*m.m_Value[15];

		Matrix.m_Value[ 4] = m_Value[ 4]*m.m_Value[ 0] + m_Value[ 5]*m.m_Value[ 4] + m_Value[ 6]*m.m_Value[ 8] + m_Value[ 7]*m.m_Value[12];
		Matrix.m_Value[ 5] = m_Value[ 4]*m.m_Value[ 1] + m_Value[ 5]*m.m_Value[ 5] + m_Value[ 6]*m.m_Value[ 9] + m_Value[ 7]*m.m_Value[13];
		Matrix.m_Value[ 6] = m_Value[ 4]*m.m_Value[ 2] + m_Value[ 5]*m.m_Value[ 6] + m_Value[ 6]*m.m_Value[10] + m_Value[ 7]*m.m_Value[14];
		Matrix.m_Value[ 7] = m_Value[ 4]*m.m_Value[ 3] + m_Value[ 5]*m.m_Value[ 7] + m_Value[ 6]*m.m_Value[11] + m_Value[ 7]*m.m_Value[15];

		Matrix.m_Value[ 8] = m_Value[ 8]*m.m_Value[ 0] + m_Value[ 9]*m.m_Value[ 4] + m_Value[10]*m.m_Value[ 8] + m_Value[11]*m.m_Value[12];
		Matrix.m_Value[ 9] = m_Value[ 8]*m.m_Value[ 1] + m_Value[ 9]*m.m_Value[ 5] + m_Value[10]*m.m_Value[ 9] + m_Value[11]*m.m_Value[13];
		Matrix.m_Value[10] = m_Value[ 8]*m.m_Value[ 2] + m_Value[ 9]*m.m_Value[ 6] + m_Value[10]*m.m_Value[10] + m_Value[11]*m.m_Value[14];
		Matrix.m_Value[11] = m_Value[ 8]*m.m_Value[ 3] + m_Value[ 9]*m.m_Value[ 7] + m_Value[10]*m.m_Value[11] + m_Value[11]*m.m_Value[15];

		Matrix.m_Value[12] = m_Value[12]*m.m_Value[ 0] + m_Value[13]*m.m_Value[ 4] + m_Value[14]*m.m_Value[ 8] + m_Value[15]*m.m_Value[12];
		Matrix.m_Value[13] = m_Value[12]*m.m_Value[ 1] + m_Value[13]*m.m_Value[ 5] + m_Value[14]*m.m_Value[ 9] + m_Value[15]*m.m_Value[13];
		Matrix.m_Value[14] = m_Value[12]*m.m_Value[ 2] + m_Value[13]*m.m_Value[ 6] + m_Value[14]*m.m_Value[10] + m_Value[15]*m.m_Value[14];
		Matrix.m_Value[15] = m_Value[12]*m.m_Value[ 3] + m_Value[13]*m.m_Value[ 7] + m_Value[14]*m.m_Value[11] + m_Value[15]*m.m_Value[15];

		return Matrix;
	}

	CMatrix4 operator*= (const CMatrix4 & m)
	{
		CMatrix4<T> Matrix, MatrixThis;

		MatrixThis = *this * *this;

		Matrix.m_Value[ 0] = MatrixThis.m_Value[ 0]*m.m_Value[ 0] + MatrixThis.m_Value[ 1]*m.m_Value[ 4] + MatrixThis.m_Value[ 2]*m.m_Value[ 8] + MatrixThis.m_Value[ 3]*m.m_Value[12];
		Matrix.m_Value[ 1] = MatrixThis.m_Value[ 0]*m.m_Value[ 1] + MatrixThis.m_Value[ 1]*m.m_Value[ 5] + MatrixThis.m_Value[ 2]*m.m_Value[ 9] + MatrixThis.m_Value[ 3]*m.m_Value[13];
		Matrix.m_Value[ 2] = MatrixThis.m_Value[ 0]*m.m_Value[ 2] + MatrixThis.m_Value[ 1]*m.m_Value[ 6] + MatrixThis.m_Value[ 2]*m.m_Value[10] + MatrixThis.m_Value[ 3]*m.m_Value[14];
		Matrix.m_Value[ 3] = MatrixThis.m_Value[ 0]*m.m_Value[ 3] + MatrixThis.m_Value[ 1]*m.m_Value[ 7] + MatrixThis.m_Value[ 2]*m.m_Value[11] + MatrixThis.m_Value[ 3]*m.m_Value[15];

		Matrix.m_Value[ 4] = MatrixThis.m_Value[ 4]*m.m_Value[ 0] + MatrixThis.m_Value[ 5]*m.m_Value[ 4] + MatrixThis.m_Value[ 6]*m.m_Value[ 8] + MatrixThis.m_Value[ 7]*m.m_Value[12];
		Matrix.m_Value[ 5] = MatrixThis.m_Value[ 4]*m.m_Value[ 1] + MatrixThis.m_Value[ 5]*m.m_Value[ 5] + MatrixThis.m_Value[ 6]*m.m_Value[ 9] + MatrixThis.m_Value[ 7]*m.m_Value[13];
		Matrix.m_Value[ 6] = MatrixThis.m_Value[ 4]*m.m_Value[ 2] + MatrixThis.m_Value[ 5]*m.m_Value[ 6] + MatrixThis.m_Value[ 6]*m.m_Value[10] + MatrixThis.m_Value[ 7]*m.m_Value[14];
		Matrix.m_Value[ 7] = MatrixThis.m_Value[ 4]*m.m_Value[ 3] + MatrixThis.m_Value[ 5]*m.m_Value[ 7] + MatrixThis.m_Value[ 6]*m.m_Value[11] + MatrixThis.m_Value[ 7]*m.m_Value[15];

		Matrix.m_Value[ 8] = MatrixThis.m_Value[ 8]*m.m_Value[ 0] + MatrixThis.m_Value[ 9]*m.m_Value[ 4] + MatrixThis.m_Value[10]*m.m_Value[ 8] + MatrixThis.m_Value[11]*m.m_Value[12];
		Matrix.m_Value[ 9] = MatrixThis.m_Value[ 8]*m.m_Value[ 1] + MatrixThis.m_Value[ 9]*m.m_Value[ 5] + MatrixThis.m_Value[10]*m.m_Value[ 9] + MatrixThis.m_Value[11]*m.m_Value[13];
		Matrix.m_Value[10] = MatrixThis.m_Value[ 8]*m.m_Value[ 2] + MatrixThis.m_Value[ 9]*m.m_Value[ 6] + MatrixThis.m_Value[10]*m.m_Value[10] + MatrixThis.m_Value[11]*m.m_Value[14];
		Matrix.m_Value[11] = MatrixThis.m_Value[ 8]*m.m_Value[ 3] + MatrixThis.m_Value[ 9]*m.m_Value[ 7] + MatrixThis.m_Value[10]*m.m_Value[11] + MatrixThis.m_Value[11]*m.m_Value[15];

		Matrix.m_Value[12] = MatrixThis.m_Value[12]*m.m_Value[ 0] + MatrixThis.m_Value[13]*m.m_Value[ 4] + MatrixThis.m_Value[14]*m.m_Value[ 8] + MatrixThis.m_Value[15]*m.m_Value[12];
		Matrix.m_Value[13] = MatrixThis.m_Value[12]*m.m_Value[ 1] + MatrixThis.m_Value[13]*m.m_Value[ 5] + MatrixThis.m_Value[14]*m.m_Value[ 9] + MatrixThis.m_Value[15]*m.m_Value[13];
		Matrix.m_Value[14] = MatrixThis.m_Value[12]*m.m_Value[ 2] + MatrixThis.m_Value[13]*m.m_Value[ 6] + MatrixThis.m_Value[14]*m.m_Value[10] + MatrixThis.m_Value[15]*m.m_Value[14];
		Matrix.m_Value[15] = MatrixThis.m_Value[12]*m.m_Value[ 3] + MatrixThis.m_Value[13]*m.m_Value[ 7] + MatrixThis.m_Value[14]*m.m_Value[11] + MatrixThis.m_Value[15]*m.m_Value[15];

		return MatrixThis;
	}

	CMatrix4 operator/ (const T s) const
	{
	    CMatrix4<T> Matrix = *this;
		for (unsigned char i=0; i<(GTL_MATRIX_4_RANG * GTL_MATRIX_4_RANG); i++)
		    Matrix.m_Value[i] /= s;
		return Matrix;
	}

	CMatrix4 operator/= (const T s)
	{
		for (unsigned char i=0; i<(GTL_MATRIX_4_RANG * GTL_MATRIX_4_RANG); i++)
		    m_Value[i] /= s;
	}

	// Access operator
	inline T& operator () (unsigned short i, unsigned short j)
	{
		if (i > 3)
			i = 3;
		if (j > 3)
			j = 3;
		return m_Value[i+j*GTL_MATRIX_4_RANG];
	}

	inline operator T* ()
	{
		return m_Value;
	}

	inline operator const T* ()
	{
		return m_Value;
	}

	// Transformation
	void transformVector (CVector3<T> *pVec)
	{
	    CVector3<T> &v = *pVec;

		float x = v (X);
		float y = v (Y);
		float z = v (Z);

		v (X) = x * m_Value[0] +
				y * m_Value[4] +
				z * m_Value[8];

		v (Y) = x * m_Value[1] +
				y * m_Value[5] +
				z * m_Value[9];

		v (Z) = x * m_Value[2] +
				y * m_Value[6] +
				z * m_Value[10];
    }
	
	void Translate (const CVector4 & v)
	{
	    m_Value[12] = v (X);
	    m_Value[13] = v (Y);
	    m_Value[14] = v (Z);
	    m_Value[15] = v (W);
	}

	void Translate (const TCoord & Coord, const T s)
	{
		switch (Coord)
		{
		case X:
			m_Value[12] = s;          
			break;
		case Y:
			m_Value[13] = s;          
			break;
		case Z:
			m_Value[14] = s;          
			break;
		default:
		case W:
			m_Value[15] = s;          
			break;
		}
	}

	void Rotate (float fAngle, CVector3<T> & axis)
	{
		float s = sin (DEG_TO_RAD(fAngle));
		float c = cos (DEG_TO_RAD(fAngle));

		axis.normalize();

		float ux = axis(X);
		float uy = axis(Y);
		float uz = axis(Z);
    
		m_Value[0]  = c + (1-c) * ux;
		m_Value[1]  = (1-c) * ux*uy + s*uz;
		m_Value[2]  = (1-c) * ux*uz - s*uy;
		m_Value[3]  = 0;
    
		m_Value[4]  = (1-c) * uy*ux - s*uz;
		m_Value[5]  = c + (1-c) * pow(uy,2);
		m_Value[6]  = (1-c) * uy*uz + s*ux;
		m_Value[7]  = 0;
    
		m_Value[8]  = (1-c) * uz*ux + s*uy;
		m_Value[9]  = (1-c) * uz*uz - s*ux;
		m_Value[10] = c + (1-c) * pow(uz,2);
		m_Value[11] = 0;
    
		m_Value[12] = 0;
		m_Value[13] = 0;
		m_Value[14] = 0;
		m_Value[15] = 1;
	}

    void Identity ()
    {
        m_Value[ 0] = m_Value[ 5] = m_Value[10] = m_Value[15] = static_cast<T> (1);
        m_Value[ 1] = m_Value[ 2] = m_Value[ 3] = static_cast<T> (0);
        m_Value[ 4] = m_Value[ 6] = m_Value[ 7] = static_cast<T> (0);
        m_Value[ 8] = m_Value[ 9] = m_Value[11] = static_cast<T> (0);
        m_Value[12] = m_Value[13] = m_Value[14] = static_cast<T> (0);
    }
};

}; // namespace gtl

#endif //__GTL_MATRIX_4_H__
