/***********************************************\
	GTL (G-Truc Library) : Alpha 4.0
	Copyright (c) 2003, G-Truc Creation.		
*************************************************
	G-Truc Creation, www.g-truc.net				
	par Groove, groove@g-truc.net				
*************************************************
	gtl_vector.h, 17/09/2003
\***********************************************/

#ifndef __GTL_VECTOR_H__
#define __GTL_VECTOR_H__

#pragma warning (disable : 4244) //double to float

#include <iostream>
#include <math.h>

namespace gtl {

typedef enum
{
	X = 0,
	Y = 1,
	Z = 2,
	W = 3,
} TCoord;

}; // namespace gtl

#endif //__GTL_VECTOR_H__
