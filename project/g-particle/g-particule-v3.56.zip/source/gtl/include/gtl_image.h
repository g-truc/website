/***********************************************\
	GTL (G-Truc Library) : Alpha 4.0
	Copyright (c) 2003, G-Truc Creation.		
*************************************************
	G-Truc Creation, www.g-truc.net				
	par Groove, groove@g-truc.net				
*************************************************
	gtl_image.h, 01/08/2003
\***********************************************/

#ifndef __GTL_IMAGE_H__
#define __GTL_IMAGE_H__

#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>

namespace gtl {

typedef enum
{
	COLOR_FORMAT_NULL = 0,
	COLOR_FORMAT_DEFAULT,
	COLOR_FORMAT_RGBA32,
	COLOR_FORMAT_RGB24,
	COLOR_FORMAT_BGRA32,
	COLOR_FORMAT_BGR24,
	COLOR_FORMAT_ARGB16,
	COLOR_FORMAT_GRAY08
} EColorFormat;

typedef enum
{
	ERROR_IMAGE_NULL = 0,
	ERROR_IMAGE_FILE_NOT_FOUND,
	ERROR_IMAGE_MEM_ALLOC,
	ERROR_IMAGE_SIZE,
	ERROR_IMAGE_PIXEL_BITS,
	ERROR_IMAGE_BAD_DATA,
	ERROR_IMAGE_TYPE,
} EImageError;

class CImage
{
protected:

	EColorFormat m_Format;
	unsigned char m_ucPixelSize;
	unsigned short m_unHeight;
	unsigned short m_unWidth;
	unsigned char *m_pucData;
	char* m_szFilename;
	unsigned char *m_pucColorMapData;

	void Error (const EImageError & iError, const char* szInfo = "0");
	void BGRtoRGB ();

	void ReadDataAlpha (FILE* File, const unsigned int iOffsetData);
	void ReadDataRGB (FILE* File, const unsigned int iOffsetData);
	void ReadDataRGBA (FILE* File, const unsigned int iOffsetData);

	void LoadBGR24FromBGR24Colormap (unsigned char* pucData);
	void LoadRGB24FromBGR24Colormap (unsigned char* pucData);
	void LoadARGB16FromABGR16 (unsigned char* pucData);
	void LoadBGR24FromBGR24 (unsigned char* pucData);
	void LoadRGB24FromBGR24 (unsigned char* pucData);
	void LoadBGRA32FromBGRA32 (unsigned char* pucData);
	void LoadRGBA32FromBGRA32 (unsigned char* pucData);

	void SaveFilename (const char* szFilename);

public:
	CImage ();
	virtual ~CImage ();
	
	virtual bool Load (const char* szFilename, const EColorFormat ColorFormat = COLOR_FORMAT_DEFAULT) = 0;
	virtual bool Save () = 0;
	virtual bool SaveAs (const char* szFilename) = 0;

	unsigned short GetValue (unsigned short x, unsigned short y) const {return m_pucData[y*m_unWidth+x];}
	unsigned char* GetData () const {return m_pucData;}
	EColorFormat GetFormat () const {return m_Format;}
	unsigned short GetHeight () const {return m_unHeight;}
	unsigned short GetWidth () const {return m_unWidth;}

	void SetData (unsigned char* pucData) {m_pucData = pucData;}
	void SetFormat (const EColorFormat & Format) {m_Format = Format;}
	void SetHeight (unsigned short unHeight) {m_unHeight = unHeight;}
	void SetWidth (unsigned short unWidth) {m_unWidth = unWidth;}
};

}; // gtl

#endif //__GTL_IMAGE_H__

