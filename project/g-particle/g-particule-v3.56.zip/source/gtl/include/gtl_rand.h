/***********************************************\
	GTL (G-Truc Library) : Alpha 4.0
	Copyright (c) 2003, G-Truc Creation.		
*************************************************
	G-Truc Creation, www.g-truc.net				
	par Groove, groove@g-truc.net				
*************************************************
	gtl_rand.h, 21/03/2003
\***********************************************/

#ifndef __GTL_RAND_H__
#define __GTL_RAND_H__

#include <stdlib.h>
#include <time.h>

namespace gtl {

inline void RandInit (long iStart = clock ())	{srand (iStart);}
inline float RandFloat ()						{return rand () / ((float)RAND_MAX);}
inline long RandFloat (long iMax)				{return (long) (RandFloat () * iMax);}
inline float RandFloat (float fMin, float fMax)	{return ((RandFloat () * (fMax - fMin)) + fMin);}
inline long RandInt (long iMin, long iMax)		{return (long) (((float)rand () / RAND_MAX * (iMax - iMin )) + iMin);}

}; // namespace gtl

#endif //__GTL_RAND_H__
