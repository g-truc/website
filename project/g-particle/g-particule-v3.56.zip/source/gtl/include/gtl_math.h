/***********************************************\
	GTL (G-Truc Library) : Alpha 4.0
	Copyright (c) 2003, G-Truc Creation.		
*************************************************
	G-Truc Creation, www.g-truc.net				
	par Groove, groove@g-truc.net				
*************************************************
	gtl_math.h, 16/08/2003
\***********************************************/

#ifndef __GTL_MATH_H__
#define __GTL_MATH_H__

namespace gtl {

#define PI					3.1415926535897932384626433832795
#define PI_OVER_180			0.0174532925199432957692369076848861
#define PI_UNDER_180		57.2957795130823208767981548141052
#define ROOT_OF_3_OVER_2	0.8660254038
#define ROOT_OF_2			0.7071067812
#define EPSILON				1.0e-8
#define SMALL				1.0e-4
#define BIG					1.0e+10

#define DEG_TO_RAD(deg)		((deg)*PI_OVER_180)
#define RAD_TO_DEG(rad)		((rad)*PI_UNDER_180)

#define SQR(nb)				((nb)*(nb))
#define CUBE(nb)			((nb)*(nb)*(nb))

#define MIN(a, b)			(((a)<(b))?(a):(b))
#define MAX(a, b)			(((a)<(b))?(b):(a))

extern const short g_nCos[360];
extern const short g_nSin[360];

inline float cos (unsigned short unAngle)
{
	if (unAngle > 360)
		unAngle = 360;
	return static_cast<float> (g_nCos[unAngle]) / 1024;
}

inline float sin (unsigned short unAngle)
{
	if (unAngle > 360)
		unAngle = 360;
	return static_cast<float> (g_nSin[unAngle]) / 1024;
}

template <typename T> T BitInversion (const T Nb)
{
	T NbBuffer = 0;
	for (short i = 0; i < sizeof(T); i++)
		if (Nb & (1<<i))
			NbBuffer |= (1<<(31-i));
	return NbBuffer;
}

inline unsigned long Factoriel (const unsigned short n)
{
	unsigned long f = 1, i;
	
	for (i = 1; i<=n; i++)
		f*= i;

	return f;
}

}; // namespace gtl

#endif //__GTL_MATH_H__
