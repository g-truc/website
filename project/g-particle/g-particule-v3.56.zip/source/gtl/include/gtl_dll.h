/***********************************************\
	GTL (G-Truc Library) : Alpha 4.0
	Copyright (c) 2003, G-Truc Creation.		
*************************************************
	G-Truc Creation, www.g-truc.net				
	par Groove, groove@g-truc.net				
*************************************************
	gtl_dll.h, 02/04/2003
\***********************************************/

#ifndef __GTL_DLL_H__
#define __GTL_DLL_H__

namespace gtl {

#define EXPORT extern "C"__declspec (dllexport)
#define IMPORT extern "C"__declspec (dllimport)

}; //namespace gtl

#endif //__GTL_DLL_H__