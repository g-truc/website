/***********************************************\
	GTL (G-Truc Library) : Alpha 4.0
	Copyright (c) 2003, G-Truc Creation.		
*************************************************
	G-Truc Creation, www.g-truc.net				
	par Groove, groove@g-truc.net				
*************************************************
	gtl_color.h, 30/08/2003
\***********************************************/

#ifndef __GTL_COLOR_H__
#define __GTL_COLOR_H__

namespace gtl {

class CColor
{
private:
	unsigned char m_ucValue[4];

public:
	CColor ();
	CColor (unsigned char ucRed, unsigned char ucGreen, unsigned char ucBlue, unsigned char ucAlpha = 255);
	void LoadFloat (float fRed, float fGreen, float fBlue, float fAlpha = 1.0);
	void LoadUChar (unsigned char ucRed, unsigned char ucGreen, unsigned char ucBlue, unsigned char ucAlpha = 255);

	unsigned long Get24BitsColor ();
	unsigned long Get32BitsColor ();

	inline unsigned char GetRed () const {return m_ucValue[0];}
	inline unsigned char GetGreen () const {return m_ucValue[1];}
	inline unsigned char GetBlue () const {return m_ucValue[2];}
	inline unsigned char GetAlpha () const {return m_ucValue[3];}

	inline void SetRed (unsigned char ucRed) {m_ucValue[0] = ucRed;}
	inline void SetGreen (unsigned char ucGreen) {m_ucValue[1] = ucGreen;}
	inline void SetBlue (unsigned char ucBlue) {m_ucValue[2] = ucBlue;}
	inline void SetAlpha (unsigned char ucAlpha) {m_ucValue[3] = ucAlpha;}

	inline operator unsigned char* () {return m_ucValue;}
};

}; //namespace gtl

#endif //__GTL_COLOR_H__
