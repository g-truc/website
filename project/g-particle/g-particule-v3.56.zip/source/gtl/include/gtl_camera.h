/***********************************************\
	GTL (G-Truc Library) : Alpha 4.0
	Copyright (c) 2003, G-Truc Creation.		
*************************************************
	G-Truc Creation, www.g-truc.net				
	par Groove, groove@g-truc.net				
*************************************************
	gtl_camera.h, 05/09/2003
\***********************************************/

#ifndef __CAMERA_H__
#define __CAMERA_H__

#include "gtl_vector2.h"
#include "gtl_vector3.h"

namespace gtl {

class CCamera
{
	typedef CVector2<int> TVector2;
	typedef CVector3<float> TVector3;

private:
	TVector3 m_Position;
	TVector3 m_View;
	TVector3 m_UpVector;
	float m_fViewDistance;
	float m_fCurrentRotX;

	void RotateView (float angle, float x, float y, float z);
	void UpdateView (int iMoveX, int iMoveZ);

public:	
	CCamera (float fViewDistance = 1.f);

	void LookAt (int iMoveX, int iMoveZ);
	void Position (const TVector3 & Position, const TVector3 & View, const TVector3 & UpVector);
	void Move (float fSpeed);
	void Strafe (float fSpeed);
	TVector3 GetPosition () const {return m_Position;}
	bool TestDistance (float x, float y, float z = 0.f);
};

}; //namespace gtl

#endif // __CAMERA_H__
