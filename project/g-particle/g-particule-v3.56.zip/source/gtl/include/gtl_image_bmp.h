/***********************************************\
	GTL (G-Truc Library) : Alpha 4.0
	Copyright (c) 2003, G-Truc Creation.		
*************************************************
	G-Truc Creation, www.g-truc.net				
	par Groove, groove@g-truc.net				
*************************************************
	gtl_image_bmp.h, 21/03/2003
\***********************************************/

#ifndef __GTL_IMAGE_BMP_H__
#define __GTL_IMAGE_BMP_H__

#include "gtl_image.h"

namespace gtl {

class CImageBMP : public CImage
{
private:

public:
	CImageBMP ();
	CImageBMP (const char* szFilename, const EColorFormat ColorFormat = COLOR_FORMAT_DEFAULT);
	virtual ~CImageBMP ();

	virtual bool Load (const char* szFilename, const EColorFormat ColorFormat = COLOR_FORMAT_DEFAULT);
	virtual bool Save () {return false;}
	virtual bool SaveAs (const char* szFilename) {return false;}
};

}; //namespace gtl

#endif //__GTL_IMAGE_BMP_H__
