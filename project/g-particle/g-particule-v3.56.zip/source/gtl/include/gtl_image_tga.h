/***********************************************\
	GTL (G-Truc Library) : Alpha 4.0
	Copyright (c) 2003, G-Truc Creation.		
*************************************************
	G-Truc Creation, www.g-truc.net				
	par Groove, groove@g-truc.net				
*************************************************
	gtl_image_tga.h, 01/08/2003
\***********************************************/

#ifndef __GTL_IMAGE_TGA_H__
#define __GTL_IMAGE_TGA_H__

#include <stdio.h>
#include <stdlib.h>
#include "gtl_image.h"

namespace gtl {

class CImageTGA : public CImage
{
private:
	// Groove - 05/03/2003 - Champs d'identification comportant au plus 255 charact�res
	char *m_szIdenticationField;

	void FreeAll ();
	bool CheckSize (long iSize);

public:
	CImageTGA () {m_szIdenticationField = NULL;}
	CImageTGA (const char* szFilename, const EColorFormat ColorFormat = COLOR_FORMAT_DEFAULT) {m_szIdenticationField = NULL; Load (szFilename, ColorFormat);}
	virtual ~CImageTGA ();

	// Groove - 09/03/2003 - Chargement d'une image.
	virtual bool Load (const char* szFilename, const EColorFormat ColorFormat = COLOR_FORMAT_DEFAULT);
	virtual bool Save ();
	virtual bool SaveAs (const char* szFilename);

	// Groove - 09/03/2003 - Fonction pemetant de r�cup�rer le champ d'identification
	char* GetIdentificationField () const {return m_szIdenticationField;}
};

}; //namespace gtl

#endif //__GTL_IMAGE_TGA_H__
