/***********************************************\
	GTL (G-Truc Library) : Alpha 4.0
	Copyright (c) 2003, G-Truc Creation.		
*************************************************
	G-Truc Creation, www.g-truc.net				
	par Groove, groove@g-truc.net				
*************************************************
	gtl_text.h, 25/09/2003
\***********************************************/

#ifndef __GTL_TEXT_H__
#define __GTL_TEXT_H__

#include <stddef.h>

namespace gtl {

#define GTL_TEXT_BUF_SIZE	256

class CText
{
private:
	char* m_pBuffer;
	void* m_GlutFont;

public:
	CText ();
	~CText ();

	void SetBufferSize (long iSize);

	void* GetFont () const;
	void SetFont (void* GlutFont);

	void Begin (float fWindowWidth, float fWindowHeight);
	void End ();
	void Print (float x, float y, char *szMsg, ...);
};

}; // namespace gtl

#endif //__GTL_TEXT_H__
