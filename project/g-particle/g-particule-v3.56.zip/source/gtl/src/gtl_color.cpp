/***********************************************\
	GTL (G-Truc Library) : Alpha 4.0			
	Copyright (c) 2003, G-Truc Creation.		
*************************************************
	G-Truc Creation, www.g-truc.net				
	par Groove, groove@g-truc.net				
*************************************************
	gtl_color.cpp, 31/08/2003
\***********************************************/

#include "../include/gtl_color.h"

using namespace gtl;

CColor::CColor (unsigned char ucRed, unsigned char ucGreen, unsigned char ucBlue, unsigned char ucAlpha)
{
	m_ucValue[0] = ucRed;
	m_ucValue[1] = ucGreen;
	m_ucValue[2] = ucBlue;
	m_ucValue[3] = ucAlpha;
}

void CColor::LoadFloat (float fRed, float fGreen, float fBlue, float fAlpha)
{
	m_ucValue[0] = static_cast<unsigned char> (fRed * 255);
	m_ucValue[1] = static_cast<unsigned char> (fGreen * 255);
	m_ucValue[2] = static_cast<unsigned char> (fBlue * 255);
	m_ucValue[3] = static_cast<unsigned char> (fAlpha * 255);
}

void CColor::LoadUChar (unsigned char ucRed, unsigned char ucGreen, unsigned char ucBlue, unsigned char ucAlpha)
{
	m_ucValue[0] = ucRed;
	m_ucValue[1] = ucGreen;
	m_ucValue[2] = ucBlue;
	m_ucValue[3] = ucAlpha;
}

unsigned long CColor::Get32BitsColor ()
{
	return m_ucValue[0] + (m_ucValue[1] << 8) + (m_ucValue[2] << 16) + (m_ucValue[3] << 24);
}

unsigned long CColor::Get24BitsColor ()
{
	return m_ucValue[0] + (m_ucValue[1] << 8) + (m_ucValue[2] << 16);
}
