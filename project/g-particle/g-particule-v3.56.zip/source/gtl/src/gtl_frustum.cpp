/***********************************************\
	GTL (G-Truc Library) : Alpha 4.0
	Copyright (c) 2003, G-Truc Creation.		
*************************************************
	G-Truc Creation, www.g-truc.net				
	par Groove, groove@g-truc.net				
*************************************************
	gtl_frustum.cpp, 21/09/2003
\***********************************************/

#include "../include/gtl_frustum.h"
#ifdef WIN32
	#include <windows.h>
#endif //WIN32
#include <GL/gl.h>
#include <math.h>

using namespace gtl;

bool CFrustum::isInFrustum (float x, float y, float z, float fRadius = 1.0f)
{
    for (int i=0; i<6; i++)
    {
        if (m_fPlanes[i][0] * x +
            m_fPlanes[i][1] * y +
            m_fPlanes[i][2] * z +
            m_fPlanes[i][3] <= -fRadius)
            return false;
    }

    return true;
}

bool CFrustum::isInFrustum (float *fCoord, float fRadius = 1.0f)
{
    for (int i=0; i<6; i++)
    {
        if (m_fPlanes[i][0] * fCoord[0] +
            m_fPlanes[i][1] * fCoord[1] +
            m_fPlanes[i][2] * fCoord[2] +
            m_fPlanes[i][3] <= -fRadius)
            return false;
    }

    return true;
}

void CFrustum::CalculatePlanes ()
{
    float p[16];	// projection matrix
    float v[16];	// model-view matrix
    float mvp[16];	// model-view-projection matrix
    float fDist;

    glGetFloatv (GL_PROJECTION_MATRIX, p);
    glGetFloatv (GL_MODELVIEW_MATRIX, v);

    mvp[ 0] = v[ 0] * p[ 0] + v[ 1] * p[ 4] + v[ 2] * p[ 8] + v[ 3] * p[12];
    mvp[ 1] = v[ 0] * p[ 1] + v[ 1] * p[ 5] + v[ 2] * p[ 9] + v[ 3] * p[13];
    mvp[ 2] = v[ 0] * p[ 2] + v[ 1] * p[ 6] + v[ 2] * p[10] + v[ 3] * p[14];
    mvp[ 3] = v[ 0] * p[ 3] + v[ 1] * p[ 7] + v[ 2] * p[11] + v[ 3] * p[15];

    mvp[ 4] = v[ 4] * p[ 0] + v[ 5] * p[ 4] + v[ 6] * p[ 8] + v[ 7] * p[12];
    mvp[ 5] = v[ 4] * p[ 1] + v[ 5] * p[ 5] + v[ 6] * p[ 9] + v[ 7] * p[13];
    mvp[ 6] = v[ 4] * p[ 2] + v[ 5] * p[ 6] + v[ 6] * p[10] + v[ 7] * p[14];
    mvp[ 7] = v[ 4] * p[ 3] + v[ 5] * p[ 7] + v[ 6] * p[11] + v[ 7] * p[15];

    mvp[ 8] = v[ 8] * p[ 0] + v[ 9] * p[ 4] + v[10] * p[ 8] + v[11] * p[12];
    mvp[ 9] = v[ 8] * p[ 1] + v[ 9] * p[ 5] + v[10] * p[ 9] + v[11] * p[13];
    mvp[10] = v[ 8] * p[ 2] + v[ 9] * p[ 6] + v[10] * p[10] + v[11] * p[14];
    mvp[11] = v[ 8] * p[ 3] + v[ 9] * p[ 7] + v[10] * p[11] + v[11] * p[15];

    mvp[12] = v[12] * p[ 0] + v[13] * p[ 4] + v[14] * p[ 8] + v[15] * p[12];
    mvp[13] = v[12] * p[ 1] + v[13] * p[ 5] + v[14] * p[ 9] + v[15] * p[13];
    mvp[14] = v[12] * p[ 2] + v[13] * p[ 6] + v[14] * p[10] + v[15] * p[14];
    mvp[15] = v[12] * p[ 3] + v[13] * p[ 7] + v[14] * p[11] + v[15] * p[15];

    m_fPlanes[0][0] = mvp[ 3] - mvp[ 0];
    m_fPlanes[0][1] = mvp[ 7] - mvp[ 4];
    m_fPlanes[0][2] = mvp[11] - mvp[ 8];
    m_fPlanes[0][3] = mvp[15] - mvp[12];

    fDist = (float) sqrt(m_fPlanes[0][0] * m_fPlanes[0][0] + 
                      m_fPlanes[0][1] * m_fPlanes[0][1] + 
                      m_fPlanes[0][2] * m_fPlanes[0][2]);

    m_fPlanes[0][0] /= fDist;
    m_fPlanes[0][1] /= fDist;
    m_fPlanes[0][2] /= fDist;
    m_fPlanes[0][3] /= fDist;

    m_fPlanes[1][0] = mvp[ 3] + mvp[ 0];
    m_fPlanes[1][1] = mvp[ 7] + mvp[ 4];
    m_fPlanes[1][2] = mvp[11] + mvp[ 8];
    m_fPlanes[1][3] = mvp[15] + mvp[12];

    fDist = (float) sqrt( m_fPlanes[1][0] * m_fPlanes[1][0] + 
                      m_fPlanes[1][1] * m_fPlanes[1][1] + 
                      m_fPlanes[1][2] * m_fPlanes[1][2] );

    m_fPlanes[1][0] /= fDist;
    m_fPlanes[1][1] /= fDist;
    m_fPlanes[1][2] /= fDist;
    m_fPlanes[1][3] /= fDist;

    m_fPlanes[2][0] = mvp[ 3] + mvp[ 1];
    m_fPlanes[2][1] = mvp[ 7] + mvp[ 5];
    m_fPlanes[2][2] = mvp[11] + mvp[ 9];
    m_fPlanes[2][3] = mvp[15] + mvp[13];

    fDist = (float) sqrt( m_fPlanes[2][0] * m_fPlanes[2][0] + 
                      m_fPlanes[2][1] * m_fPlanes[2][1] + 
                      m_fPlanes[2][2] * m_fPlanes[2][2] );

    m_fPlanes[2][0] /= fDist;
    m_fPlanes[2][1] /= fDist;
    m_fPlanes[2][2] /= fDist;
    m_fPlanes[2][3] /= fDist;

    m_fPlanes[3][0] = mvp[ 3] - mvp[ 1];
    m_fPlanes[3][1] = mvp[ 7] - mvp[ 5];
    m_fPlanes[3][2] = mvp[11] - mvp[ 9];
    m_fPlanes[3][3] = mvp[15] - mvp[13];

    fDist = (float) sqrt( m_fPlanes[3][0] * m_fPlanes[3][0] + 
                      m_fPlanes[3][1] * m_fPlanes[3][1] + 
                      m_fPlanes[3][2] * m_fPlanes[3][2] );

    m_fPlanes[3][0] /= fDist;
    m_fPlanes[3][1] /= fDist;
    m_fPlanes[3][2] /= fDist;
    m_fPlanes[3][3] /= fDist;

    m_fPlanes[4][0] = mvp[ 3] - mvp[ 2];
    m_fPlanes[4][1] = mvp[ 7] - mvp[ 6];
    m_fPlanes[4][2] = mvp[11] - mvp[10];
    m_fPlanes[4][3] = mvp[15] - mvp[14];

    fDist = (float) sqrt( m_fPlanes[4][0] * m_fPlanes[4][0] +  
                      m_fPlanes[4][1] * m_fPlanes[4][1] + 
                      m_fPlanes[4][2] * m_fPlanes[4][2] );

    m_fPlanes[4][0] /= fDist;
    m_fPlanes[4][1] /= fDist;
    m_fPlanes[4][2] /= fDist;
    m_fPlanes[4][3] /= fDist;

    m_fPlanes[5][0] = mvp[ 3] + mvp[ 2];
    m_fPlanes[5][1] = mvp[ 7] + mvp[ 6];
    m_fPlanes[5][2] = mvp[11] + mvp[10];
    m_fPlanes[5][3] = mvp[15] + mvp[14];

    fDist = (float) sqrt( m_fPlanes[5][0] * m_fPlanes[5][0] + 
                      m_fPlanes[5][1] * m_fPlanes[5][1] + 
                      m_fPlanes[5][2] * m_fPlanes[5][2] );

    m_fPlanes[5][0] /= fDist;
    m_fPlanes[5][1] /= fDist;
    m_fPlanes[5][2] /= fDist;
    m_fPlanes[5][3] /= fDist;
}
