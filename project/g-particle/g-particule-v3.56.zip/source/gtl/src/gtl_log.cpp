/***********************************************\
	GTL (G-Truc Library) : Alpha 4.0
	Copyright (c) 2003, G-Truc Creation.		
*************************************************
	G-Truc Creation, www.g-truc.net				
	par Groove, groove@g-truc.net				
*************************************************
	gtl_log.cpp, 05/09/2003
\***********************************************/

#include "../include/gtl_log.h"
/*
void CLog::CLog (const char* szStdOut, const char* szStdErr)
{
	
}
*/