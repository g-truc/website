/***********************************************\
	GTL (G-Truc Library) : Alpha 4.0
	Copyright (c) 2003, G-Truc Creation.		
*************************************************
	G-Truc Creation, www.g-truc.net				
	par Groove, groove@g-truc.net				
*************************************************
	gtl_text.cpp, 21/09/2003
\***********************************************/

#include "../include/gtl_text.h"
#include <GL/glut.h>
#include <stdio.h>
#include <stdarg.h>

using namespace gtl;

CText::CText ()
{
	m_pBuffer = NULL;
	m_GlutFont = GLUT_BITMAP_HELVETICA_12;

	SetBufferSize (GTL_TEXT_BUF_SIZE);
}

CText::~CText ()
{
	delete m_pBuffer;
}

void CText::SetBufferSize (long iSize)
{
	if (m_pBuffer != NULL)
		delete m_pBuffer;

	m_pBuffer = new char[iSize];
}

void CText::Begin (float fWindowWidth, float fWindowHeight)
{
	glPushAttrib (GL_TEXTURE_BIT | GL_DEPTH_TEST | GL_LIGHTING);

	glDisable (GL_TEXTURE_2D);
	glDisable (GL_DEPTH_TEST);
	glDisable (GL_LIGHTING);

    glMatrixMode (GL_PROJECTION);
    glPushMatrix ();
    glLoadIdentity ();
    glOrtho (0, fWindowWidth, fWindowHeight, 0, -1, 1);

    glMatrixMode (GL_MODELVIEW);
    glPushMatrix ();
    glLoadIdentity ();
}

void CText::End ()
{
    glMatrixMode (GL_PROJECTION);
    glPopMatrix ();

    glMatrixMode (GL_MODELVIEW);
    glPopMatrix ();

    glPopAttrib ();
}

void* CText::GetFont () const
{
	return m_GlutFont;
}

void CText::SetFont (void* GlutFont)
{
	m_GlutFont = GlutFont;
}

void CText::Print (float x, float y, char *szMsg, ...)
{
	char text[1024];
	va_list ap;

	if (szMsg == NULL)
		return;

	va_start (ap, szMsg);
	    vsprintf (text, szMsg, ap);
	va_end (ap);

    char *c = '\0';
    glRasterPos2f (x, y);

    for (c = text; *c != '\0'; ++c)
        glutBitmapCharacter (m_GlutFont, *c);
}