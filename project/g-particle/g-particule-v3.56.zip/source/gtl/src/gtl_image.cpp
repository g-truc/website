/***********************************************\
	GTL (G-Truc Library) : Alpha 4.0			
	Copyright (c) 2003, G-Truc Creation.		
*************************************************
	G-Truc Creation, www.g-truc.net				
	par Groove, groove@g-truc.net				
*************************************************
	gtl_image.cpp, 01/08/2003
\***********************************************/

#include "../include/gtl_image.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

using namespace gtl;

CImage::CImage ()
{
	m_pucData = NULL;
	m_szFilename = NULL;
	m_pucColorMapData = NULL;
}
	
CImage::~CImage ()
{
	if (m_pucData != NULL)
	{
		free (m_pucData);
		m_pucData = NULL;
	}
	
	if (m_szFilename != NULL)
	{
		free (m_szFilename);
		m_szFilename = NULL;
	}
	
	if (m_pucColorMapData != NULL)
	{
		free (m_pucColorMapData);
		m_pucColorMapData = NULL;
	}
}

void CImage::SaveFilename (const char* szFilename)
{
	int iFilenameSize = strlen (szFilename);
	m_szFilename = (char *) malloc (iFilenameSize+1);

	for (int i=0; i<iFilenameSize; i++)
		m_szFilename[i] = szFilename[i];

	m_szFilename[iFilenameSize+1] = '\0';
}

void CImage::Error (const EImageError & iError, const char* szInfo)
{
	switch (iError)
	{
	default:
	case ERROR_IMAGE_NULL:
		break;
	case ERROR_IMAGE_FILE_NOT_FOUND:
		printf ("GTL ERROR : File not found '%s'\n", szInfo);
		break;
	case ERROR_IMAGE_MEM_ALLOC:
		printf ("GTL ERROR : Not readable image '%s'\n", szInfo);
		break;
	case ERROR_IMAGE_SIZE:
		printf ("GTL ERROR : Incorrect size '%s'\n", szInfo);
		break;
	case ERROR_IMAGE_PIXEL_BITS:
		printf ("GTL ERROR : Incorrect color '%s'\n", szInfo);
		break;
	}
	exit (0);
}

void CImage::LoadBGR24FromBGR24Colormap (unsigned char* pucData)
{
	for (int k = 0; k < (m_unWidth * m_unHeight); k++)
	{
		m_pucData[k*3+0] = m_pucColorMapData[pucData[k]*3+0];
		m_pucData[k*3+1] = m_pucColorMapData[pucData[k]*3+1];
		m_pucData[k*3+2] = m_pucColorMapData[pucData[k]*3+2];
	}
	m_Format = COLOR_FORMAT_BGR24;
}

void CImage::LoadRGB24FromBGR24Colormap (unsigned char* pucData)
{
	for (int k = 0; k < (m_unWidth * m_unHeight); k++)
	{
		m_pucData[k*3+0] = m_pucColorMapData[pucData[k]*3+2];
		m_pucData[k*3+1] = m_pucColorMapData[pucData[k]*3+1];
		m_pucData[k*3+2] = m_pucColorMapData[pucData[k]*3+0];
	}
	m_Format = COLOR_FORMAT_RGB24;
}

void CImage::LoadARGB16FromABGR16 (unsigned char* pucData)
{
	for (int k = 0; k < (m_unWidth * m_unHeight * 2); k+=2)
	{
		m_pucData[k+0] = pucData[k+0];
		m_pucData[k+1] = pucData[k+1];
	}
	m_Format = COLOR_FORMAT_ARGB16;
}

void CImage::LoadBGR24FromBGR24 (unsigned char* pucData)
{
	for (int k = 0; k < (m_unWidth * m_unHeight * 3); k+=3)
	{
		m_pucData[k+0] = pucData[k+0];
		m_pucData[k+1] = pucData[k+1];
		m_pucData[k+2] = pucData[k+2];
	}
	m_Format = COLOR_FORMAT_BGR24;
}

void CImage::LoadRGB24FromBGR24 (unsigned char* pucData)
{
	for (int k = 0; k < (m_unWidth * m_unHeight * 3); k+=3)
	{
		m_pucData[k+0] = pucData[k+2];
		m_pucData[k+1] = pucData[k+1];
		m_pucData[k+2] = pucData[k+0];
	}
	m_Format = COLOR_FORMAT_RGB24;
}

void CImage::LoadBGRA32FromBGRA32 (unsigned char* pucData)
{
	for (int k = 0; k < (m_unWidth * m_unHeight * 4); k+=4)
	{
		m_pucData[k+0] = pucData[k+0];
		m_pucData[k+1] = pucData[k+1];
		m_pucData[k+2] = pucData[k+2];
		m_pucData[k+3] = pucData[k+3];
	}
	m_Format = COLOR_FORMAT_BGRA32;
}

void CImage::LoadRGBA32FromBGRA32 (unsigned char* pucData)
{
	for (int k = 0; k < (m_unWidth * m_unHeight * 4); k+=4)
	{
		m_pucData[k+0] = pucData[k+2];
		m_pucData[k+1] = pucData[k+1];
		m_pucData[k+2] = pucData[k+0];
		m_pucData[k+3] = pucData[k+3];
	}
	m_Format = COLOR_FORMAT_RGBA32;
}

void CImage::ReadDataRGBA (FILE *File, const unsigned int iOffsetData)
{
	if (!(m_pucData = (unsigned char *) malloc (m_unHeight * m_unHeight * 4)))
	{
		Error (ERROR_IMAGE_MEM_ALLOC);
		return;
	}

	fseek (File, iOffsetData, SEEK_SET);
	unsigned short unCheckSize = fread (m_pucData, sizeof (unsigned char), m_unHeight * m_unHeight * 4, File); 

	if (unCheckSize != (m_unHeight * m_unHeight * 4))
	{
		Error (ERROR_IMAGE_BAD_DATA);
		free (m_pucData);
		return;
	}

	// Groove - 17/02/2003 - Change BGRA color format to RGBA color format
	if (m_Format == COLOR_FORMAT_BGRA32)
	{
		BGRtoRGB ();
		m_Format = COLOR_FORMAT_RGBA32;
	}
}

void CImage::ReadDataRGB (FILE *File, const unsigned int iOffsetData)
{
	
	m_pucData = (unsigned char *) malloc (m_unHeight * m_unHeight * 3); 

	if (m_pucData == NULL)
	{
		Error (ERROR_IMAGE_MEM_ALLOC);
		return;
	}

	fseek (File, iOffsetData, SEEK_SET);
	unsigned short unCheckSize = fread (m_pucData, sizeof (unsigned char), m_unHeight * m_unHeight * 3, File);

	if (unCheckSize != m_unHeight * m_unHeight * 3)
	{
		free (m_pucData);
		Error (ERROR_IMAGE_BAD_DATA);
		return;
	}

	// Groove - 17/02/2003 - Change BGR color format to RGB color format
	if (m_Format == COLOR_FORMAT_BGR24)
	{
		BGRtoRGB ();
		m_Format = COLOR_FORMAT_RGB24;
	}
}

void CImage::ReadDataAlpha (FILE *File, const unsigned int iOffsetData)
{
	m_pucData = (unsigned char *) malloc (m_unHeight * m_unHeight);

	if (m_pucData == NULL)
	{
		Error (ERROR_IMAGE_MEM_ALLOC);
		return;
	}

	fseek (File, iOffsetData, SEEK_SET);
	unsigned short unCheckSize = fread (m_pucData, sizeof (unsigned char), m_unHeight * m_unHeight, File);

	if (unCheckSize != m_unHeight * m_unHeight)
	{
		free (m_pucData);
		Error (ERROR_IMAGE_BAD_DATA);
		return;
	}

	m_Format = COLOR_FORMAT_GRAY08;
}

void CImage::BGRtoRGB ()
{
	unsigned int iMax = 0;

	switch (m_ucPixelSize)
	{
	case 24:
		iMax = 3;
		break;
	case 32:
		iMax = 4;
		break;
	}

	unsigned char Temp;
	for (unsigned int i=0; i<(m_unHeight * m_unHeight * iMax); i+=iMax)
	{
		Temp = m_pucData[i];
		m_pucData[i] = m_pucData[i+2];
		m_pucData[i+2] = Temp;
	}
}
