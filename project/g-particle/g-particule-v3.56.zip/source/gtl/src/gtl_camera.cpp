/***********************************************\
	GTL (G-Truc Library) : Alpha 4.0
	Copyright (c) 2003, G-Truc Creation.		
*************************************************
	G-Truc Creation, www.g-truc.net				
	par Groove, groove@g-truc.net				
*************************************************
	gtl_camera.cpp, 05/09/2003
\***********************************************/

#include "../include/gtl_camera.h"
#include "../include/gtl_math.h"

#ifdef _WIN32
	#include <windows.h>
#endif // _WIN32
#include <GL/glu.h>
#include <GL/gl.h>

using namespace gtl;

CCamera::CCamera (float fViewDistance)
{
	m_Position = TVector3 (0.0, 0.0, 0.0);
	m_View = TVector3 (0.0, 0.5, 1.0);
	m_UpVector = TVector3 (0.0, 0.0, 1.0);
	m_fViewDistance = fViewDistance;
	m_fCurrentRotX = 0.0f;
}

void CCamera::LookAt (int iMoveX, int iMoveZ)
{
	UpdateView (iMoveX, iMoveZ);

	gluLookAt (m_Position (X),	m_Position (Y),		m_Position (Z),	
		 	   m_View (X),		m_View (Y),			m_View (Z),	
			   m_UpVector (X),	m_UpVector (Y),		m_UpVector (Z));
}

void CCamera::Position (const TVector3 & Position, const TVector3 & View, const TVector3 & UpVector)
{
	m_Position = Position;
	m_View = View;
	m_UpVector = UpVector;
}

void CCamera::UpdateView (int iMoveX, int iMoveZ)
{
	if ((iMoveX == 0) && (iMoveZ == 0))
		return;

	float fAngleX = iMoveX / 2000.0f;		
	float fAngleZ = iMoveZ / 2000.0f;		

	m_fCurrentRotX -= fAngleZ;  

	if (m_fCurrentRotX > 1.0f)
		m_fCurrentRotX = 1.0f;
	else if (m_fCurrentRotX < -1.0f)
		m_fCurrentRotX = -1.0f;
	else
	{
		TVector3 Axis = (m_View - m_Position) ^ m_UpVector;
		Axis = Axis.Normalize ();

		RotateView (fAngleZ, Axis (X), Axis (Y), Axis (Z));
		RotateView (fAngleX, m_UpVector (X), m_UpVector (Y), m_UpVector (Z));
	}
}

void CCamera::RotateView (float angle, float x, float y, float z)
{
	TVector3 NewView;
	TVector3 View = m_View - m_Position;		

	float cosTheta = cosf (angle);
	float sinTheta = sinf (angle);

	NewView (X)  = (cosTheta + (1 - cosTheta) * x * x)		* View (X);
	NewView (X) += ((1 - cosTheta) * x * y - z * sinTheta)	* View (Y);
	NewView (X) += ((1 - cosTheta) * x * z + y * sinTheta)	* View (Z);

	NewView (Y)  = ((1 - cosTheta) * x * y + z * sinTheta)	* View (X);
	NewView (Y) += (cosTheta + (1 - cosTheta) * y * y)		* View (Y);
	NewView (Y) += ((1 - cosTheta) * y * z - x * sinTheta)	* View (Z);

	NewView (Z)  = ((1 - cosTheta) * x * z - y * sinTheta)	* View (X);
	NewView (Z) += ((1 - cosTheta) * y * z + x * sinTheta)	* View (Y);
	NewView (Z) += (cosTheta + (1 - cosTheta) * z * z)		* View (Z);

	m_View = m_Position + NewView;
}

void CCamera::Move (float fSpeed)
{
	TVector3 Vector = m_View - m_Position;

	m_Position += Vector * fSpeed;
	m_View += Vector * fSpeed;
}

void CCamera::Strafe (float fSpeed)
{
	TVector3 Vector = (m_View - m_Position) ^ m_UpVector;

	m_Position += Vector * fSpeed;
	m_View += Vector * fSpeed;
}

bool CCamera::TestDistance (float x, float y, float z)
{
	if ((SQR(m_Position (X) - x) + SQR(m_Position (Y) - y) + SQR(m_Position (Z) - z)) > SQR(m_fViewDistance))
		return false;
	return true;
}
