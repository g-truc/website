/***********************************************\
	GTL (G-Truc Library) : Alpha 4.0
	Copyright (c) 2003, G-Truc Creation.		
*************************************************
	G-Truc Creation, www.g-truc.net				
	par Groove, groove@g-truc.net				
*************************************************
	gtl_image_raw.cpp, 21/03/2003
\***********************************************/

#include "../include/gtl_image_raw.h"
#include <stdio.h>
#include <stdlib.h>

using namespace gtl;

CImageRAW::CImageRAW ()
{

}

CImageRAW::CImageRAW (const char* szFilename, const unsigned short unWitdh, const unsigned short unHeight, const EColorFormat Format)
{
	Load (szFilename);
	Init (unWitdh, unHeight);
}

CImageRAW::~CImageRAW ()
{

}

void CImageRAW::Init (const unsigned short unWitdh, const unsigned short unHeight)
{
	m_unHeight = unHeight;
	m_unWidth = unWitdh;
}

bool CImageRAW::Load (const char* szFilename, const EColorFormat ColorFormat)
{
	FILE *File;

	if (!(File = fopen (szFilename, "r+b")))
	{
		Error (ERROR_IMAGE_FILE_NOT_FOUND, szFilename);
		return false;
	}

	// Groove - 05/03/2003 - On va a la fin du fichier
	fseek (File, 0, SEEK_END);
	// Groove - 05/03/2003 - On r�cup�re la taille du fichier en nombre d'octets
	long iFileLenght = ftell (File);

	#ifdef _DEBUG
		printf ("iFileLenght = %d\n", iFileLenght);
	#endif //_DEBUG

	m_pucData = (unsigned char *) malloc (iFileLenght * sizeof (unsigned char));

	fseek (File, 0, SEEK_SET);
	fread (m_pucData, sizeof (unsigned char), iFileLenght, File);
	fclose (File);

	if (m_pucData == NULL)
	{
		Error (ERROR_IMAGE_BAD_DATA);
		return false;
	}

	return true;
}
