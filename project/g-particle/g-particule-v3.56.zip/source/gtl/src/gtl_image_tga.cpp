/***********************************************\
	GTL (G-Truc Library) : Alpha 4.0
	Copyright (c) 2003, G-Truc Creation.		
*************************************************
	G-Truc Creation, www.g-truc.net				
	par Groove, groove@g-truc.net				
*************************************************
	gtl_image_tga.cpp, 01/08/2003
\***********************************************/

#include "../include/gtl_image_tga.h"
#include <stdio.h>
#include <string.h>

using namespace gtl;

CImageTGA::~CImageTGA ()
{
	if (m_szIdenticationField != NULL)
	{
		free (m_szIdenticationField);
		m_szIdenticationField = NULL;
	}
}

bool CImageTGA::Load (const char* szFilename, const EColorFormat ColorFormat)
{
	// Groove - 05/03/2003 - Nombre de bits dans le champs d'identification
	unsigned char iNbByteInIdField;
	// Groove - 05/03/2003 - L'image utilise telle une palette de couleurs
	bool bUseColorMap;
	// Groove - 05/03/2003 - Type de l'image
	unsigned char iImageType;
	// Groove - 05/03/2003 - Offset de la premi�re couleur de la palette 
	unsigned short iColorMapOrigin = 0;
	// Groove - 05/03/2003 - Nombre de couleurs dans la palette.
	unsigned short iColorMapLength = 0;
	// Groove - 05/03/2003 - Nombre de bits par couleur dans la palette.
	unsigned char iColorMapSize = 0;
	// Groove - 05/03/2003 - Origine de l'image en X de la texture
	short iOriginX;
	// Groove - 05/03/2003 - Origine de l'image en Y de la texture
	short iOriginY;
	// Groove - 05/03/2003 - Octet indiquant quelques information sur l'image suivant la position des bits
	// Bit 0-3, nombre de bit r�serv� pour la couche alpha
	// Bit 4, Reserv�, doit etre �gale � 0
	// Bit 5, sens de l'image. Si Bit5 == 1 l'origine de l'image est en haut a gauche de l'ecran sinon en bas � gauche
	// Bit 6,7 Drapeau de stokage de donn�es intercal�es
	// 00 -> Pas de donn�es intercal�s
	// 01 -> ???
	// 10 -> ???
	// 11 -> reserved
	unsigned char iImageDescriptorByte;

	SaveFilename (szFilename);

///////////////////////////////////////////////////////

	FILE *File;

	if (!(File = fopen (szFilename, "r+b")))
	{
		Error (ERROR_IMAGE_FILE_NOT_FOUND, szFilename);
		return false;
	}

	// Groove - 05/03/2003 - On va a la fin du fichier
	fseek (File, 0, SEEK_END);
	// Groove - 05/03/2003 - On r�cup�re la taille du fichier en nombre d'octets
	long iSize = ftell (File);

	#ifdef _DEBUG
		printf ("iSize = %d\n", iSize);
	#endif //_DEBUG

	// Groove - 05/03/2003 - On aloue de la m�moire dynamique de la taille du fichier
	unsigned char *piFileBuffer = (unsigned char *) malloc (iSize);
	// Groove - 05/03/2003 - On se positionne au debut du fichier
	fseek (File, 0, SEEK_SET);
	// Groove - 05/03/2003 - On lit la totalit� du fichier.
	fread (piFileBuffer, sizeof (unsigned char), iSize, File);

	// Groove - 05/03/2003 - Fermeture du fichier
	fclose (File);

	// Groove - 05/03/2003 - Lecture du header
	iNbByteInIdField = piFileBuffer[0];
	bUseColorMap = piFileBuffer[1] == 1;
	iImageType = piFileBuffer[2];

	#ifdef _DEBUG
		printf ("iNbByteInIdField = %d\n", iNbByteInIdField);
		printf ("bUseColorMap = %d\n", bUseColorMap);
		printf ("iImageType = %d\n", iImageType);
	#endif //_DEBUG

	if (bUseColorMap)
	{
		iColorMapOrigin = iNbByteInIdField + 18;
		//iColorMapOrigin = piFileBuffer[3] | (piFileBuffer[4] << 8);
		iColorMapLength = piFileBuffer[5] | (piFileBuffer[6] << 8);
		iColorMapSize = piFileBuffer[7];
		#ifdef _DEBUG
			printf ("iColorMapOrigin = %d\n", iColorMapOrigin);
			printf ("iColorMapLength = %d\n", iColorMapLength);
			printf ("iColorMapSize = %d\n", iColorMapSize);
		#endif //_DEBUG

		if (!(m_pucColorMapData = (unsigned char *) malloc (sizeof (unsigned char) * iColorMapLength * iColorMapSize / 8)))
		{
			free (piFileBuffer);
			piFileBuffer = NULL;
			Error (ERROR_IMAGE_MEM_ALLOC, szFilename);
			return false;
		}
		for (unsigned short i=0; i<(iColorMapLength * iColorMapSize / 8); i++)
			m_pucColorMapData[i] = piFileBuffer [iColorMapOrigin+i];
	}

	iOriginX = piFileBuffer[8] | (piFileBuffer[9] << 8);
	iOriginY = piFileBuffer[10] | (piFileBuffer[11] << 8);
	m_unWidth = piFileBuffer[12] | (piFileBuffer[13] << 8);
	m_unHeight = piFileBuffer[14] | (piFileBuffer[15] << 8);
	m_ucPixelSize = piFileBuffer[16];
	iImageDescriptorByte = piFileBuffer[17];
/*
	if (!CheckSize (m_unWidth) || !CheckSize (m_unHeight))
	{
		free (m_pucColorMapData);
		m_pucColorMapData = NULL;
		free (piFileBuffer);
		piFileBuffer = NULL;
		Error (ERROR_IMAGE_SIZE, szFilename);
		return false;
	}
*/
	#ifdef _DEBUG
		printf ("iOriginX = %d\n", iOriginX);
		printf ("iOriginY = %d\n", iOriginY);
		printf ("iWidth = %d\n", m_unWidth);
		printf ("iHeight = %d\n", m_unHeight);
		printf ("iPixelSize = %d\n", m_ucPixelSize);
		printf ("iImageDescriptorByte = %d\n", iImageDescriptorByte);
	#endif //_DEBUG	

	// Groove - 05/03/2003 - Lecture du champ d'information (titre de l'image)
	if (iNbByteInIdField > 0)
	{
		if (!(m_szIdenticationField =  (char *) malloc (sizeof (char) * iNbByteInIdField)))
		{
			free (m_pucColorMapData);
			m_pucColorMapData = NULL;
			free (piFileBuffer);
			piFileBuffer = NULL;
			Error (ERROR_IMAGE_MEM_ALLOC, szFilename);
			return false;
		}
		for (short j=0; j<iNbByteInIdField; j++)
			m_szIdenticationField[j] = piFileBuffer [18+j];
	}

	// Groove - 09/03/2003 - Allocation de la m�moire n�c�ssaire pour r�cup�rer les donn�es de l'image.
	if (!(m_pucData = (unsigned char *) malloc (sizeof (unsigned char) * m_ucPixelSize * m_unWidth * m_unHeight)))
	{
		FreeAll ();
		free (piFileBuffer);
		piFileBuffer = NULL;
		Error (ERROR_IMAGE_MEM_ALLOC, szFilename);
		return false;
	}

	long iDataOrigin;

	switch (iImageType)
	{
	default:
		FreeAll ();
		free (piFileBuffer);
		piFileBuffer = NULL;
		Error (ERROR_IMAGE_BAD_DATA, "Lecture impossible de l'image");
		break;
	case 1:
		iDataOrigin = iColorMapOrigin + iColorMapLength * iColorMapSize / 8;
		
		if (ColorFormat == COLOR_FORMAT_BGR24 || ColorFormat == COLOR_FORMAT_DEFAULT)
			LoadBGR24FromBGR24Colormap (&piFileBuffer[iDataOrigin]);

		if (ColorFormat == COLOR_FORMAT_RGB24)
			LoadRGB24FromBGR24Colormap (&piFileBuffer[iDataOrigin]);
		break;
	case 2:
		iDataOrigin = 18 + iNbByteInIdField;

		if (m_ucPixelSize == 16)
		{
			// Groove - 10/03/2003 - Image ARGB16 -> ARGB16
			if (ColorFormat == COLOR_FORMAT_ARGB16 || ColorFormat == COLOR_FORMAT_DEFAULT)
				LoadARGB16FromABGR16 (&piFileBuffer[iDataOrigin]);
		}

		if (m_ucPixelSize == 24)
		{
			// Groove - 10/03/2003 - Image BGR24 -> BGR24
			if (ColorFormat == COLOR_FORMAT_BGR24 || ColorFormat == COLOR_FORMAT_DEFAULT)
				LoadBGR24FromBGR24 (&piFileBuffer[iDataOrigin]);
			// Groove - 10/03/2003 - Image BGR24 -> RGB24
			else if (ColorFormat == COLOR_FORMAT_RGB24)
				LoadRGB24FromBGR24 (&piFileBuffer[iDataOrigin]);
		}

		else if (m_ucPixelSize == 32)
		{
			// Groove - 10/03/2003 - Image BGRA32 -> BGRA32
			if (ColorFormat == COLOR_FORMAT_BGRA32 || ColorFormat == COLOR_FORMAT_DEFAULT)
				LoadBGRA32FromBGRA32 (&piFileBuffer[iDataOrigin]);
			// Groove - 10/03/2003 - Image BGRA32 -> RGBA32
			else if (ColorFormat == COLOR_FORMAT_RGBA32)
				LoadRGBA32FromBGRA32 (&piFileBuffer[iDataOrigin]);
		}

		break;
	}

	free (piFileBuffer);
	piFileBuffer = NULL;

	return true;
}

bool CImageTGA::Save ()
{
	return SaveAs (m_szFilename);
}

bool CImageTGA::SaveAs (const char* szFilename)
{
	unsigned char pucHeader [18];
	pucHeader[0] = 0;
	pucHeader[1] = 0;
	pucHeader[2] = 2;
	pucHeader[3] = 0;
	pucHeader[4] = 0;
	pucHeader[5] = 0;
	pucHeader[6] = 0;
	pucHeader[7] = 0;
	pucHeader[8] = 0;
	pucHeader[9] = 0;
	pucHeader[10] = 0;
	pucHeader[11] = 0;
	pucHeader[12] = /*static_cast<unsigned char>*/ (m_unWidth);
	pucHeader[13] = m_unWidth >> 8;
	pucHeader[14] = /*static_cast<unsigned char>*/ (m_unHeight);
	pucHeader[15] = m_unHeight >> 8;
	pucHeader[16] = 24;
	pucHeader[17] = 0;

	FILE *File;

	if (!(File = fopen (szFilename, "wb")))
	{
		Error (ERROR_IMAGE_FILE_NOT_FOUND, szFilename);
		return false;
	}

	fwrite (pucHeader, sizeof (unsigned char), 18, File);
	fwrite (m_pucData, sizeof (unsigned char), m_unWidth*m_unHeight*3, File);

	return true;
}

bool CImageTGA::CheckSize (long iSize)
{
    return (iSize == 2		|| iSize == 4		|| 
			iSize == 8		|| iSize == 16		|| 
			iSize == 32		|| iSize == 64		||
			iSize == 128	|| iSize == 256		|| 
			iSize == 512	|| iSize == 1024	||
			iSize == 2048	|| iSize == 4096	||
			iSize == 8192	|| iSize == 16384);
}

void CImageTGA::FreeAll ()
{
 	if (m_szIdenticationField != NULL)
		free (m_szIdenticationField);
	if (m_pucColorMapData != NULL)
		free (m_pucColorMapData);
	if (m_pucData != NULL)
		free (m_pucData);
	if (m_szFilename != NULL)
		free (m_szFilename);
}
