/***********************************************\
	GTL (G-Truc Library) : Alpha 4.0
	Copyright (c) 2003, G-Truc Creation.		
*************************************************
	G-Truc Creation, www.g-truc.net				
	par Groove, groove@g-truc.net				
*************************************************
	gtl_image_bmp.cpp, 25/09/2003
\***********************************************/

#include "../include/gtl_image_bmp.h"
#include <stdio.h>
#include <stdlib.h>

using namespace gtl;

#define	BITMAP_ID			('B' + ('M'<<8))

CImageBMP::CImageBMP ()
{

}

CImageBMP::CImageBMP (const char* szFilename, const EColorFormat ColorFormat)
{
	Load (szFilename, ColorFormat);
}

CImageBMP::~CImageBMP ()
{

}
/*
bool CImageBMP::Load (const char *szFilename, const EColorFormat ColorFormat)
{
	FILE *File;
	unsigned short iType;
	unsigned int iOffsetData;
	int piSize[2];
	
	if (!(File = fopen (szFilename, "r+b")))
	{
		Error (ERROR_IMAGE_FILE_NOT_FOUND, szFilename);
		return false;
	}

	fread (&iType, sizeof (unsigned short), 1, File);
	if (iType != BITMAP_ID)
	{
		Error (ERROR_IMAGE_TYPE);
		return false;
	}

	// Groove - 17/02/2003 - Lecture de l'adresse ou commence les donn�es
	fseek (File, 10, SEEK_SET);
	fread (&iOffsetData, sizeof (unsigned int), 1, File);
	fseek (File, 18, SEEK_SET);

	// Groove - 17/02/2003 - Lecture de dimension de l'image
	fread (&piSize, sizeof (int), 2, File);
	m_unHeight = piSize[1];
	m_unWidth = piSize[0];

	// Groove - 17/02/2003 - Lecture du nombre de bit par pixel
	fseek (File, 28, SEEK_SET);
	fread (&m_ucPixelSize, sizeof (unsigned short), 1, File);

	switch (ColorFormat)
	{
	default:
		break;
	case COLOR_FORMAT_DEFAULT:
	case COLOR_FORMAT_BGR24:
		if (m_ucPixelSize == 24)
		{
			ReadDataRGB (File, iOffsetData);
		}
		break;
	case COLOR_FORMAT_RGB24:
		if (m_ucPixelSize == 24)
		{
			ReadDataRGB (File, iOffsetData);
			BGRtoRGB ();
		}
		break;
	}

	fclose (File);

	return true;
}
*/

bool CImageBMP::Load (const char *szFilename, const EColorFormat ColorFormat)
{
	SaveFilename (szFilename);

	FILE *File;

	if (!(File = fopen (szFilename, "r+b")))
	{
		Error (ERROR_IMAGE_FILE_NOT_FOUND, szFilename);
		return false;
	}

	// Groove - 05/03/2003 - On va a la fin du fichier
	fseek (File, 0, SEEK_END);
	// Groove - 05/03/2003 - On r�cup�re la taille du fichier en nombre d'octets
	long iSize = ftell (File);

	#ifdef _DEBUG
		printf ("iSize = %d\n", iSize);
	#endif //_DEBUG

	// Groove - 05/03/2003 - On aloue de la m�moire dynamique de la taille du fichier
	unsigned char *piFileBuffer = (unsigned char *) malloc (iSize);
	// Groove - 05/03/2003 - On se positionne au debut du fichier
	fseek (File, 0, SEEK_SET);
	// Groove - 05/03/2003 - On lit la totalit� du fichier.
	fread (piFileBuffer, sizeof (unsigned char), iSize, File);

	// Groove - 05/03/2003 - Fermeture du fichier
	fclose (File);
	int iOffsetData = piFileBuffer[10] | piFileBuffer[11] << 8 | piFileBuffer[12] << 16 | piFileBuffer[13] << 24;
	m_unHeight = piFileBuffer[18] | piFileBuffer[19] << 8 | piFileBuffer[20] << 16 | piFileBuffer[21] << 24;
	m_unWidth = piFileBuffer[22] | piFileBuffer[23] << 8 | piFileBuffer[24] << 16 | piFileBuffer[25] << 24;

	switch (ColorFormat)
	{
	default:
		break;
	case COLOR_FORMAT_DEFAULT:
	case COLOR_FORMAT_BGR24:
		if (m_ucPixelSize == 24)
			LoadBGR24FromBGR24 (&piFileBuffer[iOffsetData]);
		break;
	case COLOR_FORMAT_RGB24:
		if (m_ucPixelSize == 24)
			LoadRGB24FromBGR24 (&piFileBuffer[iOffsetData]);
		break;
	}

	free (piFileBuffer);

	return true;
}


